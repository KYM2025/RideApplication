// Modal Window System
class ModalManager {
    constructor() {
        this.modals = new Map();
        this.activeModal = null;
        this.modalStack = [];
        this.backdrop = null;
        this.options = {
            closeOnBackdrop: true,
            closeOnEscape: true,
            animationDuration: 300,
            maxWidth: '90vw',
            maxHeight: '90vh',
            zIndexBase: 1000
        };
        
        this.init();
    }
    
    init() {
        this.createBackdrop();
        this.bindGlobalEvents();
    }
    
    createBackdrop() {
        this.backdrop = document.createElement('div');
        this.backdrop.className = 'modal-backdrop';
        this.backdrop.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: ${this.options.zIndexBase - 1};
            opacity: 0;
            visibility: hidden;
            transition: all ${this.options.animationDuration}ms ease-in-out;
            backdrop-filter: blur(2px);
        `;
        document.body.appendChild(this.backdrop);
    }
    
    bindGlobalEvents() {
        // Escape key to close modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.activeModal && this.options.closeOnEscape) {
                this.close(this.activeModal.id);
            }
        });
        
        // Backdrop click to close
        this.backdrop.addEventListener('click', (e) => {
            if (e.target === this.backdrop && this.activeModal && this.options.closeOnBackdrop) {
                this.close(this.activeModal.id);
            }
        });
        
        // Prevent body scroll when modal is open
        document.addEventListener('wheel', (e) => {
            if (this.activeModal && !e.target.closest('.modal-content')) {
                e.preventDefault();
            }
        }, { passive: false });
    }
    
    // Create modal
    create(id, options = {}) {
        if (this.modals.has(id)) {
            console.warn(`Modal with id "${id}" already exists`);
            return this.modals.get(id);
        }
        
        const config = {
            title: options.title || 'Modal',
            content: options.content || '',
            size: options.size || 'medium',
            closable: options.closable !== false,
            draggable: options.draggable || false,
            resizable: options.resizable || false,
            buttons: options.buttons || [],
            onOpen: options.onOpen || null,
            onClose: options.onClose || null,
            onConfirm: options.onConfirm || null,
            onCancel: options.onCancel || null,
            className: options.className || '',
            ...options
        };
        
        const modal = this.createModalElement(id, config);
        this.modals.set(id, { element: modal, config, isOpen: false });
        
        return modal;
    }
    
    createModalElement(id, config) {
        const modal = document.createElement('div');
        modal.id = id;
        modal.className = `modal ${config.className}`;
        modal.style.cssText = `
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%) scale(0.9);
            z-index: ${this.options.zIndexBase + this.modalStack.length};
            opacity: 0;
            visibility: hidden;
            transition: all ${this.options.animationDuration}ms ease-in-out;
            max-width: ${this.options.maxWidth};
            max-height: ${this.options.maxHeight};
        `;
        
        const sizeClasses = {
            small: 'modal-sm',
            medium: 'modal-md',
            large: 'modal-lg',
            xlarge: 'modal-xl',
            fullscreen: 'modal-fullscreen'
        };
        
        if (sizeClasses[config.size]) {
            modal.classList.add(sizeClasses[config.size]);
        }
        
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title">${config.title}</h3>
                    <div class="modal-header-actions">
                        ${config.draggable ? '<button class="modal-drag-handle" title="Drag to move"><i class="fas fa-arrows-alt"></i></button>' : ''}
                        ${config.closable ? '<button class="modal-close" title="Close"><i class="fas fa-times"></i></button>' : ''}
                    </div>
                </div>
                <div class="modal-body">
                    ${config.content}
                </div>
                ${config.buttons.length > 0 ? this.createModalFooter(config.buttons) : ''}
            </div>
            ${config.resizable ? '<div class="modal-resize-handle"></div>' : ''}
        `;
        
        document.body.appendChild(modal);
        this.bindModalEvents(modal, config);
        
        return modal;
    }
    
    createModalFooter(buttons) {
        const buttonElements = buttons.map(button => {
            const btnClass = button.type === 'primary' ? 'btn btn-primary' : 
                           button.type === 'danger' ? 'btn btn-danger' : 'btn btn-secondary';
            
            return `<button class="modal-btn ${btnClass}" data-action="${button.action || 'close'}">
                ${button.icon ? `<i class="${button.icon}"></i>` : ''}
                ${button.text}
            </button>`;
        }).join('');
        
        return `<div class="modal-footer">${buttonElements}</div>`;
    }
    
    bindModalEvents(modal, config) {
        const modalId = modal.id;
        
        // Close button
        const closeBtn = modal.querySelector('.modal-close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => this.close(modalId));
        }
        
        // Footer buttons
        modal.querySelectorAll('.modal-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const action = btn.dataset.action;
                this.handleButtonAction(modalId, action, config);
            });
        });
        
        // Draggable functionality
        if (config.draggable) {
            this.makeDraggable(modal);
        }
        
        // Resizable functionality
        if (config.resizable) {
            this.makeResizable(modal);
        }
        
        // Focus management
        modal.addEventListener('keydown', (e) => {
            if (e.key === 'Tab') {
                this.handleTabNavigation(e, modal);
            }
        });
    }
    
    makeDraggable(modal) {
        const header = modal.querySelector('.modal-header');
        const dragHandle = modal.querySelector('.modal-drag-handle') || header;
        
        let isDragging = false;
        let startPos = { x: 0, y: 0 };
        let modalPos = { x: 0, y: 0 };
        
        const onMouseDown = (e) => {
            if (e.target.closest('.modal-close')) return;
            
            isDragging = true;
            startPos = { x: e.clientX, y: e.clientY };
            
            const rect = modal.getBoundingClientRect();
            modalPos = {
                x: rect.left + rect.width / 2 - window.innerWidth / 2,
                y: rect.top + rect.height / 2 - window.innerHeight / 2
            };
            
            modal.style.cursor = 'grabbing';
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        };
        
        const onMouseMove = (e) => {
            if (!isDragging) return;
            
            const deltaX = e.clientX - startPos.x;
            const deltaY = e.clientY - startPos.y;
            
            const newX = modalPos.x + deltaX;
            const newY = modalPos.y + deltaY;
            
            modal.style.transform = `translate(calc(-50% + ${newX}px), calc(-50% + ${newY}px))`;
        };
        
        const onMouseUp = () => {
            isDragging = false;
            modal.style.cursor = '';
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
        
        dragHandle.addEventListener('mousedown', onMouseDown);
        dragHandle.style.cursor = 'grab';
    }
    
    makeResizable(modal) {
        const resizeHandle = modal.querySelector('.modal-resize-handle');
        if (!resizeHandle) return;
        
        let isResizing = false;
        let startSize = { width: 0, height: 0 };
        let startPos = { x: 0, y: 0 };
        
        const onMouseDown = (e) => {
            isResizing = true;
            startPos = { x: e.clientX, y: e.clientY };
            
            const rect = modal.getBoundingClientRect();
            startSize = { width: rect.width, height: rect.height };
            
            document.addEventListener('mousemove', onMouseMove);
            document.addEventListener('mouseup', onMouseUp);
        };
        
        const onMouseMove = (e) => {
            if (!isResizing) return;
            
            const deltaX = e.clientX - startPos.x;
            const deltaY = e.clientY - startPos.y;
            
            const newWidth = Math.max(300, startSize.width + deltaX);
            const newHeight = Math.max(200, startSize.height + deltaY);
            
            modal.style.width = newWidth + 'px';
            modal.style.height = newHeight + 'px';
        };
        
        const onMouseUp = () => {
            isResizing = false;
            document.removeEventListener('mousemove', onMouseMove);
            document.removeEventListener('mouseup', onMouseUp);
        };
        
        resizeHandle.addEventListener('mousedown', onMouseDown);
    }
    
    handleButtonAction(modalId, action, config) {
        switch (action) {
            case 'close':
            case 'cancel':
                if (config.onCancel) {
                    const result = config.onCancel(modalId);
                    if (result !== false) this.close(modalId);
                } else {
                    this.close(modalId);
                }
                break;
                
            case 'confirm':
            case 'save':
                if (config.onConfirm) {
                    const result = config.onConfirm(modalId);
                    if (result !== false) this.close(modalId);
                } else {
                    this.close(modalId);
                }
                break;
                
            default:
                // Custom action
                if (config.onAction) {
                    config.onAction(modalId, action);
                }
                break;
        }
    }
    
    handleTabNavigation(e, modal) {
        const focusableElements = modal.querySelectorAll(
            'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])'
        );
        
        const firstElement = focusableElements[0];
        const lastElement = focusableElements[focusableElements.length - 1];
        
        if (e.shiftKey) {
            if (document.activeElement === firstElement) {
                lastElement.focus();
                e.preventDefault();
            }
        } else {
            if (document.activeElement === lastElement) {
                firstElement.focus();
                e.preventDefault();
            }
        }
    }
    
    // Open modal
    open(id, data = {}) {
        const modalData = this.modals.get(id);
        if (!modalData) {
            console.error(`Modal with id "${id}" not found`);
            return false;
        }
        
        const { element: modal, config } = modalData;
        
        // Update content if data provided
        if (data.title) {
            const titleElement = modal.querySelector('.modal-title');
            if (titleElement) titleElement.textContent = data.title;
        }
        
        if (data.content) {
            const bodyElement = modal.querySelector('.modal-body');
            if (bodyElement) bodyElement.innerHTML = data.content;
        }
        
        // Close current modal if exists
        if (this.activeModal && this.activeModal.id !== id) {
            this.modalStack.push(this.activeModal);
        }
        
        // Show backdrop
        this.backdrop.style.visibility = 'visible';
        this.backdrop.style.opacity = '1';
        
        // Show modal
        modal.style.visibility = 'visible';
        modal.style.opacity = '1';
        modal.style.transform = 'translate(-50%, -50%) scale(1)';
        
        // Update state
        modalData.isOpen = true;
        this.activeModal = { id, element: modal, config };
        
        // Prevent body scroll
        document.body.style.overflow = 'hidden';
        
        // Focus management
        setTimeout(() => {
            const firstFocusable = modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
            if (firstFocusable) firstFocusable.focus();
        }, this.options.animationDuration);
        
        // Call open callback
        if (config.onOpen) {
            config.onOpen(id, data);
        }
        
        // Dispatch event
        modal.dispatchEvent(new CustomEvent('modal:open', { detail: { id, data } }));
        
        return true;
    }
    
    // Close modal
    close(id) {
        const modalData = this.modals.get(id);
        if (!modalData || !modalData.isOpen) return false;
        
        const { element: modal, config } = modalData;
        
        // Hide modal
        modal.style.opacity = '0';
        modal.style.transform = 'translate(-50%, -50%) scale(0.9)';
        
        setTimeout(() => {
            modal.style.visibility = 'hidden';
        }, this.options.animationDuration);
        
        // Update state
        modalData.isOpen = false;
        
        // Handle modal stack
        if (this.modalStack.length > 0) {
            this.activeModal = this.modalStack.pop();
        } else {
            this.activeModal = null;
            
            // Hide backdrop
            this.backdrop.style.opacity = '0';
            setTimeout(() => {
                this.backdrop.style.visibility = 'hidden';
            }, this.options.animationDuration);
            
            // Restore body scroll
            document.body.style.overflow = '';
        }
        
        // Call close callback
        if (config.onClose) {
            config.onClose(id);
        }
        
        // Dispatch event
        modal.dispatchEvent(new CustomEvent('modal:close', { detail: { id } }));
        
        return true;
    }
    
    // Update modal content
    updateContent(id, content) {
        const modalData = this.modals.get(id);
        if (!modalData) return false;
        
        const bodyElement = modalData.element.querySelector('.modal-body');
        if (bodyElement) {
            bodyElement.innerHTML = content;
            return true;
        }
        
        return false;
    }
    
    // Update modal title
    updateTitle(id, title) {
        const modalData = this.modals.get(id);
        if (!modalData) return false;
        
        const titleElement = modalData.element.querySelector('.modal-title');
        if (titleElement) {
            titleElement.textContent = title;
            return true;
        }
        
        return false;
    }
    
    // Check if modal is open
    isOpen(id) {
        const modalData = this.modals.get(id);
        return modalData ? modalData.isOpen : false;
    }
    
    // Get modal element
    getModal(id) {
        const modalData = this.modals.get(id);
        return modalData ? modalData.element : null;
    }
    
    // Destroy modal
    destroy(id) {
        const modalData = this.modals.get(id);
        if (!modalData) return false;
        
        if (modalData.isOpen) {
            this.close(id);
        }
        
        modalData.element.remove();
        this.modals.delete(id);
        
        return true;
    }
    
    // Destroy all modals
    destroyAll() {
        this.modals.forEach((modalData, id) => {
            this.destroy(id);
        });
        
        if (this.backdrop) {
            this.backdrop.remove();
        }
    }
    
    // Predefined modal types
    alert(message, title = 'Alert') {
        const id = 'alert-modal-' + Date.now();
        
        this.create(id, {
            title: title,
            content: `<p>${message}</p>`,
            size: 'small',
            buttons: [
                { text: 'OK', type: 'primary', action: 'close' }
            ]
        });
        
        this.open(id);
        return id;
    }
    
    confirm(message, title = 'Confirm', onConfirm = null, onCancel = null) {
        const id = 'confirm-modal-' + Date.now();
        
        this.create(id, {
            title: title,
            content: `<p>${message}</p>`,
            size: 'small',
            buttons: [
                { text: 'Cancel', type: 'secondary', action: 'cancel' },
                { text: 'Confirm', type: 'primary', action: 'confirm' }
            ],
            onConfirm: onConfirm,
            onCancel: onCancel
        });
        
        this.open(id);
        return id;
    }
    
    prompt(message, defaultValue = '', title = 'Input', onConfirm = null, onCancel = null) {
        const id = 'prompt-modal-' + Date.now();
        
        this.create(id, {
            title: title,
            content: `
                <p>${message}</p>
                <input type="text" id="prompt-input" class="form-control" value="${defaultValue}" style="margin-top: 10px;">
            `,
            size: 'small',
            buttons: [
                { text: 'Cancel', type: 'secondary', action: 'cancel' },
                { text: 'OK', type: 'primary', action: 'confirm' }
            ],
            onConfirm: (modalId) => {
                const input = document.getElementById('prompt-input');
                const value = input ? input.value : '';
                if (onConfirm) return onConfirm(value);
                return true;
            },
            onCancel: onCancel,
            onOpen: () => {
                setTimeout(() => {
                    const input = document.getElementById('prompt-input');
                    if (input) {
                        input.focus();
                        input.select();
                    }
                }, 100);
            }
        });
        
        this.open(id);
        return id;
    }
    
    // Loading modal
    loading(message = 'Loading...', title = 'Please Wait') {
        const id = 'loading-modal-' + Date.now();
        
        this.create(id, {
            title: title,
            content: `
                <div class="loading-content">
                    <div class="loading-spinner">
                        <i class="fas fa-spinner fa-spin fa-2x"></i>
                    </div>
                    <p>${message}</p>
                </div>
            `,
            size: 'small',
            closable: false,
            className: 'loading-modal'
        });
        
        this.open(id);
        return id;
    }
}

// Specific modal creators for the ride history system
class RideHistoryModals extends ModalManager {
    constructor() {
        super();
        this.initRideModals();
    }
    
    initRideModals() {
        // Ride details modal
        this.create('ride-details', {
            title: 'Ride Details',
            size: 'large',
            draggable: true,
            buttons: [
                { text: 'Edit', type: 'secondary', action: 'edit', icon: 'fas fa-edit' },
                { text: 'Rate Driver', type: 'primary', action: 'rate', icon: 'fas fa-star' },
                { text: 'Close', type: 'secondary', action: 'close' }
            ],
            onAction: (modalId, action) => {
                if (action === 'edit') {
                    this.close(modalId);
                    this.openRideForm();
                } else if (action === 'rate') {
                    this.close(modalId);
                    this.openDriverRating();
                }
            }
        });
        
        // Add/Edit ride modal
        this.create('ride-form', {
            title: 'Add New Ride',
            size: 'large',
            buttons: [
                { text: 'Cancel', type: 'secondary', action: 'cancel' },
                { text: 'Save Ride', type: 'primary', action: 'save', icon: 'fas fa-save' }
            ],
            onConfirm: (modalId) => {
                return this.saveRideForm();
            }
        });
        
        // Driver rating modal
        this.create('driver-rating', {
            title: 'Rate Your Driver',
            size: 'medium',
            buttons: [
                { text: 'Cancel', type: 'secondary', action: 'cancel' },
                { text: 'Submit Rating', type: 'primary', action: 'submit', icon: 'fas fa-star' }
            ],
            onConfirm: (modalId) => {
                return this.submitDriverRating();
            }
        });
        
        // Torah quiz modal
        this.create('torah-quiz', {
            title: 'Torah Quiz',
            size: 'large',
            closable: false,
            buttons: [
                { text: 'Skip Question', type: 'secondary', action: 'skip' },
                { text: 'Submit Answer', type: 'primary', action: 'submit' }
            ]
        });
    }
    
    showRideDetails(rideData) {
        const content = this.generateRideDetailsContent(rideData);
        this.updateContent('ride-details', content);
        this.open('ride-details', { rideData });
    }
    
    generateRideDetailsContent(ride) {
        return `
            <div class="ride-details-content">
                <div class="ride-header">
                    <div class="ride-route">
                        <div class="route-point pickup">
                            <i class="fas fa-circle text-success"></i>
                            <div class="route-info">
                                <strong>Pickup</strong>
                                <p>${ride.pickup_location}</p>
                                <small>${new Date(ride.pickup_time || ride.ride_date).toLocaleString()}</small>
                            </div>
                        </div>
                        <div class="route-line"></div>
                        <div class="route-point dropoff">
                            <i class="fas fa-circle text-danger"></i>
                            <div class="route-info">
                                <strong>Dropoff</strong>
                                <p>${ride.dropoff_location}</p>
                                <small>${new Date(ride.dropoff_time || ride.ride_date).toLocaleString()}</small>
                            </div>
                        </div>
                    </div>
                    <div class="ride-status">
                        <span class="status-badge ${ride.ride_status}">${ride.ride_status}</span>
                    </div>
                </div>
                
                <div class="ride-details-grid">
                    <div class="detail-card">
                        <h4><i class="fas fa-road"></i> Trip Details</h4>
                        <div class="detail-row">
                            <span>Distance:</span>
                            <span>${ride.distance_km} km (${ride.distance_miles || (ride.distance_km * 0.621371).toFixed(1)} miles)</span>
                        </div>
                        <div class="detail-row">
                            <span>Duration:</span>
                            <span>${ride.trip_duration_minutes || 'N/A'} minutes</span>
                        </div>
                        <div class="detail-row">
                            <span>Ride Streak:</span>
                            <span>Day ${ride.ride_streak_day}</span>
                        </div>
                    </div>
                    
                    <div class="detail-card">
                        <h4><i class="fas fa-dollar-sign"></i> Payment</h4>
                        <div class="detail-row">
                            <span>Fare:</span>
                            <span>$${ride.fare_amount}</span>
                        </div>
                        <div class="detail-row">
                            <span>Tip:</span>
                            <span>$${ride.tip_amount || 0}</span>
                        </div>
                        <div class="detail-row">
                            <span>Total:</span>
                            <strong>$${ride.total_amount || (parseFloat(ride.fare_amount) + parseFloat(ride.tip_amount || 0)).toFixed(2)}</strong>
                        </div>
                        <div class="detail-row">
                            <span>Method:</span>
                            <span>${ride.payment_method}</span>
                        </div>
                        <div class="detail-row">
                            <span>Status:</span>
                            <span class="status-badge ${ride.payment_status}">${ride.payment_status}</span>
                        </div>
                    </div>
                    
                    <div class="detail-card">
                        <h4><i class="fas fa-user-tie"></i> Driver</h4>
                        <div class="detail-row">
                            <span>Name:</span>
                            <span>${ride.driver_name || 'N/A'}</span>
                        </div>
                        <div class="detail-row">
                            <span>Vehicle:</span>
                            <span>${ride.vehicle_make || ''} ${ride.vehicle_model || ''}</span>
                        </div>
                        <div class="detail-row">
                            <span>License Plate:</span>
                            <span>${ride.license_plate || 'N/A'}</span>
                        </div>
                        <div class="detail-row">
                            <span>Rating:</span>
                            <span>${this.generateStarRating(ride.driver_rating || 0)}</span>
                        </div>
                    </div>
                </div>
                
                ${ride.special_requests ? `
                    <div class="special-requests">
                        <h4><i class="fas fa-comment"></i> Special Requests</h4>
                        <p>${ride.special_requests}</p>
                    </div>
                ` : ''}
            </div>
        `;
    }
    
    generateStarRating(rating) {
        const stars = [];
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        
        for (let i = 0; i < 5; i++) {
            if (i < fullStars) {
                stars.push('<i class="fas fa-star text-warning"></i>');
            } else if (i === fullStars && hasHalfStar) {
                stars.push('<i class="fas fa-star-half-alt text-warning"></i>');
            } else {
                stars.push('<i class="far fa-star text-muted"></i>');
            }
        }
        
        return stars.join('') + ` <span class="rating-value">(${rating.toFixed(1)})</span>`;
    }
    
    openRideForm(rideData = null) {
        const isEdit = !!rideData;
        const title = isEdit ? 'Edit Ride' : 'Add New Ride';
        
        const content = this.generateRideFormContent(rideData);
        
        this.updateTitle('ride-form', title);
        this.updateContent('ride-form', content);
        this.open('ride-form', { rideData, isEdit });
    }
    
    generateRideFormContent(ride = {}) {
        const now = new Date();
        const defaultDate = ride.ride_date ? new Date(ride.ride_date).toISOString().slice(0, 16) : 
                           now.toISOString().slice(0, 16);
        
        return `
            <form id="rideForm" class="ride-form">
                <div class="form-row">
                    <div class="form-group">
                        <label for="pickupLocation">Pickup Location *</label>
                        <input type="text" id="pickupLocation" name="pickup_location" 
                               value="${ride.pickup_location || ''}" required>
                    </div>
                    <div class="form-group">
                        <label for="dropoffLocation">Dropoff Location *</label>
                        <input type="text" id="dropoffLocation" name="dropoff_location" 
                               value="${ride.dropoff_location || ''}" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="rideDate">Date & Time *</label>
                        <input type="datetime-local" id="rideDate" name="ride_date" 
                               value="${defaultDate}" required>
                    </div>
                    <div class="form-group">
                        <label for="distance">Distance (km) *</label>
                        <input type="number" id="distance" name="distance_km" 
                               value="${ride.distance_km || ''}" step="0.1" min="0" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="fareAmount">Fare Amount ($) *</label>
                        <input type="number" id="fareAmount" name="fare_amount" 
                               value="${ride.fare_amount || ''}" step="0.01" min="0" required>
                    </div>
                    <div class="form-group">
                        <label for="tipAmount">Tip Amount ($)</label>
                        <input type="number" id="tipAmount" name="tip_amount" 
                               value="${ride.tip_amount || 0}" step="0.01" min="0">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="paymentMethod">Payment Method *</label>
                        <select id="paymentMethod" name="payment_method" required>
                            <option value="">Select Payment Method</option>
                            <option value="credit_card" ${ride.payment_method === 'credit_card' ? 'selected' : ''}>Credit Card</option>
                            <option value="debit_card" ${ride.payment_method === 'debit_card' ? 'selected' : ''}>Debit Card</option>
                            <option value="cash" ${ride.payment_method === 'cash' ? 'selected' : ''}>Cash</option>
                            <option value="digital_wallet" ${ride.payment_method === 'digital_wallet' ? 'selected' : ''}>Digital Wallet</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="rideStatus">Ride Status</label>
                        <select id="rideStatus" name="ride_status">
                            <option value="completed" ${ride.ride_status === 'completed' ? 'selected' : ''}>Completed</option>
                            <option value="cancelled" ${ride.ride_status === 'cancelled' ? 'selected' : ''}>Cancelled</option>
                            <option value="pending" ${ride.ride_status === 'pending' ? 'selected' : ''}>Pending</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="specialRequests">Special Requests</label>
                    <textarea id="specialRequests" name="special_requests" rows="3"
                              placeholder="Any special requests or notes...">${ride.special_requests || ''}</textarea>
                </div>
                
                <div class="form-group">
                    <label for="driverName">Driver Name</label>
                    <input type="text" id="driverName" name="driver_name"
                           value="${ride.driver_name || ''}" placeholder="Driver's name">
                </div>
            </form>
        `;
    }
    
    saveRideForm() {
        const form = document.getElementById('rideForm');
        if (!form) return false;
        
        const formData = new FormData(form);
        const rideData = {};
        
        for (const [key, value] of formData.entries()) {
            rideData[key] = value;
        }
        
        // Validate required fields
        const requiredFields = ['pickup_location', 'dropoff_location', 'ride_date', 'distance_km', 'fare_amount', 'payment_method'];
        const missingFields = requiredFields.filter(field => !rideData[field]);
        
        if (missingFields.length > 0) {
            this.alert(`Please fill in all required fields: ${missingFields.join(', ')}`);
            return false;
        }
        
        // Calculate total amount
        const fareAmount = parseFloat(rideData.fare_amount) || 0;
        const tipAmount = parseFloat(rideData.tip_amount) || 0;
        rideData.total_amount = (fareAmount + tipAmount).toFixed(2);
        
        // Generate ride ID if new
        if (!rideData.ride_id) {
            rideData.ride_id = 'ride_' + Date.now();
        }
        
        // Dispatch save event
        document.dispatchEvent(new CustomEvent('ride:save', {
            detail: rideData
        }));
        
        return true;
    }
    
    openDriverRating(rideData = null) {
        const content = this.generateDriverRatingContent(rideData);
        this.updateContent('driver-rating', content);
        this.open('driver-rating', { rideData });
    }
    
    generateDriverRatingContent(ride = {}) {
        return `
            <div class="driver-rating-content">
                ${ride.driver_name ? `
                    <div class="driver-info">
                        <div class="driver-avatar">
                            <i class="fas fa-user-circle fa-3x"></i>
                        </div>
                        <div class="driver-details">
                            <h4>${ride.driver_name}</h4>
                            <p>${ride.vehicle_make || ''} ${ride.vehicle_model || ''}</p>
                            <small>License: ${ride.license_plate || 'N/A'}</small>
                        </div>
                    </div>
                ` : ''}
                
                <div class="rating-section">
                    <label>Overall Rating *</label>
                    <div class="star-rating-input" id="starRating">
                        <i class="fas fa-star" data-rating="1"></i>
                        <i class="fas fa-star" data-rating="2"></i>
                        <i class="fas fa-star" data-rating="3"></i>
                        <i class="fas fa-star" data-rating="4"></i>
                        <i class="fas fa-star" data-rating="5"></i>
                    </div>
                    <input type="hidden" id="ratingValue" name="rating" value="0">
                </div>
                
                <div class="feedback-section">
                    <label for="feedbackText">Feedback (Optional)</label>
                    <textarea id="feedbackText" name="feedback_text" rows="4"
                              placeholder="Share your experience with this driver..."></textarea>
                </div>
                
                <div class="rating-options">
                    <label class="checkbox-label">
                        <input type="checkbox" id="anonymousFeedback" name="is_anonymous">
                        Submit feedback anonymously
                    </label>
                </div>
            </div>
        `;
    }
    
    submitDriverRating() {
        const rating = document.getElementById('ratingValue')?.value;
        const feedback = document.getElementById('feedbackText')?.value;
        const isAnonymous = document.getElementById('anonymousFeedback')?.checked;
        
        if (!rating || rating === '0') {
            this.alert('Please select a rating');
            return false;
        }
        
        const ratingData = {
            rating: parseInt(rating),
            feedback_text: feedback,
            is_anonymous: isAnonymous,
            timestamp: new Date().toISOString()
        };
        
        // Dispatch rating event
        document.dispatchEvent(new CustomEvent('driver:rate', {
            detail: ratingData
        }));
        
        return true;
    }
}

// Initialize modal managers
const modalManager = new ModalManager();
const rideModals = new RideHistoryModals();

// Export for global use
window.ModalManager = ModalManager;
window.RideHistoryModals = RideHistoryModals;
window.modalManager = modalManager;
window.rideModals = rideModals;

// Bind star rating functionality
document.addEventListener('click', (e) => {
    if (e.target.matches('.star-rating-input i')) {
        const rating = parseInt(e.target.dataset.rating);
        const container = e.target.parentElement;
        const hiddenInput = container.parentElement.querySelector('input[type="hidden"]');
        
        // Update visual stars
        container.querySelectorAll('i').forEach((star, index) => {
            if (index < rating) {
                star.classList.add('active');
            } else {
                star.classList.remove('active');
            }
        });
        
        // Update hidden input
        if (hiddenInput) {
            hiddenInput.value = rating;
        }
    }
});