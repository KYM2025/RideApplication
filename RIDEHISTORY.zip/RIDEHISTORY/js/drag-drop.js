// Drag and Drop Interface System
class DragDropManager {
    constructor() {
        this.draggedElement = null;
        this.draggedData = null;
        this.dropZones = new Map();
        this.draggableElements = new Map();
        this.dragPreview = null;
        this.dragOffset = { x: 0, y: 0 };
        this.isDragging = false;
        
        this.options = {
            dragThreshold: 5,
            animationDuration: 300,
            ghostOpacity: 0.5,
            snapToGrid: false,
            gridSize: 20,
            autoScroll: true,
            scrollSpeed: 10,
            scrollZone: 50
        };
        
        this.init();
    }
    
    init() {
        this.bindGlobalEvents();
        this.createDragPreview();
    }
    
    bindGlobalEvents() {
        document.addEventListener('dragstart', (e) => e.preventDefault());
        document.addEventListener('selectstart', (e) => {
            if (this.isDragging) e.preventDefault();
        });
        
        // Touch events for mobile support
        document.addEventListener('touchmove', (e) => {
            if (this.isDragging) {
                e.preventDefault();
            }
        }, { passive: false });
        
        // Auto-scroll during drag
        document.addEventListener('mousemove', (e) => {
            if (this.isDragging && this.options.autoScroll) {
                this.handleAutoScroll(e);
            }
        });
    }
    
    createDragPreview() {
        this.dragPreview = document.createElement('div');
        this.dragPreview.className = 'drag-preview';
        this.dragPreview.style.cssText = `
            position: fixed;
            pointer-events: none;
            z-index: 10000;
            opacity: ${this.options.ghostOpacity};
            transform: rotate(5deg);
            transition: none;
            display: none;
        `;
        document.body.appendChild(this.dragPreview);
    }
    
    // Register draggable element
    makeDraggable(element, options = {}) {
        const config = {
            data: options.data || {},
            handle: options.handle || element,
            clone: options.clone !== false,
            revert: options.revert !== false,
            constrainToParent: options.constrainToParent || false,
            onStart: options.onStart || null,
            onDrag: options.onDrag || null,
            onEnd: options.onEnd || null,
            ...options
        };
        
        const handle = typeof config.handle === 'string' 
            ? element.querySelector(config.handle) 
            : config.handle;
        
        if (!handle) return;
        
        // Store configuration
        this.draggableElements.set(element, config);
        
        // Add visual indicators
        element.classList.add('draggable');
        handle.classList.add('drag-handle');
        
        // Bind events
        this.bindDragEvents(element, handle, config);
        
        return element;
    }
    
    bindDragEvents(element, handle, config) {
        let startPos = { x: 0, y: 0 };
        let currentPos = { x: 0, y: 0 };
        let hasMoved = false;
        
        const onStart = (e) => {
            e.preventDefault();
            
            const clientX = e.clientX || (e.touches && e.touches[0].clientX);
            const clientY = e.clientY || (e.touches && e.touches[0].clientY);
            
            startPos = { x: clientX, y: clientY };
            currentPos = { x: clientX, y: clientY };
            hasMoved = false;
            
            // Store drag data
            this.draggedElement = element;
            this.draggedData = config.data;
            
            // Calculate offset from element center
            const rect = element.getBoundingClientRect();
            this.dragOffset = {
                x: clientX - rect.left - rect.width / 2,
                y: clientY - rect.top - rect.height / 2
            };
            
            // Add event listeners
            document.addEventListener('mousemove', onMove);
            document.addEventListener('mouseup', onEnd);
            document.addEventListener('touchmove', onMove, { passive: false });
            document.addEventListener('touchend', onEnd);
            
            // Visual feedback
            element.classList.add('drag-starting');
        };
        
        const onMove = (e) => {
            const clientX = e.clientX || (e.touches && e.touches[0].clientX);
            const clientY = e.clientY || (e.touches && e.touches[0].clientY);
            
            currentPos = { x: clientX, y: clientY };
            
            const deltaX = Math.abs(clientX - startPos.x);
            const deltaY = Math.abs(clientY - startPos.y);
            
            if (!hasMoved && (deltaX > this.options.dragThreshold || deltaY > this.options.dragThreshold)) {
                hasMoved = true;
                this.startDrag(element, config, currentPos);
            }
            
            if (this.isDragging) {
                this.updateDragPosition(currentPos);
                this.checkDropZones(currentPos);
                
                // Call custom drag handler
                if (config.onDrag) {
                    config.onDrag(element, currentPos, this.draggedData);
                }
            }
        };
        
        const onEnd = (e) => {
            document.removeEventListener('mousemove', onMove);
            document.removeEventListener('mouseup', onEnd);
            document.removeEventListener('touchmove', onMove);
            document.removeEventListener('touchend', onEnd);
            
            element.classList.remove('drag-starting');
            
            if (this.isDragging) {
                this.endDrag(currentPos, config);
            }
        };
        
        // Mouse events
        handle.addEventListener('mousedown', onStart);
        
        // Touch events
        handle.addEventListener('touchstart', onStart, { passive: false });
        
        // Prevent default drag behavior
        handle.addEventListener('dragstart', (e) => e.preventDefault());
    }
    
    startDrag(element, config, position) {
        this.isDragging = true;
        
        // Create drag preview
        if (config.clone) {
            const clone = element.cloneNode(true);
            clone.classList.add('drag-clone');
            this.dragPreview.innerHTML = '';
            this.dragPreview.appendChild(clone);
        } else {
            this.dragPreview.innerHTML = element.outerHTML;
        }
        
        // Show preview
        this.dragPreview.style.display = 'block';
        this.updateDragPosition(position);
        
        // Visual feedback
        element.classList.add('dragging');
        document.body.classList.add('dragging-active');
        
        // Highlight drop zones
        this.highlightDropZones();
        
        // Call start handler
        if (config.onStart) {
            config.onStart(element, position, this.draggedData);
        }
        
        // Dispatch custom event
        element.dispatchEvent(new CustomEvent('dragstart', {
            detail: { element, data: this.draggedData, position }
        }));
    }
    
    updateDragPosition(position) {
        if (!this.dragPreview) return;
        
        let x = position.x - this.dragOffset.x;
        let y = position.y - this.dragOffset.y;
        
        // Snap to grid if enabled
        if (this.options.snapToGrid) {
            x = Math.round(x / this.options.gridSize) * this.options.gridSize;
            y = Math.round(y / this.options.gridSize) * this.options.gridSize;
        }
        
        this.dragPreview.style.left = x + 'px';
        this.dragPreview.style.top = y + 'px';
    }
    
    endDrag(position, config) {
        const dropZone = this.getDropZoneAt(position);
        let dropped = false;
        
        if (dropZone) {
            const dropConfig = this.dropZones.get(dropZone);
            if (dropConfig && this.canDrop(dropZone, this.draggedElement, this.draggedData)) {
                dropped = this.performDrop(dropZone, dropConfig);
            }
        }
        
        // Cleanup
        this.isDragging = false;
        this.dragPreview.style.display = 'none';
        this.draggedElement.classList.remove('dragging');
        document.body.classList.remove('dragging-active');
        
        // Remove drop zone highlights
        this.clearDropZoneHighlights();
        
        // Revert if not dropped and revert is enabled
        if (!dropped && config.revert) {
            this.revertDrag();
        }
        
        // Call end handler
        if (config.onEnd) {
            config.onEnd(this.draggedElement, position, this.draggedData, dropped);
        }
        
        // Dispatch custom event
        this.draggedElement.dispatchEvent(new CustomEvent('dragend', {
            detail: { 
                element: this.draggedElement, 
                data: this.draggedData, 
                position, 
                dropped 
            }
        }));
        
        // Reset
        this.draggedElement = null;
        this.draggedData = null;
    }
    
    // Register drop zone
    makeDropZone(element, options = {}) {
        const config = {
            accept: options.accept || '*',
            onDragEnter: options.onDragEnter || null,
            onDragLeave: options.onDragLeave || null,
            onDrop: options.onDrop || null,
            canDrop: options.canDrop || null,
            ...options
        };
        
        this.dropZones.set(element, config);
        element.classList.add('drop-zone');
        
        return element;
    }
    
    highlightDropZones() {
        this.dropZones.forEach((config, element) => {
            if (this.canDrop(element, this.draggedElement, this.draggedData)) {
                element.classList.add('drop-zone-active');
            }
        });
    }
    
    clearDropZoneHighlights() {
        this.dropZones.forEach((config, element) => {
            element.classList.remove('drop-zone-active', 'drop-zone-hover');
        });
    }
    
    checkDropZones(position) {
        const currentDropZone = this.getDropZoneAt(position);
        
        // Update hover states
        this.dropZones.forEach((config, element) => {
            const isHovering = element === currentDropZone;
            const wasHovering = element.classList.contains('drop-zone-hover');
            
            if (isHovering && !wasHovering) {
                element.classList.add('drop-zone-hover');
                if (config.onDragEnter) {
                    config.onDragEnter(element, this.draggedElement, this.draggedData);
                }
            } else if (!isHovering && wasHovering) {
                element.classList.remove('drop-zone-hover');
                if (config.onDragLeave) {
                    config.onDragLeave(element, this.draggedElement, this.draggedData);
                }
            }
        });
    }
    
    getDropZoneAt(position) {
        const elements = document.elementsFromPoint(position.x, position.y);
        
        for (const element of elements) {
            if (this.dropZones.has(element)) {
                return element;
            }
        }
        
        return null;
    }
    
    canDrop(dropZone, draggedElement, draggedData) {
        const config = this.dropZones.get(dropZone);
        if (!config) return false;
        
        // Check accept criteria
        if (config.accept !== '*') {
            if (typeof config.accept === 'string') {
                if (!draggedElement.matches(config.accept)) return false;
            } else if (typeof config.accept === 'function') {
                if (!config.accept(draggedElement, draggedData)) return false;
            } else if (Array.isArray(config.accept)) {
                if (!config.accept.some(selector => draggedElement.matches(selector))) return false;
            }
        }
        
        // Custom canDrop function
        if (config.canDrop) {
            return config.canDrop(dropZone, draggedElement, draggedData);
        }
        
        return true;
    }
    
    performDrop(dropZone, config) {
        try {
            if (config.onDrop) {
                const result = config.onDrop(dropZone, this.draggedElement, this.draggedData);
                if (result === false) return false;
            }
            
            // Dispatch drop event
            dropZone.dispatchEvent(new CustomEvent('drop', {
                detail: {
                    dropZone,
                    draggedElement: this.draggedElement,
                    draggedData: this.draggedData
                }
            }));
            
            return true;
        } catch (error) {
            console.error('Error during drop operation:', error);
            return false;
        }
    }
    
    revertDrag() {
        if (!this.draggedElement) return;
        
        // Animate back to original position
        this.draggedElement.style.transition = `transform ${this.options.animationDuration}ms ease-out`;
        this.draggedElement.style.transform = 'translate(0, 0)';
        
        setTimeout(() => {
            this.draggedElement.style.transition = '';
            this.draggedElement.style.transform = '';
        }, this.options.animationDuration);
    }
    
    handleAutoScroll(e) {
        const { scrollZone, scrollSpeed } = this.options;
        const { clientX, clientY } = e;
        const { innerWidth, innerHeight } = window;
        
        let scrollX = 0;
        let scrollY = 0;
        
        // Horizontal scrolling
        if (clientX < scrollZone) {
            scrollX = -scrollSpeed;
        } else if (clientX > innerWidth - scrollZone) {
            scrollX = scrollSpeed;
        }
        
        // Vertical scrolling
        if (clientY < scrollZone) {
            scrollY = -scrollSpeed;
        } else if (clientY > innerHeight - scrollZone) {
            scrollY = scrollSpeed;
        }
        
        if (scrollX !== 0 || scrollY !== 0) {
            window.scrollBy(scrollX, scrollY);
        }
    }
    
    // Sortable list functionality
    makeSortable(container, options = {}) {
        const config = {
            handle: options.handle || null,
            placeholder: options.placeholder || 'sortable-placeholder',
            onSort: options.onSort || null,
            animation: options.animation !== false,
            ...options
        };
        
        const items = Array.from(container.children);
        
        items.forEach(item => {
            this.makeDraggable(item, {
                handle: config.handle,
                clone: false,
                revert: false,
                onStart: (element) => {
                    this.createSortablePlaceholder(container, element, config.placeholder);
                },
                onDrag: (element, position) => {
                    this.updateSortablePosition(container, element, position);
                },
                onEnd: (element, position, data, dropped) => {
                    this.finalizeSortable(container, element, config);
                }
            });
        });
        
        return container;
    }
    
    createSortablePlaceholder(container, draggedElement, placeholderClass) {
        const placeholder = document.createElement('div');
        placeholder.className = placeholderClass;
        placeholder.style.height = draggedElement.offsetHeight + 'px';
        
        container.insertBefore(placeholder, draggedElement.nextSibling);
        this.sortablePlaceholder = placeholder;
    }
    
    updateSortablePosition(container, draggedElement, position) {
        if (!this.sortablePlaceholder) return;
        
        const items = Array.from(container.children).filter(child => 
            child !== draggedElement && child !== this.sortablePlaceholder
        );
        
        let insertBefore = null;
        
        for (const item of items) {
            const rect = item.getBoundingClientRect();
            const itemCenter = rect.top + rect.height / 2;
            
            if (position.y < itemCenter) {
                insertBefore = item;
                break;
            }
        }
        
        if (insertBefore) {
            container.insertBefore(this.sortablePlaceholder, insertBefore);
        } else {
            container.appendChild(this.sortablePlaceholder);
        }
    }
    
    finalizeSortable(container, draggedElement, config) {
        if (this.sortablePlaceholder) {
            container.insertBefore(draggedElement, this.sortablePlaceholder);
            this.sortablePlaceholder.remove();
            this.sortablePlaceholder = null;
        }
        
        if (config.onSort) {
            const newOrder = Array.from(container.children).map((child, index) => ({
                element: child,
                index: index,
                data: this.draggableElements.get(child)?.data
            }));
            
            config.onSort(newOrder, draggedElement);
        }
    }
    
    // Kanban board functionality
    createKanbanBoard(container, columns, options = {}) {
        const config = {
            cardSelector: '.kanban-card',
            columnSelector: '.kanban-column',
            onMove: options.onMove || null,
            ...options
        };
        
        // Make cards draggable
        container.querySelectorAll(config.cardSelector).forEach(card => {
            this.makeDraggable(card, {
                data: { 
                    id: card.dataset.id,
                    originalColumn: card.closest(config.columnSelector)?.dataset.column
                },
                onStart: () => {
                    container.classList.add('kanban-dragging');
                },
                onEnd: () => {
                    container.classList.remove('kanban-dragging');
                }
            });
        });
        
        // Make columns drop zones
        container.querySelectorAll(config.columnSelector).forEach(column => {
            this.makeDropZone(column, {
                accept: config.cardSelector,
                onDrop: (dropZone, draggedElement, draggedData) => {
                    const newColumn = dropZone.dataset.column;
                    const cardList = dropZone.querySelector('.kanban-card-list');
                    
                    if (cardList) {
                        cardList.appendChild(draggedElement);
                    }
                    
                    if (config.onMove) {
                        config.onMove(draggedElement, draggedData.originalColumn, newColumn);
                    }
                    
                    return true;
                }
            });
        });
        
        return container;
    }
    
    // Dashboard widget rearrangement
    makeDashboardSortable(container, options = {}) {
        const config = {
            widgetSelector: '.dashboard-widget',
            gridColumns: options.gridColumns || 3,
            onRearrange: options.onRearrange || null,
            ...options
        };
        
        const widgets = container.querySelectorAll(config.widgetSelector);
        
        widgets.forEach(widget => {
            this.makeDraggable(widget, {
                handle: '.widget-header',
                data: { 
                    id: widget.dataset.widgetId,
                    originalPosition: Array.from(widgets).indexOf(widget)
                },
                onStart: () => {
                    container.classList.add('dashboard-rearranging');
                    this.createGridPlaceholder(container, widget);
                },
                onDrag: (element, position) => {
                    this.updateGridPosition(container, element, position, config.gridColumns);
                },
                onEnd: () => {
                    container.classList.remove('dashboard-rearranging');
                    this.finalizeGridPosition(container, config);
                }
            });
        });
        
        return container;
    }
    
    createGridPlaceholder(container, widget) {
        const placeholder = document.createElement('div');
        placeholder.className = 'grid-placeholder';
        placeholder.style.cssText = `
            grid-column: span ${widget.style.gridColumn || 1};
            grid-row: span ${widget.style.gridRow || 1};
            background: rgba(44, 90, 160, 0.1);
            border: 2px dashed #2c5aa0;
            border-radius: 8px;
        `;
        
        container.insertBefore(placeholder, widget.nextSibling);
        this.gridPlaceholder = placeholder;
    }
    
    updateGridPosition(container, widget, position, gridColumns) {
        // Calculate grid position based on mouse position
        const containerRect = container.getBoundingClientRect();
        const relativeX = position.x - containerRect.left;
        const relativeY = position.y - containerRect.top;
        
        const columnWidth = containerRect.width / gridColumns;
        const targetColumn = Math.floor(relativeX / columnWidth);
        
        // Find the best insertion point
        const widgets = Array.from(container.children).filter(child => 
            child !== widget && child !== this.gridPlaceholder && 
            child.classList.contains('dashboard-widget')
        );
        
        let insertBefore = null;
        
        for (const otherWidget of widgets) {
            const rect = otherWidget.getBoundingClientRect();
            if (position.y < rect.top + rect.height / 2) {
                insertBefore = otherWidget;
                break;
            }
        }
        
        if (this.gridPlaceholder) {
            if (insertBefore) {
                container.insertBefore(this.gridPlaceholder, insertBefore);
            } else {
                container.appendChild(this.gridPlaceholder);
            }
        }
    }
    
    finalizeGridPosition(container, config) {
        if (this.gridPlaceholder) {
            const widget = this.draggedElement;
            container.insertBefore(widget, this.gridPlaceholder);
            this.gridPlaceholder.remove();
            this.gridPlaceholder = null;
            
            if (config.onRearrange) {
                const newOrder = Array.from(container.children)
                    .filter(child => child.classList.contains('dashboard-widget'))
                    .map((child, index) => ({
                        element: child,
                        id: child.dataset.widgetId,
                        position: index
                    }));
                
                config.onRearrange(newOrder);
            }
        }
    }
    
    // Cleanup
    destroy() {
        this.draggableElements.clear();
        this.dropZones.clear();
        
        if (this.dragPreview) {
            this.dragPreview.remove();
        }
        
        // Clear any active intervals
        this.updateIntervals?.forEach(interval => clearInterval(interval));
    }
}

// Initialize drag and drop manager
const dragDropManager = new DragDropManager();

// Export for global use
window.DragDropManager = DragDropManager;
window.dragDropManager = dragDropManager;