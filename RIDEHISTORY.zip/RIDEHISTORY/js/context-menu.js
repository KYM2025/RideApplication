// Contextual Menu and Hover Effects System
class ContextMenuManager {
    constructor() {
        this.activeMenu = null;
        this.menuConfigs = new Map();
        this.hoverEffects = new Map();
        this.tooltips = new Map();
        this.contextMenuElement = null;
        
        this.options = {
            hideDelay: 300,
            showDelay: 500,
            animationDuration: 200,
            maxWidth: 250,
            zIndex: 10000
        };
        
        this.init();
    }
    
    init() {
        this.createContextMenuElement();
        this.bindGlobalEvents();
    }
    
    createContextMenuElement() {
        this.contextMenuElement = document.createElement('div');
        this.contextMenuElement.className = 'context-menu';
        this.contextMenuElement.style.cssText = `
            position: fixed;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            border: 1px solid #e9ecef;
            padding: 8px 0;
            min-width: 180px;
            max-width: ${this.options.maxWidth}px;
            z-index: ${this.options.zIndex};
            opacity: 0;
            visibility: hidden;
            transform: scale(0.95);
            transition: all ${this.options.animationDuration}ms ease-out;
            font-family: 'Inter', sans-serif;
            font-size: 14px;
        `;
        
        document.body.appendChild(this.contextMenuElement);
    }
    
    bindGlobalEvents() {
        // Hide context menu on click outside
        document.addEventListener('click', (e) => {
            if (this.activeMenu && !this.contextMenuElement.contains(e.target)) {
                this.hideContextMenu();
            }
        });
        
        // Hide context menu on scroll
        document.addEventListener('scroll', () => {
            if (this.activeMenu) {
                this.hideContextMenu();
            }
        });
        
        // Hide context menu on escape
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.activeMenu) {
                this.hideContextMenu();
            }
        });
        
        // Handle window resize
        window.addEventListener('resize', () => {
            if (this.activeMenu) {
                this.hideContextMenu();
            }
        });
    }
    
    // Register context menu for elements
    registerContextMenu(selector, menuItems, options = {}) {
        const config = {
            items: menuItems,
            onShow: options.onShow || null,
            onHide: options.onHide || null,
            onAction: options.onAction || null,
            className: options.className || '',
            ...options
        };
        
        this.menuConfigs.set(selector, config);
        
        // Bind context menu events
        document.addEventListener('contextmenu', (e) => {
            const target = e.target.closest(selector);
            if (target) {
                e.preventDefault();
                this.showContextMenu(e, target, config);
            }
        });
        
        return this;
    }
    
    showContextMenu(event, target, config) {
        // Hide any existing menu
        this.hideContextMenu();
        
        // Generate menu items
        const menuHTML = this.generateMenuHTML(config.items, target);
        this.contextMenuElement.innerHTML = menuHTML;
        
        // Add custom class
        if (config.className) {
            this.contextMenuElement.className = `context-menu ${config.className}`;
        }
        
        // Position menu
        this.positionMenu(event.clientX, event.clientY);
        
        // Show menu
        this.contextMenuElement.style.visibility = 'visible';
        this.contextMenuElement.style.opacity = '1';
        this.contextMenuElement.style.transform = 'scale(1)';
        
        // Store active menu info
        this.activeMenu = {
            target: target,
            config: config,
            event: event
        };
        
        // Bind menu item events
        this.bindMenuEvents(target, config);
        
        // Call onShow callback
        if (config.onShow) {
            config.onShow(target, this.contextMenuElement);
        }
    }
    
    generateMenuHTML(items, target) {
        return items.map(item => {
            if (item.type === 'separator') {
                return '<div class="context-menu-separator"></div>';
            }
            
            // Check if item should be shown
            if (item.condition && !item.condition(target)) {
                return '';
            }
            
            const disabled = item.disabled && item.disabled(target);
            const icon = item.icon ? `<i class="${item.icon}"></i>` : '';
            const shortcut = item.shortcut ? `<span class="shortcut">${item.shortcut}</span>` : '';
            
            return `
                <div class="context-menu-item ${disabled ? 'disabled' : ''} ${item.className || ''}" 
                     data-action="${item.action || ''}"
                     ${item.danger ? 'data-danger="true"' : ''}>
                    ${icon}
                    <span class="menu-text">${item.text}</span>
                    ${shortcut}
                </div>
            `;
        }).join('');
    }
    
    positionMenu(x, y) {
        const menu = this.contextMenuElement;
        const menuRect = menu.getBoundingClientRect();
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        
        let left = x;
        let top = y;
        
        // Adjust horizontal position
        if (left + menuRect.width > windowWidth - 10) {
            left = windowWidth - menuRect.width - 10;
        }
        
        // Adjust vertical position
        if (top + menuRect.height > windowHeight - 10) {
            top = windowHeight - menuRect.height - 10;
        }
        
        // Ensure menu is not off-screen
        left = Math.max(10, left);
        top = Math.max(10, top);
        
        menu.style.left = left + 'px';
        menu.style.top = top + 'px';
    }
    
    bindMenuEvents(target, config) {
        this.contextMenuElement.addEventListener('click', (e) => {
            const menuItem = e.target.closest('.context-menu-item');
            if (!menuItem || menuItem.classList.contains('disabled')) {
                return;
            }
            
            const action = menuItem.dataset.action;
            
            // Call action handler
            if (config.onAction) {
                config.onAction(action, target, this.activeMenu.event);
            }
            
            // Dispatch custom event
            target.dispatchEvent(new CustomEvent('contextmenu:action', {
                detail: {
                    action: action,
                    target: target,
                    originalEvent: this.activeMenu.event
                }
            }));
            
            // Hide menu
            this.hideContextMenu();
        });
        
        // Hover effects for menu items
        this.contextMenuElement.addEventListener('mouseover', (e) => {
            const menuItem = e.target.closest('.context-menu-item');
            if (menuItem && !menuItem.classList.contains('disabled')) {
                menuItem.classList.add('hover');
            }
        });
        
        this.contextMenuElement.addEventListener('mouseout', (e) => {
            const menuItem = e.target.closest('.context-menu-item');
            if (menuItem) {
                menuItem.classList.remove('hover');
            }
        });
    }
    
    hideContextMenu() {
        if (!this.activeMenu) return;
        
        this.contextMenuElement.style.opacity = '0';
        this.contextMenuElement.style.transform = 'scale(0.95)';
        
        setTimeout(() => {
            this.contextMenuElement.style.visibility = 'hidden';
            this.contextMenuElement.className = 'context-menu';
        }, this.options.animationDuration);
        
        // Call onHide callback
        if (this.activeMenu.config.onHide) {
            this.activeMenu.config.onHide(this.activeMenu.target, this.contextMenuElement);
        }
        
        this.activeMenu = null;
    }
    
    // Hover effects system
    registerHoverEffect(selector, options = {}) {
        const config = {
            effect: options.effect || 'scale',
            duration: options.duration || 200,
            scale: options.scale || 1.05,
            translateY: options.translateY || -2,
            shadow: options.shadow || '0 4px 20px rgba(0,0,0,0.15)',
            onHover: options.onHover || null,
            onLeave: options.onLeave || null,
            ...options
        };
        
        this.hoverEffects.set(selector, config);
        
        // Apply hover effects
        document.addEventListener('mouseover', (e) => {
            const target = e.target.closest(selector);
            if (target && !target.hasAttribute('data-hover-applied')) {
                this.applyHoverEffect(target, config);
            }
        });
        
        document.addEventListener('mouseout', (e) => {
            const target = e.target.closest(selector);
            if (target && target.hasAttribute('data-hover-applied')) {
                this.removeHoverEffect(target, config);
            }
        });
        
        return this;
    }
    
    applyHoverEffect(element, config) {
        element.setAttribute('data-hover-applied', 'true');
        
        // Store original styles
        const originalTransform = element.style.transform || '';
        const originalBoxShadow = element.style.boxShadow || '';
        const originalTransition = element.style.transition || '';
        
        element.setAttribute('data-original-transform', originalTransform);
        element.setAttribute('data-original-shadow', originalBoxShadow);
        element.setAttribute('data-original-transition', originalTransition);
        
        // Apply transition
        element.style.transition = `all ${config.duration}ms ease-out`;
        
        // Apply effect based on type
        switch (config.effect) {
            case 'scale':
                element.style.transform = `${originalTransform} scale(${config.scale})`;
                break;
                
            case 'lift':
                element.style.transform = `${originalTransform} translateY(${config.translateY}px)`;
                element.style.boxShadow = config.shadow;
                break;
                
            case 'glow':
                element.style.boxShadow = `0 0 20px ${config.glowColor || 'rgba(44, 90, 160, 0.3)'}`;
                break;
                
            case 'rotate':
                element.style.transform = `${originalTransform} rotate(${config.rotation || 5}deg)`;
                break;
                
            case 'bounce':
                element.style.animation = `bounce ${config.duration}ms ease-out`;
                break;
                
            case 'pulse':
                element.style.animation = `pulse ${config.duration}ms ease-out`;
                break;
        }
        
        // Call hover callback
        if (config.onHover) {
            config.onHover(element);
        }
    }
    
    removeHoverEffect(element, config) {
        element.removeAttribute('data-hover-applied');
        
        // Restore original styles
        const originalTransform = element.getAttribute('data-original-transform') || '';
        const originalBoxShadow = element.getAttribute('data-original-shadow') || '';
        const originalTransition = element.getAttribute('data-original-transition') || '';
        
        element.style.transform = originalTransform;
        element.style.boxShadow = originalBoxShadow;
        element.style.animation = '';
        
        // Restore transition after effect
        setTimeout(() => {
            element.style.transition = originalTransition;
        }, config.duration);
        
        // Clean up attributes
        element.removeAttribute('data-original-transform');
        element.removeAttribute('data-original-shadow');
        element.removeAttribute('data-original-transition');
        
        // Call leave callback
        if (config.onLeave) {
            config.onLeave(element);
        }
    }
    
    // Tooltip system
    registerTooltip(selector, options = {}) {
        const config = {
            content: options.content || '',
            position: options.position || 'top',
            delay: options.delay || this.options.showDelay,
            hideDelay: options.hideDelay || this.options.hideDelay,
            className: options.className || '',
            html: options.html || false,
            ...options
        };
        
        this.tooltips.set(selector, config);
        
        let showTimeout, hideTimeout;
        
        document.addEventListener('mouseover', (e) => {
            const target = e.target.closest(selector);
            if (target) {
                clearTimeout(hideTimeout);
                showTimeout = setTimeout(() => {
                    this.showTooltip(target, config);
                }, config.delay);
            }
        });
        
        document.addEventListener('mouseout', (e) => {
            const target = e.target.closest(selector);
            if (target) {
                clearTimeout(showTimeout);
                hideTimeout = setTimeout(() => {
                    this.hideTooltip(target);
                }, config.hideDelay);
            }
        });
        
        return this;
    }
    
    showTooltip(element, config) {
        // Remove existing tooltip
        this.hideTooltip(element);
        
        // Get tooltip content
        let content = config.content;
        if (typeof content === 'function') {
            content = content(element);
        } else if (!content) {
            content = element.getAttribute('title') || element.getAttribute('data-tooltip') || '';
        }
        
        if (!content) return;
        
        // Create tooltip element
        const tooltip = document.createElement('div');
        tooltip.className = `tooltip ${config.className}`;
        tooltip.style.cssText = `
            position: absolute;
            background: rgba(0, 0, 0, 0.9);
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            font-size: 12px;
            font-family: 'Inter', sans-serif;
            white-space: nowrap;
            z-index: ${this.options.zIndex + 1};
            opacity: 0;
            pointer-events: none;
            transition: opacity ${this.options.animationDuration}ms ease-out;
            max-width: 200px;
        `;
        
        if (config.html) {
            tooltip.innerHTML = content;
        } else {
            tooltip.textContent = content;
        }
        
        document.body.appendChild(tooltip);
        
        // Position tooltip
        this.positionTooltip(tooltip, element, config.position);
        
        // Show tooltip
        requestAnimationFrame(() => {
            tooltip.style.opacity = '1';
        });
        
        // Store reference
        element._tooltip = tooltip;
    }
    
    positionTooltip(tooltip, element, position) {
        const elementRect = element.getBoundingClientRect();
        const tooltipRect = tooltip.getBoundingClientRect();
        const scrollTop = window.pageYOffset;
        const scrollLeft = window.pageXOffset;
        
        let left, top;
        
        switch (position) {
            case 'top':
                left = elementRect.left + scrollLeft + (elementRect.width - tooltipRect.width) / 2;
                top = elementRect.top + scrollTop - tooltipRect.height - 8;
                break;
                
            case 'bottom':
                left = elementRect.left + scrollLeft + (elementRect.width - tooltipRect.width) / 2;
                top = elementRect.bottom + scrollTop + 8;
                break;
                
            case 'left':
                left = elementRect.left + scrollLeft - tooltipRect.width - 8;
                top = elementRect.top + scrollTop + (elementRect.height - tooltipRect.height) / 2;
                break;
                
            case 'right':
                left = elementRect.right + scrollLeft + 8;
                top = elementRect.top + scrollTop + (elementRect.height - tooltipRect.height) / 2;
                break;
        }
        
        // Ensure tooltip stays within viewport
        const windowWidth = window.innerWidth;
        const windowHeight = window.innerHeight;
        
        left = Math.max(10, Math.min(left, windowWidth - tooltipRect.width - 10));
        top = Math.max(10, Math.min(top, windowHeight - tooltipRect.height - 10));
        
        tooltip.style.left = left + 'px';
        tooltip.style.top = top + 'px';
    }
    
    hideTooltip(element) {
        if (element._tooltip) {
            element._tooltip.style.opacity = '0';
            setTimeout(() => {
                if (element._tooltip) {
                    element._tooltip.remove();
                    delete element._tooltip;
                }
            }, this.options.animationDuration);
        }
    }
    
    // Predefined context menus for ride history system
    initRideHistoryContextMenus() {
        // Ride table row context menu
        this.registerContextMenu('.rides-table tbody tr', [
            {
                text: 'View Details',
                icon: 'fas fa-eye',
                action: 'view',
                shortcut: 'Enter'
            },
            {
                text: 'Edit Ride',
                icon: 'fas fa-edit',
                action: 'edit',
                shortcut: 'Ctrl+E'
            },
            {
                text: 'Duplicate Ride',
                icon: 'fas fa-copy',
                action: 'duplicate'
            },
            { type: 'separator' },
            {
                text: 'Rate Driver',
                icon: 'fas fa-star',
                action: 'rate',
                condition: (target) => {
                    const status = target.querySelector('.status-badge')?.textContent;
                    return status === 'completed';
                }
            },
            {
                text: 'Export Ride',
                icon: 'fas fa-download',
                action: 'export'
            },
            { type: 'separator' },
            {
                text: 'Delete Ride',
                icon: 'fas fa-trash',
                action: 'delete',
                danger: true,
                shortcut: 'Del'
            }
        ], {
            onAction: (action, target, event) => {
                const rideId = target.dataset.rideId || target.querySelector('[data-ride-id]')?.dataset.rideId;
                
                switch (action) {
                    case 'view':
                        this.handleViewRide(rideId);
                        break;
                    case 'edit':
                        this.handleEditRide(rideId);
                        break;
                    case 'duplicate':
                        this.handleDuplicateRide(rideId);
                        break;
                    case 'rate':
                        this.handleRateDriver(rideId);
                        break;
                    case 'export':
                        this.handleExportRide(rideId);
                        break;
                    case 'delete':
                        this.handleDeleteRide(rideId);
                        break;
                }
            }
        });
        
        // Dashboard widget context menu
        this.registerContextMenu('.dashboard-widget', [
            {
                text: 'Refresh Widget',
                icon: 'fas fa-sync',
                action: 'refresh'
            },
            {
                text: 'Configure',
                icon: 'fas fa-cog',
                action: 'configure'
            },
            { type: 'separator' },
            {
                text: 'Move Up',
                icon: 'fas fa-arrow-up',
                action: 'move-up'
            },
            {
                text: 'Move Down',
                icon: 'fas fa-arrow-down',
                action: 'move-down'
            },
            { type: 'separator' },
            {
                text: 'Hide Widget',
                icon: 'fas fa-eye-slash',
                action: 'hide'
            }
        ]);
        
        // Chart context menu
        this.registerContextMenu('.chart-container', [
            {
                text: 'Export Chart',
                icon: 'fas fa-download',
                action: 'export-chart'
            },
            {
                text: 'Full Screen',
                icon: 'fas fa-expand',
                action: 'fullscreen'
            },
            { type: 'separator' },
            {
                text: 'Change Chart Type',
                icon: 'fas fa-chart-bar',
                action: 'change-type'
            },
            {
                text: 'Chart Settings',
                icon: 'fas fa-cog',
                action: 'settings'
            }
        ]);
    }
    
    // Action handlers
    handleViewRide(rideId) {
        document.dispatchEvent(new CustomEvent('ride:view', { detail: { rideId } }));
    }
    
    handleEditRide(rideId) {
        document.dispatchEvent(new CustomEvent('ride:edit', { detail: { rideId } }));
    }
    
    handleDuplicateRide(rideId) {
        document.dispatchEvent(new CustomEvent('ride:duplicate', { detail: { rideId } }));
    }
    
    handleRateDriver(rideId) {
        document.dispatchEvent(new CustomEvent('driver:rate', { detail: { rideId } }));
    }
    
    handleExportRide(rideId) {
        document.dispatchEvent(new CustomEvent('ride:export', { detail: { rideId } }));
    }
    
    handleDeleteRide(rideId) {
        if (confirm('Are you sure you want to delete this ride?')) {
            document.dispatchEvent(new CustomEvent('ride:delete', { detail: { rideId } }));
        }
    }
    
    // Initialize hover effects for common elements
    initCommonHoverEffects() {
        // Card hover effects
        this.registerHoverEffect('.stat-card', {
            effect: 'lift',
            duration: 200,
            translateY: -4,
            shadow: '0 8px 25px rgba(0,0,0,0.15)'
        });
        
        // Button hover effects
        this.registerHoverEffect('.btn', {
            effect: 'scale',
            duration: 150,
            scale: 1.02
        });
        
        // Table row hover effects
        this.registerHoverEffect('.rides-table tbody tr', {
            effect: 'glow',
            duration: 200,
            glowColor: 'rgba(44, 90, 160, 0.1)'
        });
        
        // Chart container hover effects
        this.registerHoverEffect('.chart-container', {
            effect: 'lift',
            duration: 300,
            translateY: -2,
            shadow: '0 6px 20px rgba(0,0,0,0.1)'
        });
    }
    
    // Initialize tooltips for common elements
    initCommonTooltips() {
        // Status badges
        this.registerTooltip('.status-badge', {
            content: (element) => {
                const status = element.textContent.toLowerCase();
                const tooltips = {
                    completed: 'Ride completed successfully',
                    pending: 'Ride is pending confirmation',
                    cancelled: 'Ride was cancelled',
                    in_progress: 'Ride is currently in progress'
                };
                return tooltips[status] || status;
            },
            position: 'top'
        });
        
        // Star ratings
        this.registerTooltip('.star-rating', {
            content: (element) => {
                const rating = element.dataset.rating || '0';
                return `Rating: ${rating}/5 stars`;
            },
            position: 'top'
        });
        
        // Action buttons
        this.registerTooltip('[data-tooltip]', {
            content: (element) => element.dataset.tooltip,
            position: 'top'
        });
    }
    
    // Cleanup
    destroy() {
        if (this.contextMenuElement) {
            this.contextMenuElement.remove();
        }
        
        this.menuConfigs.clear();
        this.hoverEffects.clear();
        this.tooltips.clear();
    }
}

// Initialize context menu manager
const contextMenuManager = new ContextMenuManager();

// Initialize predefined menus and effects
contextMenuManager.initRideHistoryContextMenus();
contextMenuManager.initCommonHoverEffects();
contextMenuManager.initCommonTooltips();

// Export for global use
window.ContextMenuManager = ContextMenuManager;
window.contextMenuManager = contextMenuManager;