// Real-time Data Visualization System
class DataVisualizationEngine {
    constructor() {
        this.charts = new Map();
        this.chartConfigs = new Map();
        this.updateIntervals = new Map();
        this.colorPalettes = {
            primary: ['#2c5aa0', '#4a7bc8', '#1e3f73', '#6b8dd6', '#0f2a5a'],
            secondary: ['#d4af37', '#e6c866', '#b8941f', '#f0d975', '#9e7c0d'],
            status: {
                completed: '#28a745',
                pending: '#ffc107',
                cancelled: '#dc3545',
                in_progress: '#17a2b8'
            },
            gradient: [
                'rgba(44, 90, 160, 0.8)',
                'rgba(74, 123, 200, 0.6)',
                'rgba(212, 175, 55, 0.8)',
                'rgba(230, 200, 102, 0.6)'
            ]
        };
        
        this.init();
    }
    
    init() {
        // Set Chart.js global defaults
        Chart.defaults.font.family = 'Inter, sans-serif';
        Chart.defaults.font.size = 12;
        Chart.defaults.color = '#6c757d';
        Chart.defaults.plugins.legend.labels.usePointStyle = true;
        Chart.defaults.plugins.legend.labels.padding = 20;
        Chart.defaults.elements.point.radius = 4;
        Chart.defaults.elements.point.hoverRadius = 6;
        Chart.defaults.elements.line.tension = 0.4;
        Chart.defaults.scale.grid.color = 'rgba(0,0,0,0.05)';
        Chart.defaults.scale.grid.lineWidth = 1;
    }
    
    // Ride Activity Chart
    createRideActivityChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;
        
        const config = {
            type: 'line',
            data: {
                labels: data.labels || [],
                datasets: [{
                    label: 'Daily Rides',
                    data: data.rides || [],
                    borderColor: this.colorPalettes.primary[0],
                    backgroundColor: this.colorPalettes.gradient[0],
                    fill: true,
                    tension: 0.4,
                    pointBackgroundColor: this.colorPalettes.primary[0],
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2
                }, {
                    label: 'Distance (km)',
                    data: data.distance || [],
                    borderColor: this.colorPalettes.secondary[0],
                    backgroundColor: this.colorPalettes.gradient[2],
                    fill: false,
                    tension: 0.4,
                    yAxisID: 'y1',
                    pointBackgroundColor: this.colorPalettes.secondary[0],
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'Ride Activity Over Time',
                        font: { size: 16, weight: 'bold' },
                        color: '#212529'
                    },
                    legend: {
                        position: 'top',
                        align: 'end'
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0,0,0,0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: this.colorPalettes.primary[0],
                        borderWidth: 1,
                        cornerRadius: 8,
                        displayColors: true,
                        callbacks: {
                            title: (context) => {
                                return `Date: ${context[0].label}`;
                            },
                            label: (context) => {
                                const label = context.dataset.label;
                                const value = context.parsed.y;
                                return `${label}: ${label.includes('Distance') ? value + ' km' : value}`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        display: true,
                        title: {
                            display: true,
                            text: 'Date',
                            font: { weight: 'bold' }
                        },
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Number of Rides',
                            font: { weight: 'bold' }
                        },
                        beginAtZero: true
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Distance (km)',
                            font: { weight: 'bold' }
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                        beginAtZero: true
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeInOutQuart'
                },
                ...options
            }
        };
        
        const chart = new Chart(ctx, config);
        this.charts.set(canvasId, chart);
        this.chartConfigs.set(canvasId, config);
        
        return chart;
    }
    
    // Spending Breakdown Chart
    createSpendingChart(canvasId, data, chartType = 'doughnut', options = {}) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;
        
        const config = {
            type: chartType,
            data: {
                labels: data.labels || ['Rides', 'Tips', 'Fees', 'Other'],
                datasets: [{
                    data: data.values || [0, 0, 0, 0],
                    backgroundColor: [
                        this.colorPalettes.primary[0],
                        this.colorPalettes.secondary[0],
                        this.colorPalettes.primary[2],
                        this.colorPalettes.secondary[2]
                    ],
                    borderColor: '#ffffff',
                    borderWidth: 2,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Spending Breakdown',
                        font: { size: 16, weight: 'bold' },
                        color: '#212529'
                    },
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            generateLabels: (chart) => {
                                const data = chart.data;
                                if (data.labels.length && data.datasets.length) {
                                    return data.labels.map((label, i) => {
                                        const value = data.datasets[0].data[i];
                                        const total = data.datasets[0].data.reduce((a, b) => a + b, 0);
                                        const percentage = ((value / total) * 100).toFixed(1);
                                        
                                        return {
                                            text: `${label}: $${value} (${percentage}%)`,
                                            fillStyle: data.datasets[0].backgroundColor[i],
                                            strokeStyle: data.datasets[0].borderColor,
                                            lineWidth: data.datasets[0].borderWidth,
                                            hidden: false,
                                            index: i
                                        };
                                    });
                                }
                                return [];
                            }
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0,0,0,0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: this.colorPalettes.primary[0],
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            label: (context) => {
                                const label = context.label;
                                const value = context.parsed;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `${label}: $${value} (${percentage}%)`;
                            }
                        }
                    }
                },
                animation: {
                    animateRotate: true,
                    animateScale: true,
                    duration: 1000
                },
                ...options
            }
        };
        
        const chart = new Chart(ctx, config);
        this.charts.set(canvasId, chart);
        this.chartConfigs.set(canvasId, config);
        
        return chart;
    }
    
    // Rating Distribution Chart
    createRatingDistributionChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;
        
        const config = {
            type: 'bar',
            data: {
                labels: ['1 Star', '2 Stars', '3 Stars', '4 Stars', '5 Stars'],
                datasets: [{
                    label: 'Number of Ratings',
                    data: data.ratings || [0, 0, 0, 0, 0],
                    backgroundColor: [
                        '#dc3545',
                        '#fd7e14',
                        '#ffc107',
                        '#20c997',
                        '#28a745'
                    ],
                    borderColor: '#ffffff',
                    borderWidth: 1,
                    borderRadius: 4,
                    borderSkipped: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Driver Rating Distribution',
                        font: { size: 16, weight: 'bold' },
                        color: '#212529'
                    },
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0,0,0,0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: this.colorPalettes.primary[0],
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            title: (context) => {
                                return context[0].label;
                            },
                            label: (context) => {
                                const value = context.parsed.y;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = total > 0 ? ((value / total) * 100).toFixed(1) : 0;
                                return `Count: ${value} (${percentage}%)`;
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Rating',
                            font: { weight: 'bold' }
                        },
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Number of Ratings',
                            font: { weight: 'bold' }
                        },
                        beginAtZero: true,
                        ticks: {
                            stepSize: 1
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeInOutQuart'
                },
                ...options
            }
        };
        
        const chart = new Chart(ctx, config);
        this.charts.set(canvasId, chart);
        this.chartConfigs.set(canvasId, config);
        
        return chart;
    }
    
    // Peak Hours Chart
    createPeakHoursChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;
        
        const config = {
            type: 'radar',
            data: {
                labels: data.hours || ['12 AM', '3 AM', '6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'],
                datasets: [{
                    label: 'Ride Frequency',
                    data: data.frequency || [0, 0, 0, 0, 0, 0, 0, 0],
                    borderColor: this.colorPalettes.primary[0],
                    backgroundColor: this.colorPalettes.gradient[0],
                    pointBackgroundColor: this.colorPalettes.primary[0],
                    pointBorderColor: '#ffffff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    pointHoverRadius: 6
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Peak Hours Analysis',
                        font: { size: 16, weight: 'bold' },
                        color: '#212529'
                    },
                    legend: {
                        display: false
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0,0,0,0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: this.colorPalettes.primary[0],
                        borderWidth: 1,
                        cornerRadius: 8
                    }
                },
                scales: {
                    r: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        },
                        pointLabels: {
                            font: {
                                size: 11
                            }
                        },
                        ticks: {
                            display: false
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeInOutQuart'
                },
                ...options
            }
        };
        
        const chart = new Chart(ctx, config);
        this.charts.set(canvasId, chart);
        this.chartConfigs.set(canvasId, config);
        
        return chart;
    }
    
    // Monthly Trends Chart
    createMonthlyTrendsChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;
        
        const config = {
            type: 'line',
            data: {
                labels: data.months || [],
                datasets: [{
                    label: 'Total Rides',
                    data: data.rides || [],
                    borderColor: this.colorPalettes.primary[0],
                    backgroundColor: this.colorPalettes.gradient[0],
                    fill: false,
                    tension: 0.4
                }, {
                    label: 'Total Spending',
                    data: data.spending || [],
                    borderColor: this.colorPalettes.secondary[0],
                    backgroundColor: this.colorPalettes.gradient[2],
                    fill: false,
                    tension: 0.4,
                    yAxisID: 'y1'
                }, {
                    label: 'Average Rating',
                    data: data.ratings || [],
                    borderColor: this.colorPalettes.primary[2],
                    backgroundColor: this.colorPalettes.gradient[1],
                    fill: false,
                    tension: 0.4,
                    yAxisID: 'y2'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                plugins: {
                    title: {
                        display: true,
                        text: 'Monthly Trends Analysis',
                        font: { size: 16, weight: 'bold' },
                        color: '#212529'
                    },
                    legend: {
                        position: 'top',
                        align: 'end'
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0,0,0,0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: this.colorPalettes.primary[0],
                        borderWidth: 1,
                        cornerRadius: 8
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Month',
                            font: { weight: 'bold' }
                        },
                        grid: {
                            display: false
                        }
                    },
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Rides',
                            font: { weight: 'bold' }
                        },
                        beginAtZero: true
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'Spending ($)',
                            font: { weight: 'bold' }
                        },
                        grid: {
                            drawOnChartArea: false,
                        },
                        beginAtZero: true
                    },
                    y2: {
                        type: 'linear',
                        display: false,
                        min: 1,
                        max: 5
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeInOutQuart'
                },
                ...options
            }
        };
        
        const chart = new Chart(ctx, config);
        this.charts.set(canvasId, chart);
        this.chartConfigs.set(canvasId, config);
        
        return chart;
    }
    
    // Torah Quiz Progress Chart
    createTorahQuizChart(canvasId, data, options = {}) {
        const ctx = document.getElementById(canvasId);
        if (!ctx) return null;
        
        const config = {
            type: 'polarArea',
            data: {
                labels: data.categories || [],
                datasets: [{
                    data: data.scores || [],
                    backgroundColor: [
                        'rgba(44, 90, 160, 0.7)',
                        'rgba(212, 175, 55, 0.7)',
                        'rgba(74, 123, 200, 0.7)',
                        'rgba(230, 200, 102, 0.7)',
                        'rgba(30, 63, 115, 0.7)'
                    ],
                    borderColor: [
                        '#2c5aa0',
                        '#d4af37',
                        '#4a7bc8',
                        '#e6c866',
                        '#1e3f73'
                    ],
                    borderWidth: 2
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    title: {
                        display: true,
                        text: 'Torah Quiz Performance by Category',
                        font: { size: 16, weight: 'bold' },
                        color: '#212529'
                    },
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0,0,0,0.8)',
                        titleColor: '#ffffff',
                        bodyColor: '#ffffff',
                        borderColor: this.colorPalettes.primary[0],
                        borderWidth: 1,
                        cornerRadius: 8,
                        callbacks: {
                            label: (context) => {
                                const label = context.label;
                                const value = context.parsed.r;
                                return `${label}: ${value}% accuracy`;
                            }
                        }
                    }
                },
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            stepSize: 20,
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeInOutQuart'
                },
                ...options
            }
        };
        
        const chart = new Chart(ctx, config);
        this.charts.set(canvasId, chart);
        this.chartConfigs.set(canvasId, config);
        
        return chart;
    }
    
    // Update chart data
    updateChart(canvasId, newData) {
        const chart = this.charts.get(canvasId);
        if (!chart) return false;
        
        // Update data
        if (newData.labels) {
            chart.data.labels = newData.labels;
        }
        
        if (newData.datasets) {
            newData.datasets.forEach((dataset, index) => {
                if (chart.data.datasets[index]) {
                    Object.assign(chart.data.datasets[index], dataset);
                }
            });
        }
        
        // Animate the update
        chart.update('active');
        return true;
    }
    
    // Real-time updates
    startRealTimeUpdates(canvasId, updateFunction, interval = 30000) {
        if (this.updateIntervals.has(canvasId)) {
            clearInterval(this.updateIntervals.get(canvasId));
        }
        
        const intervalId = setInterval(async () => {
            try {
                const newData = await updateFunction();
                this.updateChart(canvasId, newData);
            } catch (error) {
                console.error(`Error updating chart ${canvasId}:`, error);
            }
        }, interval);
        
        this.updateIntervals.set(canvasId, intervalId);
    }
    
    stopRealTimeUpdates(canvasId) {
        if (this.updateIntervals.has(canvasId)) {
            clearInterval(this.updateIntervals.get(canvasId));
            this.updateIntervals.delete(canvasId);
        }
    }
    
    // Export chart as image
    exportChart(canvasId, filename, format = 'png') {
        const chart = this.charts.get(canvasId);
        if (!chart) return false;
        
        const url = chart.toBase64Image();
        const link = document.createElement('a');
        link.download = `${filename}.${format}`;
        link.href = url;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        return true;
    }
    
    // Resize chart
    resizeChart(canvasId) {
        const chart = this.charts.get(canvasId);
        if (chart) {
            chart.resize();
        }
    }
    
    // Destroy chart
    destroyChart(canvasId) {
        const chart = this.charts.get(canvasId);
        if (chart) {
            chart.destroy();
            this.charts.delete(canvasId);
            this.chartConfigs.delete(canvasId);
        }
        
        this.stopRealTimeUpdates(canvasId);
    }
    
    // Destroy all charts
    destroyAllCharts() {
        this.charts.forEach((chart, canvasId) => {
            this.destroyChart(canvasId);
        });
    }
    
    // Get chart instance
    getChart(canvasId) {
        return this.charts.get(canvasId);
    }
    
    // Change chart type
    changeChartType(canvasId, newType) {
        const chart = this.charts.get(canvasId);
        const config = this.chartConfigs.get(canvasId);
        
        if (!chart || !config) return false;
        
        // Destroy current chart
        chart.destroy();
        
        // Update config
        config.type = newType;
        
        // Create new chart
        const ctx = document.getElementById(canvasId);
        const newChart = new Chart(ctx, config);
        
        this.charts.set(canvasId, newChart);
        
        return true;
    }
    
    // Generate sample data for testing
    generateSampleData() {
        const now = new Date();
        const days = [];
        const rides = [];
        const distance = [];
        
        for (let i = 29; i >= 0; i--) {
            const date = new Date(now);
            date.setDate(date.getDate() - i);
            days.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            rides.push(Math.floor(Math.random() * 10) + 1);
            distance.push(Math.floor(Math.random() * 50) + 10);
        }
        
        return {
            rideActivity: {
                labels: days,
                rides: rides,
                distance: distance
            },
            spending: {
                labels: ['Rides', 'Tips', 'Fees', 'Other'],
                values: [450, 75, 25, 15]
            },
            ratings: {
                ratings: [2, 5, 12, 45, 78]
            },
            peakHours: {
                hours: ['12 AM', '3 AM', '6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'],
                frequency: [5, 2, 8, 25, 30, 35, 45, 20]
            },
            monthlyTrends: {
                months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                rides: [45, 52, 48, 61, 55, 67],
                spending: [680, 780, 720, 915, 825, 1005],
                ratings: [4.2, 4.3, 4.1, 4.5, 4.4, 4.6]
            },
            torahQuiz: {
                categories: ['Torah', 'Talmud', 'Halacha', 'History', 'Philosophy'],
                scores: [85, 92, 78, 88, 95]
            }
        };
    }
}

// Initialize the visualization engine
const dataViz = new DataVisualizationEngine();

// Export for global use
window.DataVisualizationEngine = DataVisualizationEngine;
window.dataViz = dataViz;