// Data Export System
class DataExportManager {
    constructor() {
        this.exportFormats = ['csv', 'json', 'pdf', 'excel'];
        this.exportQueue = [];
        this.isExporting = false;
        
        this.options = {
            dateFormat: 'YYYY-MM-DD',
            csvDelimiter: ',',
            csvEncoding: 'utf-8',
            pdfPageSize: 'A4',
            pdfOrientation: 'portrait',
            maxRowsPerExport: 10000,
            chunkSize: 1000
        };
        
        this.init();
    }
    
    init() {
        this.bindExportEvents();
        this.createExportModal();
    }
    
    bindExportEvents() {
        // Listen for export events
        document.addEventListener('data:export', (e) => {
            const { data, format, filename, options } = e.detail;
            this.exportData(data, format, filename, options);
        });
        
        // Bind export buttons
        document.addEventListener('click', (e) => {
            if (e.target.matches('[data-export]')) {
                const format = e.target.dataset.export;
                const dataSource = e.target.dataset.source || 'rides';
                this.showExportDialog(dataSource, format);
            }
        });
    }
    
    createExportModal() {
        const modal = document.createElement('div');
        modal.id = 'exportModal';
        modal.className = 'modal';
        modal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Export Data</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="export-options">
                        <div class="form-group">
                            <label>Data Source:</label>
                            <select id="exportDataSource">
                                <option value="rides">Ride History</option>
                                <option value="drivers">Driver Information</option>
                                <option value="feedback">Driver Feedback</option>
                                <option value="notifications">Notifications</option>
                                <option value="torah_quiz">Torah Quiz Progress</option>
                                <option value="all">All Data</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <label>Export Format:</label>
                            <div class="format-options">
                                <label class="radio-option">
                                    <input type="radio" name="exportFormat" value="csv" checked>
                                    <span class="format-icon"><i class="fas fa-file-csv"></i></span>
                                    <span>CSV</span>
                                </label>
                                <label class="radio-option">
                                    <input type="radio" name="exportFormat" value="json">
                                    <span class="format-icon"><i class="fas fa-file-code"></i></span>
                                    <span>JSON</span>
                                </label>
                                <label class="radio-option">
                                    <input type="radio" name="exportFormat" value="pdf">
                                    <span class="format-icon"><i class="fas fa-file-pdf"></i></span>
                                    <span>PDF</span>
                                </label>
                                <label class="radio-option">
                                    <input type="radio" name="exportFormat" value="excel">
                                    <span class="format-icon"><i class="fas fa-file-excel"></i></span>
                                    <span>Excel</span>
                                </label>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Date Range:</label>
                            <div class="date-range">
                                <input type="date" id="exportDateFrom" placeholder="From">
                                <input type="date" id="exportDateTo" placeholder="To">
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label>Filename:</label>
                            <input type="text" id="exportFilename" placeholder="Enter filename">
                        </div>
                        
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="includeHeaders" checked>
                                Include column headers
                            </label>
                        </div>
                        
                        <div class="form-group">
                            <label>
                                <input type="checkbox" id="compressExport">
                                Compress export (ZIP)
                            </label>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn secondary" id="cancelExport">Cancel</button>
                    <button class="btn primary" id="startExport">
                        <i class="fas fa-download"></i>
                        Export Data
                    </button>
                </div>
            </div>
        `;
        
        document.body.appendChild(modal);
        this.bindModalEvents();
    }
    
    bindModalEvents() {
        const modal = document.getElementById('exportModal');
        const closeBtn = modal.querySelector('.modal-close');
        const cancelBtn = modal.querySelector('#cancelExport');
        const exportBtn = modal.querySelector('#startExport');
        
        closeBtn.addEventListener('click', () => this.hideExportModal());
        cancelBtn.addEventListener('click', () => this.hideExportModal());
        exportBtn.addEventListener('click', () => this.processExport());
        
        // Update filename based on selections
        const dataSourceSelect = modal.querySelector('#exportDataSource');
        const formatRadios = modal.querySelectorAll('input[name="exportFormat"]');
        const filenameInput = modal.querySelector('#exportFilename');
        
        const updateFilename = () => {
            const dataSource = dataSourceSelect.value;
            const format = modal.querySelector('input[name="exportFormat"]:checked').value;
            const timestamp = new Date().toISOString().split('T')[0];
            filenameInput.value = `${dataSource}_export_${timestamp}`;
        };
        
        dataSourceSelect.addEventListener('change', updateFilename);
        formatRadios.forEach(radio => radio.addEventListener('change', updateFilename));
        
        // Initialize filename
        updateFilename();
    }
    
    showExportDialog(dataSource = 'rides', format = 'csv') {
        const modal = document.getElementById('exportModal');
        const dataSourceSelect = modal.querySelector('#exportDataSource');
        const formatRadio = modal.querySelector(`input[name="exportFormat"][value="${format}"]`);
        
        dataSourceSelect.value = dataSource;
        if (formatRadio) formatRadio.checked = true;
        
        modal.classList.add('active');
    }
    
    hideExportModal() {
        const modal = document.getElementById('exportModal');
        modal.classList.remove('active');
    }
    
    async processExport() {
        const modal = document.getElementById('exportModal');
        const dataSource = modal.querySelector('#exportDataSource').value;
        const format = modal.querySelector('input[name="exportFormat"]:checked').value;
        const filename = modal.querySelector('#exportFilename').value;
        const dateFrom = modal.querySelector('#exportDateFrom').value;
        const dateTo = modal.querySelector('#exportDateTo').value;
        const includeHeaders = modal.querySelector('#includeHeaders').checked;
        const compress = modal.querySelector('#compressExport').checked;
        
        const options = {
            dateFrom,
            dateTo,
            includeHeaders,
            compress
        };
        
        this.hideExportModal();
        
        try {
            const data = await this.fetchExportData(dataSource, options);
            await this.exportData(data, format, filename, options);
        } catch (error) {
            console.error('Export failed:', error);
            this.showExportError(error.message);
        }
    }
    
    async fetchExportData(dataSource, options = {}) {
        // This would typically fetch from your data service
        // For now, we'll simulate with sample data
        
        const sampleData = this.generateSampleData(dataSource);
        
        // Apply date filtering if specified
        if (options.dateFrom || options.dateTo) {
            return this.filterDataByDate(sampleData, options.dateFrom, options.dateTo);
        }
        
        return sampleData;
    }
    
    generateSampleData(dataSource) {
        switch (dataSource) {
            case 'rides':
                return this.generateSampleRides();
            case 'drivers':
                return this.generateSampleDrivers();
            case 'feedback':
                return this.generateSampleFeedback();
            case 'notifications':
                return this.generateSampleNotifications();
            case 'torah_quiz':
                return this.generateSampleQuizData();
            case 'all':
                return {
                    rides: this.generateSampleRides(),
                    drivers: this.generateSampleDrivers(),
                    feedback: this.generateSampleFeedback(),
                    notifications: this.generateSampleNotifications(),
                    torah_quiz: this.generateSampleQuizData()
                };
            default:
                return [];
        }
    }
    
    generateSampleRides() {
        const rides = [];
        const locations = [
            'Downtown Seattle', 'Capitol Hill', 'Fremont', 'Ballard', 'Queen Anne',
            'University District', 'Georgetown', 'Beacon Hill', 'West Seattle'
        ];
        
        for (let i = 0; i < 50; i++) {
            const date = new Date();
            date.setDate(date.getDate() - Math.floor(Math.random() * 90));
            
            rides.push({
                ride_id: `ride_${i + 1}`,
                user_id: `user_${Math.floor(Math.random() * 10) + 1}`,
                driver_id: `driver_${Math.floor(Math.random() * 20) + 1}`,
                pickup_location: locations[Math.floor(Math.random() * locations.length)],
                dropoff_location: locations[Math.floor(Math.random() * locations.length)],
                distance_km: (Math.random() * 50 + 1).toFixed(1),
                fare_amount: (Math.random() * 80 + 10).toFixed(2),
                tip_amount: (Math.random() * 15).toFixed(2),
                total_amount: 0, // Will be calculated
                payment_method: ['credit_card', 'debit_card', 'cash', 'digital_wallet'][Math.floor(Math.random() * 4)],
                ride_date: date.toISOString(),
                ride_status: ['completed', 'cancelled', 'pending'][Math.floor(Math.random() * 3)],
                ride_streak_day: Math.floor(Math.random() * 30) + 1
            });
        }
        
        // Calculate total amounts
        rides.forEach(ride => {
            ride.total_amount = (parseFloat(ride.fare_amount) + parseFloat(ride.tip_amount)).toFixed(2);
        });
        
        return rides;
    }
    
    generateSampleDrivers() {
        const drivers = [];
        const names = ['John Smith', 'Sarah Johnson', 'Mike Davis', 'Lisa Wilson', 'David Brown'];
        const vehicles = [
            { make: 'Toyota', model: 'Camry' },
            { make: 'Honda', model: 'Accord' },
            { make: 'Ford', model: 'Fusion' },
            { make: 'Nissan', model: 'Altima' },
            { make: 'Chevrolet', model: 'Malibu' }
        ];
        
        for (let i = 0; i < 20; i++) {
            const vehicle = vehicles[Math.floor(Math.random() * vehicles.length)];
            drivers.push({
                driver_id: `driver_${i + 1}`,
                name: names[Math.floor(Math.random() * names.length)],
                vehicle_make: vehicle.make,
                vehicle_model: vehicle.model,
                license_plate: `ABC${Math.floor(Math.random() * 1000).toString().padStart(3, '0')}`,
                average_rating: (Math.random() * 2 + 3).toFixed(1),
                total_trips: Math.floor(Math.random() * 500) + 50,
                created_at: new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString()
            });
        }
        
        return drivers;
    }
    
    generateSampleFeedback() {
        const feedback = [];
        const comments = [
            'Great driver, very professional',
            'Clean car and safe driving',
            'Arrived on time, friendly service',
            'Could improve communication',
            'Excellent experience overall'
        ];
        
        for (let i = 0; i < 30; i++) {
            feedback.push({
                feedback_id: `feedback_${i + 1}`,
                ride_id: `ride_${Math.floor(Math.random() * 50) + 1}`,
                driver_id: `driver_${Math.floor(Math.random() * 20) + 1}`,
                rating: Math.floor(Math.random() * 5) + 1,
                feedback_text: comments[Math.floor(Math.random() * comments.length)],
                sentiment_score: (Math.random() * 2 - 1).toFixed(3),
                timestamp: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString()
            });
        }
        
        return feedback;
    }
    
    generateSampleNotifications() {
        const notifications = [];
        const types = ['ride_completed', 'driver_rated', 'quiz_available', 'system_update'];
        const titles = [
            'Ride Completed',
            'Rate Your Driver',
            'New Torah Quiz Available',
            'System Update'
        ];
        
        for (let i = 0; i < 25; i++) {
            const type = types[Math.floor(Math.random() * types.length)];
            notifications.push({
                notification_id: `notif_${i + 1}`,
                user_id: `user_${Math.floor(Math.random() * 10) + 1}`,
                type: type,
                title: titles[types.indexOf(type)],
                message: `This is a sample notification message for ${type}`,
                timestamp: new Date(Date.now() - Math.random() * 7 * 24 * 60 * 60 * 1000).toISOString(),
                is_read: Math.random() > 0.3
            });
        }
        
        return notifications;
    }
    
    generateSampleQuizData() {
        const quizData = [];
        const categories = ['Torah', 'Talmud', 'Halacha', 'History', 'Philosophy'];
        
        for (let i = 0; i < 40; i++) {
            quizData.push({
                progress_id: `progress_${i + 1}`,
                user_id: `user_${Math.floor(Math.random() * 10) + 1}`,
                question_id: `question_${Math.floor(Math.random() * 100) + 1}`,
                category: categories[Math.floor(Math.random() * categories.length)],
                user_answer: ['A', 'B', 'C', 'D'][Math.floor(Math.random() * 4)],
                correct_answer: ['A', 'B', 'C', 'D'][Math.floor(Math.random() * 4)],
                is_correct: Math.random() > 0.3,
                timestamp: new Date(Date.now() - Math.random() * 60 * 24 * 60 * 60 * 1000).toISOString(),
                streak_count: Math.floor(Math.random() * 20)
            });
        }
        
        return quizData;
    }
    
    filterDataByDate(data, dateFrom, dateTo) {
        if (!dateFrom && !dateTo) return data;
        
        const fromDate = dateFrom ? new Date(dateFrom) : new Date(0);
        const toDate = dateTo ? new Date(dateTo) : new Date();
        
        if (Array.isArray(data)) {
            return data.filter(item => {
                const itemDate = new Date(item.ride_date || item.timestamp || item.created_at);
                return itemDate >= fromDate && itemDate <= toDate;
            });
        } else if (typeof data === 'object') {
            const filtered = {};
            Object.keys(data).forEach(key => {
                filtered[key] = this.filterDataByDate(data[key], dateFrom, dateTo);
            });
            return filtered;
        }
        
        return data;
    }
    
    async exportData(data, format, filename, options = {}) {
        this.showExportProgress();
        
        try {
            switch (format) {
                case 'csv':
                    await this.exportToCSV(data, filename, options);
                    break;
                case 'json':
                    await this.exportToJSON(data, filename, options);
                    break;
                case 'pdf':
                    await this.exportToPDF(data, filename, options);
                    break;
                case 'excel':
                    await this.exportToExcel(data, filename, options);
                    break;
                default:
                    throw new Error(`Unsupported export format: ${format}`);
            }
            
            this.hideExportProgress();
            this.showExportSuccess(filename, format);
        } catch (error) {
            this.hideExportProgress();
            throw error;
        }
    }
    
    async exportToCSV(data, filename, options = {}) {
        let csvContent = '';
        
        if (Array.isArray(data) && data.length > 0) {
            // Single dataset
            csvContent = this.arrayToCSV(data, options.includeHeaders);
        } else if (typeof data === 'object') {
            // Multiple datasets
            Object.keys(data).forEach(key => {
                if (Array.isArray(data[key]) && data[key].length > 0) {
                    csvContent += `\n# ${key.toUpperCase()}\n`;
                    csvContent += this.arrayToCSV(data[key], options.includeHeaders);
                    csvContent += '\n';
                }
            });
        }
        
        if (options.compress) {
            await this.downloadCompressed(csvContent, `${filename}.csv`, 'text/csv');
        } else {
            this.downloadFile(csvContent, `${filename}.csv`, 'text/csv');
        }
    }
    
    arrayToCSV(array, includeHeaders = true) {
        if (!array || array.length === 0) return '';
        
        const headers = Object.keys(array[0]);
        let csv = '';
        
        if (includeHeaders) {
            csv += headers.map(header => this.escapeCSVField(header)).join(this.options.csvDelimiter) + '\n';
        }
        
        array.forEach(row => {
            const values = headers.map(header => {
                const value = row[header];
                return this.escapeCSVField(value);
            });
            csv += values.join(this.options.csvDelimiter) + '\n';
        });
        
        return csv;
    }
    
    escapeCSVField(field) {
        if (field === null || field === undefined) return '';
        
        const stringField = String(field);
        
        // If field contains delimiter, newline, or quote, wrap in quotes and escape quotes
        if (stringField.includes(this.options.csvDelimiter) || 
            stringField.includes('\n') || 
            stringField.includes('"')) {
            return '"' + stringField.replace(/"/g, '""') + '"';
        }
        
        return stringField;
    }
    
    async exportToJSON(data, filename, options = {}) {
        const jsonContent = JSON.stringify(data, null, 2);
        
        if (options.compress) {
            await this.downloadCompressed(jsonContent, `${filename}.json`, 'application/json');
        } else {
            this.downloadFile(jsonContent, `${filename}.json`, 'application/json');
        }
    }
    
    async exportToPDF(data, filename, options = {}) {
        // This would require a PDF library like jsPDF
        // For demonstration, we'll create a simple HTML-to-PDF approach
        
        const htmlContent = this.generatePDFHTML(data, filename);
        
        // Create a new window for printing
        const printWindow = window.open('', '_blank');
        printWindow.document.write(htmlContent);
        printWindow.document.close();
        
        // Trigger print dialog
        printWindow.onload = () => {
            printWindow.print();
            setTimeout(() => printWindow.close(), 1000);
        };
    }
    
    generatePDFHTML(data, filename) {
        let html = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>${filename}</title>
                <style>
                    body { font-family: Arial, sans-serif; margin: 20px; }
                    h1 { color: #2c5aa0; border-bottom: 2px solid #2c5aa0; padding-bottom: 10px; }
                    h2 { color: #4a7bc8; margin-top: 30px; }
                    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                    th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
                    th { background-color: #f8f9fa; font-weight: bold; }
                    tr:nth-child(even) { background-color: #f9f9f9; }
                    .export-info { margin-bottom: 30px; padding: 15px; background: #e9ecef; border-radius: 5px; }
                    @media print {
                        body { margin: 0; }
                        .no-print { display: none; }
                    }
                </style>
            </head>
            <body>
                <h1>Straight-Way Rideshare Data Export</h1>
                <div class="export-info">
                    <strong>Export Date:</strong> ${new Date().toLocaleString()}<br>
                    <strong>Filename:</strong> ${filename}<br>
                    <strong>Total Records:</strong> ${this.countRecords(data)}
                </div>
        `;
        
        if (Array.isArray(data)) {
            html += this.generateTableHTML(data, 'Data');
        } else if (typeof data === 'object') {
            Object.keys(data).forEach(key => {
                if (Array.isArray(data[key]) && data[key].length > 0) {
                    html += `<h2>${key.charAt(0).toUpperCase() + key.slice(1)}</h2>`;
                    html += this.generateTableHTML(data[key], key);
                }
            });
        }
        
        html += `
            </body>
            </html>
        `;
        
        return html;
    }
    
    generateTableHTML(array, title) {
        if (!array || array.length === 0) return '';
        
        const headers = Object.keys(array[0]);
        
        let html = '<table>';
        html += '<thead><tr>';
        headers.forEach(header => {
            html += `<th>${header.replace(/_/g, ' ').toUpperCase()}</th>`;
        });
        html += '</tr></thead>';
        
        html += '<tbody>';
        array.forEach(row => {
            html += '<tr>';
            headers.forEach(header => {
                const value = row[header];
                html += `<td>${this.formatCellValue(value)}</td>`;
            });
            html += '</tr>';
        });
        html += '</tbody>';
        
        html += '</table>';
        
        return html;
    }
    
    formatCellValue(value) {
        if (value === null || value === undefined) return '';
        
        // Format dates
        if (typeof value === 'string' && value.match(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/)) {
            return new Date(value).toLocaleString();
        }
        
        // Format numbers
        if (typeof value === 'number') {
            return value.toLocaleString();
        }
        
        return String(value);
    }
    
    countRecords(data) {
        if (Array.isArray(data)) {
            return data.length;
        } else if (typeof data === 'object') {
            return Object.keys(data).reduce((total, key) => {
                return total + (Array.isArray(data[key]) ? data[key].length : 0);
            }, 0);
        }
        return 0;
    }
    
    async exportToExcel(data, filename, options = {}) {
        // This would require a library like SheetJS
        // For now, we'll export as CSV with .xlsx extension
        console.warn('Excel export requires SheetJS library. Falling back to CSV format.');
        await this.exportToCSV(data, filename, options);
    }
    
    downloadFile(content, filename, mimeType) {
        const blob = new Blob([content], { type: mimeType });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        
        link.href = url;
        link.download = filename;
        link.style.display = 'none';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        URL.revokeObjectURL(url);
    }
    
    async downloadCompressed(content, filename, mimeType) {
        // This would require a compression library like JSZip
        console.warn('Compression requires JSZip library. Downloading uncompressed file.');
        this.downloadFile(content, filename, mimeType);
    }
    
    showExportProgress() {
        const progressModal = document.createElement('div');
        progressModal.id = 'exportProgressModal';
        progressModal.className = 'modal active';
        progressModal.innerHTML = `
            <div class="modal-content">
                <div class="modal-body text-center">
                    <div class="export-progress">
                        <i class="fas fa-spinner fa-spin fa-3x"></i>
                        <h3>Exporting Data...</h3>
                        <p>Please wait while we prepare your export.</p>
                    </div>
                </div>
            </div>
        `;
        
        document.body.appendChild(progressModal);
    }
    
    hideExportProgress() {
        const progressModal = document.getElementById('exportProgressModal');
        if (progressModal) {
            progressModal.remove();
        }
    }
    
    showExportSuccess(filename, format) {
        const successModal = document.createElement('div');
        successModal.id = 'exportSuccessModal';
        successModal.className = 'modal active';
        successModal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Export Successful</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body text-center">
                    <div class="export-success">
                        <i class="fas fa-check-circle fa-3x text-success"></i>
                        <h4>Export Completed Successfully!</h4>
                        <p>Your data has been exported as <strong>${filename}.${format}</strong></p>
                        <p>The file should start downloading automatically.</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn primary" onclick="this.closest('.modal').remove()">Close</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(successModal);
        
        // Auto-close after 5 seconds
        setTimeout(() => {
            if (successModal.parentElement) {
                successModal.remove();
            }
        }, 5000);
        
        // Bind close button
        successModal.querySelector('.modal-close').addEventListener('click', () => {
            successModal.remove();
        });
    }
    
    showExportError(message) {
        const errorModal = document.createElement('div');
        errorModal.id = 'exportErrorModal';
        errorModal.className = 'modal active';
        errorModal.innerHTML = `
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Export Failed</h3>
                    <button class="modal-close">&times;</button>
                </div>
                <div class="modal-body text-center">
                    <div class="export-error">
                        <i class="fas fa-exclamation-triangle fa-3x text-danger"></i>
                        <h4>Export Failed</h4>
                        <p>There was an error exporting your data:</p>
                        <p class="error-message">${message}</p>
                        <p>Please try again or contact support if the problem persists.</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn primary" onclick="this.closest('.modal').remove()">Close</button>
                </div>
            </div>
        `;
        
        document.body.appendChild(errorModal);
        
        // Bind close button
        errorModal.querySelector('.modal-close').addEventListener('click', () => {
            errorModal.remove();
        });
    }
    
    // Quick export methods
    quickExportCSV(data, filename = 'export') {
        return this.exportData(data, 'csv', filename, { includeHeaders: true });
    }
    
    quickExportJSON(data, filename = 'export') {
        return this.exportData(data, 'json', filename);
    }
    
    quickExportPDF(data, filename = 'export') {
        return this.exportData(data, 'pdf', filename);
    }
    
    // Batch export functionality
    async batchExport(exports) {
        const results = [];
        
        for (const exportConfig of exports) {
            try {
                await this.exportData(
                    exportConfig.data,
                    exportConfig.format,
                    exportConfig.filename,
                    exportConfig.options
                );
                results.push({ success: true, filename: exportConfig.filename });
            } catch (error) {
                results.push({ success: false, filename: exportConfig.filename, error: error.message });
            }
        }
        
        return results;
    }
}

// Initialize export manager
const dataExportManager = new DataExportManager();

// Export for global use
window.DataExportManager = DataExportManager;
window.dataExportManager = dataExportManager;

// Utility functions for common export scenarios
window.exportRideHistory = (rides, format = 'csv') => {
    const filename = `ride_history_${new Date().toISOString().split('T')[0]}`;
    return dataExportManager.exportData(rides, format, filename);
};

window.exportDriverFeedback = (feedback, format = 'csv') => {
    const filename = `driver_feedback_${new Date().toISOString().split('T')[0]}`;
    return dataExportManager.exportData(feedback, format, filename);
};

window.exportTorahQuizData = (quizData, format = 'csv') => {
    const filename = `torah_quiz_${new Date().toISOString().split('T')[0]}`;
    return dataExportManager.exportData(quizData, format, filename);
};