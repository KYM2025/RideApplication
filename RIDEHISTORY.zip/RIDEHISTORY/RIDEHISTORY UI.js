// Main Application Controller
class StraightWayApp {
    constructor() {
        this.isInitialized = false;
        this.currentUser = null;
        this.activeTab = 'dashboard';
        this.dataCache = new Map();
        this.updateIntervals = new Map();
        
        // Component references
        this.firebaseService = null;
        this.dataViz = null;
        this.dragDropManager = null;
        this.modalManager = null;
        this.contextMenuManager = null;
        this.dataExportManager = null;
        this.searchEngine = null;
        
        // Data stores
        this.rides = [];
        this.drivers = [];
        this.feedback = [];
        this.notifications = [];
        this.torahProgress = [];
        
        this.init();
    }
    
    async init() {
        try {
            console.log('Initializing Straight-Way Rideshare Application...');
            
            // Wait for DOM to be ready
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', () => this.initializeApp());
            } else {
                await this.initializeApp();
            }
            
        } catch (error) {
            console.error('Application initialization failed:', error);
            this.showError('Failed to initialize application', error.message);
        }
    }
    
    async initializeApp() {
        try {
            // Initialize components
            await this.initializeComponents();
            
            // Load sample data immediately for demo
            await this.loadSampleData();
            
            // Set up event listeners
            this.setupEventListeners();
            
            // Initialize UI
            this.initializeUI();
            
            // Hide loading screen
            this.hideLoadingState();
            
            // Start real-time updates (optional)
            this.startRealTimeUpdates();
            
            this.isInitialized = true;
            console.log('Application initialized successfully');
            
            // Dispatch ready event
            document.dispatchEvent(new CustomEvent('app:ready'));
            
        } catch (error) {
            console.error('Application initialization error:', error);
            // Still try to show the interface with sample data
            await this.loadSampleData();
            this.hideLoadingState();
            this.isInitialized = true;
        }
    }
    
    async initializeComponents() {
        try {
            // Initialize Firebase service (optional for demo)
            this.firebaseService = window.firebaseService || null;
            
            // Initialize data visualization
            this.dataViz = window.dataViz || null;
            
            // Initialize drag and drop (optional)
            this.dragDropManager = window.dragDropManager || null;
            
            // Initialize modals (optional)
            this.modalManager = window.rideModals || null;
            
            // Initialize context menus (optional)
            this.contextMenuManager = window.contextMenuManager || null;
            
            // Initialize data export (optional)
            this.dataExportManager = window.dataExportManager || null;
            
            // Initialize search engine
            this.initializeSearchEngine();
            
            // Initialize data tables
            this.initializeDataTables();
            
            console.log('Components initialized successfully');
        } catch (error) {
            console.error('Component initialization error:', error);
            // Continue with demo mode
        }
    }
    
    initializeSearchEngine() {
        // This would initialize the advanced search engine with data sources
        const dataSources = {
            rides: this.rides,
            drivers: this.drivers,
            feedback: this.feedback,
            notifications: this.notifications,
            torah_quiz: this.torahProgress
        };
        
        // Initialize search engine (would use the AdvancedSearchEngine class)
        console.log('Search engine initialized with data sources');
    }
    
    initializeDataTables() {
        // Initialize rides table
        const ridesTableConfig = {
            pageSize: 10,
            sortable: true,
            filterable: true,
            searchable: true,
            exportable: true,
            selectable: true
        };
        
        const ridesColumns = [
            { key: 'ride_date', title: 'Date', type: 'date', sortable: true },
            { key: 'pickup_location', title: 'Pickup', type: 'text', sortable: true },
            { key: 'dropoff_location', title: 'Dropoff', type: 'text', sortable: true },
            { key: 'distance_km', title: 'Distance', type: 'number', sortable: true },
            { key: 'fare_amount', title: 'Fare', type: 'currency', sortable: true },
            { key: 'ride_status', title: 'Status', type: 'status', sortable: true }
        ];
        
        // Initialize table (would use InteractiveDataTable class)
        console.log('Data tables initialized');
    }
    
    setupEventListeners() {
        // Authentication events
        document.addEventListener('auth:signedIn', (e) => {
            this.onUserSignedIn(e.detail.user);
        });
        
        document.addEventListener('auth:signedOut', () => {
            this.onUserSignedOut();
        });
        
        // Data update events
        document.addEventListener('rides:updated', (e) => {
            this.onRidesUpdated(e.detail.rides);
        });
        
        document.addEventListener('notifications:updated', (e) => {
            this.onNotificationsUpdated(e.detail.notifications);
        });
        
        document.addEventListener('quiz:progress:updated', (e) => {
            this.onQuizProgressUpdated(e.detail.progress);
        });
        
        // UI events
        document.addEventListener('click', (e) => {
            this.handleGlobalClick(e);
        });
        
        // Tab navigation
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const tabId = e.currentTarget.dataset.tab;
                this.switchTab(tabId);
            });
        });
        
        // Ride operations
        document.addEventListener('ride:save', (e) => {
            this.handleRideSave(e.detail);
        });
        
        document.addEventListener('ride:view', (e) => {
            this.handleRideView(e.detail.rideId);
        });
        
        document.addEventListener('ride:edit', (e) => {
            this.handleRideEdit(e.detail.rideId);
        });
        
        document.addEventListener('ride:delete', (e) => {
            this.handleRideDelete(e.detail.rideId);
        });
        
        // Driver rating events
        document.addEventListener('driver:rate', (e) => {
            this.handleDriverRating(e.detail);
        });
        
        // Export events
        document.addEventListener('data:export', (e) => {
            this.handleDataExport(e.detail);
        });
        
        // Window events
        window.addEventListener('resize', () => {
            this.handleWindowResize();
        });
        
        window.addEventListener('beforeunload', () => {
            this.cleanup();
        });
    }
    
    initializeUI() {
        // Initialize dashboard
        this.initializeDashboard();
        
        // Initialize charts with sample data
        this.initializeCharts();
        
        // Set up drag and drop areas
        this.setupDragAndDrop();
        
        // Initialize tooltips and hover effects
        this.initializeInteractiveElements();
        
        // Load initial data
        this.loadInitialData();
    }
    
    initializeDashboard() {
        // Update dashboard stats
        this.updateDashboardStats();
        
        // Initialize dashboard widgets
        this.initializeDashboardWidgets();
    }
    
    initializeDashboardWidgets() {
        // Initialize recent activity widget
        this.updateRecentActivity();
        
        // Initialize quick stats
        this.updateQuickStats();
        
        // Set up widget interactions
        this.setupWidgetInteractions();
    }
    
    updateRecentActivity() {
        const recentActivityList = document.getElementById('recentActivityList');
        if (recentActivityList && this.rides.length > 0) {
            const recentRides = this.rides.slice(0, 5);
            recentActivityList.innerHTML = recentRides.map(ride => `
                <div class="activity-item">
                    <div class="activity-icon">
                        <i class="fas fa-car"></i>
                    </div>
                    <div class="activity-content">
                        <p><strong>Ride completed</strong></p>
                        <p>From ${ride.pickup_location} to ${ride.dropoff_location}</p>
                        <small>${this.formatTimeAgo(ride.created_at)}</small>
                    </div>
                    <div class="activity-amount">
                        $${ride.fare_amount}
                    </div>
                </div>
            `).join('');
        }
    }
    
    updateQuickStats() {
        // Update header stats
        const stats = this.calculateDashboardStats();
        
        // Update notification count
        const unreadNotifications = this.notifications.filter(n => !n.is_read).length;
        const notificationBadge = document.getElementById('notificationCount');
        if (notificationBadge) {
            notificationBadge.textContent = unreadNotifications;
            notificationBadge.style.display = unreadNotifications > 0 ? 'block' : 'none';
        }
        
        // Update user name
        const userNameElement = document.getElementById('userName');
        if (userNameElement) {
            userNameElement.textContent = this.currentUser ?
                (this.currentUser.displayName || this.currentUser.email || 'Demo User') :
                'Demo User';
        }
    }
    
    setupWidgetInteractions() {
        // Set up view all button
        const viewAllBtn = document.querySelector('.view-all-btn');
        if (viewAllBtn) {
            viewAllBtn.addEventListener('click', () => {
                this.switchTab('rides');
            });
        }
        
        // Set up chart period selector
        const activityPeriod = document.getElementById('activityPeriod');
        if (activityPeriod) {
            activityPeriod.addEventListener('change', (e) => {
                this.updateActivityChart(e.target.value);
            });
        }
    }
    
    updateActivityChart(period) {
        // Update the ride activity chart based on selected period
        if (this.dataViz) {
            const filteredData = this.getFilteredRideData(period);
            this.dataViz.updateChart('rideActivityChart', filteredData);
        }
    }
    
    getFilteredRideData(days) {
        const now = new Date();
        const cutoffDate = new Date(now.getTime() - (parseInt(days) * 24 * 60 * 60 * 1000));
        
        const filteredRides = this.rides.filter(ride =>
            new Date(ride.ride_date) >= cutoffDate
        );
        
        // Generate chart data from filtered rides
        const dateMap = new Map();
        filteredRides.forEach(ride => {
            const date = new Date(ride.ride_date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            if (!dateMap.has(date)) {
                dateMap.set(date, { rides: 0, distance: 0 });
            }
            const data = dateMap.get(date);
            data.rides += 1;
            data.distance += parseFloat(ride.distance_km || 0);
        });
        
        const labels = Array.from(dateMap.keys());
        const rides = Array.from(dateMap.values()).map(d => d.rides);
        const distance = Array.from(dateMap.values()).map(d => d.distance);
        
        return {
            rideActivity: {
                labels: labels,
                rides: rides,
                distance: distance
            }
        };
    }
    
    initializeCharts() {
        // Generate sample data for charts
        const sampleData = this.dataViz ? this.dataViz.generateSampleData() : this.generateChartSampleData();
        
        // Create ride activity chart
        if (this.dataViz) {
            this.dataViz.createRideActivityChart('rideActivityChart', sampleData.rideActivity);
            
            // Create spending chart
            this.dataViz.createSpendingChart('spendingChart', sampleData.spending);
            
            // Create rating distribution chart
            this.dataViz.createRatingDistributionChart('ratingDistributionChart', sampleData.ratings);
            
            // Create peak hours chart
            this.dataViz.createPeakHoursChart('peakHoursChart', sampleData.peakHours);
            
            // Create monthly trends chart
            this.dataViz.createMonthlyTrendsChart('monthlyTrendsChart', sampleData.monthlyTrends);
            
            // Create Torah quiz chart
            this.dataViz.createTorahQuizChart('torahQuizChart', sampleData.torahQuiz);
        }
    }
    
    generateChartSampleData() {
        // Fallback chart data generation if dataViz is not available
        const now = new Date();
        const days = [];
        const rides = [];
        const distance = [];
        
        for (let i = 29; i >= 0; i--) {
            const date = new Date(now);
            date.setDate(date.getDate() - i);
            days.push(date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }));
            rides.push(Math.floor(Math.random() * 10) + 1);
            distance.push(Math.floor(Math.random() * 50) + 10);
        }
        
        return {
            rideActivity: {
                labels: days,
                rides: rides,
                distance: distance
            },
            spending: {
                labels: ['Rides', 'Tips', 'Fees', 'Other'],
                values: [450, 75, 25, 15]
            },
            ratings: {
                ratings: [2, 5, 12, 45, 78]
            },
            peakHours: {
                hours: ['12 AM', '3 AM', '6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'],
                frequency: [5, 2, 8, 25, 30, 35, 45, 20]
            },
            monthlyTrends: {
                months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                rides: [45, 52, 48, 61, 55, 67],
                spending: [680, 780, 720, 915, 825, 1005],
                ratings: [4.2, 4.3, 4.1, 4.5, 4.4, 4.6]
            },
            torahQuiz: {
                categories: ['Torah', 'Talmud', 'Halacha', 'History', 'Philosophy'],
                scores: [85, 92, 78, 88, 95]
            }
        };
    }
    
    setupDragAndDrop() {
        // Make dashboard widgets draggable
        this.dragDropManager.makeDashboardSortable('.dashboard-grid', {
            onRearrange: (newOrder) => {
                this.saveDashboardLayout(newOrder);
            }
        });
        
        // Make ride table rows draggable for reordering
        document.querySelectorAll('.rides-table tbody tr').forEach(row => {
            this.dragDropManager.makeDraggable(row, {
                data: { rideId: row.dataset.rideId }
            });
        });
    }
    
    initializeInteractiveElements() {
        // Initialize tooltips for status badges
        document.querySelectorAll('.status-badge').forEach(badge => {
            badge.setAttribute('data-tooltip', this.getStatusTooltip(badge.textContent));
        });
        
        // Initialize hover effects for cards
        document.querySelectorAll('.stat-card').forEach(card => {
            card.addEventListener('mouseenter', () => {
                card.style.transform = 'translateY(-2px)';
                card.style.boxShadow = '0 8px 25px rgba(0,0,0,0.15)';
            });
            
            card.addEventListener('mouseleave', () => {
                card.style.transform = '';
                card.style.boxShadow = '';
            });
        });
    }
    
    async loadInitialData() {
        try {
            // Show loading state
            this.showLoadingState();
            
            // Load user data if authenticated
            if (this.currentUser) {
                await this.loadUserData(this.currentUser.uid);
            } else {
                // Load sample data for demo
                await this.loadSampleData();
            }
            
            // Hide loading state
            this.hideLoadingState();
            
        } catch (error) {
            console.error('Failed to load initial data:', error);
            this.showError('Failed to load data', error.message);
        }
    }
    
    async loadUserData(userId) {
        try {
            if (this.firebaseService) {
                // Load rides
                const ridesResult = await this.firebaseService.getUserRides(userId);
                if (ridesResult.success) {
                    this.rides = ridesResult.data;
                    this.updateRidesDisplay();
                }
                
                // Load notifications
                const notificationsResult = await this.firebaseService.getUserNotifications(userId);
                if (notificationsResult.success) {
                    this.notifications = notificationsResult.data;
                    this.updateNotificationsDisplay();
                }
                
                // Load quiz progress
                const quizResult = await this.firebaseService.getUserQuizProgress(userId);
                if (quizResult.success) {
                    this.torahProgress = quizResult.data;
                    this.updateQuizProgressDisplay();
                }
            } else {
                // Fallback to sample data
                await this.loadSampleData();
            }
            
            // Update dashboard with real data
            this.updateDashboardWithRealData();
        } catch (error) {
            console.error('Error loading user data, falling back to sample data:', error);
            await this.loadSampleData();
        }
    }
    
    async loadSampleData() {
        // Generate sample data for demonstration
        this.rides = this.generateSampleRides();
        this.drivers = this.generateSampleDrivers();
        this.feedback = this.generateSampleFeedback();
        this.notifications = this.generateSampleNotifications();
        this.torahProgress = this.generateSampleTorahProgress();
        
        // Update displays
        this.updateRidesDisplay();
        this.updateNotificationsDisplay();
        this.updateQuizProgressDisplay();
        this.updateDashboardWithRealData();
    }
    
    startRealTimeUpdates() {
        try {
            // Start periodic updates for charts
            this.updateIntervals.set('charts', setInterval(() => {
                this.updateChartsWithLatestData();
            }, 30000)); // Update every 30 seconds
            
            // Start periodic updates for dashboard stats
            this.updateIntervals.set('dashboard', setInterval(() => {
                this.updateDashboardStats();
            }, 60000)); // Update every minute
            
            // Start periodic updates for notifications (optional)
            if (this.firebaseService) {
                this.updateIntervals.set('notifications', setInterval(() => {
                    this.checkForNewNotifications();
                }, 15000)); // Check every 15 seconds
            }
        } catch (error) {
            console.error('Error starting real-time updates:', error);
        }
    }
    
    // Event handlers
    onUserSignedIn(user) {
        this.currentUser = user;
        console.log('User signed in:', user.email);
        
        // Update UI for authenticated user
        this.updateUserInterface(user);
        
        // Load user-specific data
        this.loadUserData(user.uid);
        
        // Show welcome message
        this.showNotification(`Welcome back, ${user.displayName || user.email}!`, 'success');
    }
    
    onUserSignedOut() {
        this.currentUser = null;
        console.log('User signed out');
        
        // Clear user data
        this.clearUserData();
        
        // Update UI for anonymous user
        this.updateUserInterface(null);
        
        // Load sample data
        this.loadSampleData();
    }
    
    onRidesUpdated(rides) {
        this.rides = rides;
        this.updateRidesDisplay();
        this.updateDashboardStats();
        this.updateChartsWithLatestData();
    }
    
    onNotificationsUpdated(notifications) {
        this.notifications = notifications;
        this.updateNotificationsDisplay();
        this.updateNotificationBadge();
    }
    
    onQuizProgressUpdated(progress) {
        this.torahProgress = progress;
        this.updateQuizProgressDisplay();
        this.updateTorahQuizChart();
    }
    
    handleGlobalClick(e) {
        // Handle various click events
        const target = e.target;
        
        // Handle export buttons
        if (target.matches('[data-export]')) {
            const format = target.dataset.export;
            const source = target.dataset.source || 'rides';
            this.dataExportManager.showExportDialog(source, format);
        }
        
        // Handle chart type toggles
        if (target.matches('.chart-type-btn')) {
            const chartContainer = target.closest('.chart-container');
            const chartCanvas = chartContainer.querySelector('canvas');
            const newType = target.dataset.type;
            
            if (chartCanvas) {
                this.dataViz.changeChartType(chartCanvas.id, newType);
            }
        }
        
        // Handle notification clicks
        if (target.matches('.notification-item')) {
            const notificationId = target.dataset.notificationId;
            this.handleNotificationClick(notificationId);
        }
    }
    
    switchTab(tabId) {
        // Update active tab
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.classList.remove('active');
        });
        
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        // Activate new tab
        document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
        document.getElementById(tabId).classList.add('active');
        
        this.activeTab = tabId;
        
        // Load tab-specific data
        this.loadTabData(tabId);
        
        // Update URL hash
        window.location.hash = tabId;
    }
    
    async loadTabData(tabId) {
        switch (tabId) {
            case 'rides':
                await this.loadRidesTabData();
                break;
            case 'ratings':
                await this.loadRatingsTabData();
                break;
            case 'torah':
                await this.loadTorahTabData();
                break;
            case 'notifications':
                await this.loadNotificationsTabData();
                break;
            case 'analytics':
                await this.loadAnalyticsTabData();
                break;
        }
    }
    
    async handleRideSave(rideData) {
        try {
            const result = await this.firebaseService.createRide(rideData);
            
            if (result.success) {
                this.showNotification('Ride saved successfully!', 'success');
                
                // Refresh rides data
                if (this.currentUser) {
                    await this.loadUserData(this.currentUser.uid);
                }
            } else {
                this.showError('Failed to save ride', result.error);
            }
        } catch (error) {
            console.error('Error saving ride:', error);
            this.showError('Failed to save ride', error.message);
        }
    }
    
    async handleRideView(rideId) {
        const ride = this.rides.find(r => r.id === rideId || r.ride_id === rideId);
        if (ride) {
            this.modalManager.showRideDetails(ride);
        }
    }
    
    async handleRideEdit(rideId) {
        const ride = this.rides.find(r => r.id === rideId || r.ride_id === rideId);
        if (ride) {
            this.modalManager.openRideForm(ride);
        }
    }
    
    async handleRideDelete(rideId) {
        try {
            const result = await this.firebaseService.deleteRide(rideId);
            
            if (result.success) {
                this.showNotification('Ride deleted successfully!', 'success');
                
                // Remove from local data
                this.rides = this.rides.filter(r => r.id !== rideId && r.ride_id !== rideId);
                this.updateRidesDisplay();
            } else {
                this.showError('Failed to delete ride', result.error);
            }
        } catch (error) {
            console.error('Error deleting ride:', error);
            this.showError('Failed to delete ride', error.message);
        }
    }
    
    async handleDriverRating(ratingData) {
        try {
            const result = await this.firebaseService.submitDriverRating(ratingData);
            
            if (result.success) {
                this.showNotification('Driver rating submitted successfully!', 'success');
            } else {
                this.showError('Failed to submit rating', result.error);
            }
        } catch (error) {
            console.error('Error submitting rating:', error);
            this.showError('Failed to submit rating', error.message);
        }
    }
    
    handleDataExport(exportConfig) {
        this.dataExportManager.exportData(
            exportConfig.data,
            exportConfig.format,
            exportConfig.filename,
            exportConfig.options
        );
    }
    
    handleWindowResize() {
        // Resize charts
        this.dataViz.charts.forEach((chart, canvasId) => {
            this.dataViz.resizeChart(canvasId);
        });
        
        // Update responsive layouts
        this.updateResponsiveLayouts();
    }
    
    // UI update methods
    updateDashboardStats() {
        const stats = this.calculateDashboardStats();
        
        // Update stat cards
        document.getElementById('totalRides').textContent = stats.totalRides;
        document.getElementById('currentStreak').textContent = stats.currentStreak;
        document.getElementById('totalPoints').textContent = stats.totalPoints;
        document.getElementById('dashTotalRides').textContent = stats.totalRides;
        document.getElementById('totalDistance').textContent = `${stats.totalDistance} km`;
        document.getElementById('totalSpending').textContent = `$${stats.totalSpending}`;
        document.getElementById('avgRating').textContent = stats.avgRating.toFixed(1);
    }
    
    calculateDashboardStats() {
        return {
            totalRides: this.rides.length,
            currentStreak: this.calculateCurrentStreak(),
            totalPoints: this.calculateTotalPoints(),
            totalDistance: this.rides.reduce((sum, ride) => sum + parseFloat(ride.distance_km || 0), 0).toFixed(1),
            totalSpending: this.rides.reduce((sum, ride) => sum + parseFloat(ride.total_amount || 0), 0).toFixed(2),
            avgRating: this.calculateAverageRating()
        };
    }
    
    calculateCurrentStreak() {
        // Calculate current ride streak
        let streak = 0;
        const sortedRides = this.rides
            .filter(ride => ride.ride_status === 'completed')
            .sort((a, b) => new Date(b.ride_date) - new Date(a.ride_date));
        
        for (const ride of sortedRides) {
            const rideDate = new Date(ride.ride_date);
            const today = new Date();
            const daysDiff = Math.floor((today - rideDate) / (1000 * 60 * 60 * 24));
            
            if (daysDiff <= streak + 1) {
                streak++;
            } else {
                break;
            }
        }
        
        return streak;
    }
    
    calculateTotalPoints() {
        // Calculate total points based on rides and quiz progress
        const ridePoints = this.rides.length * 10;
        const quizPoints = this.torahProgress.filter(p => p.is_correct).length * 5;
        return ridePoints + quizPoints;
    }
    
    calculateAverageRating() {
        const ratings = this.feedback.map(f => f.rating).filter(r => r > 0);
        if (ratings.length === 0) return 0;
        return ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length;
    }
    
    updateRidesDisplay() {
        // Update rides table
        const tableBody = document.getElementById('ridesTableBody');
        if (tableBody) {
            tableBody.innerHTML = this.generateRidesTableHTML();
        }
        
        // Update rides cards view
        const cardsContainer = document.getElementById('ridesGrid');
        if (cardsContainer) {
            cardsContainer.innerHTML = this.generateRidesCardsHTML();
        }
    }
    
    generateRidesTableHTML() {
        return this.rides.map(ride => `
            <tr data-ride-id="${ride.id || ride.ride_id}">
                <td>${new Date(ride.ride_date).toLocaleDateString()}</td>
                <td>${ride.pickup_location}</td>
                <td>${ride.dropoff_location}</td>
                <td>${ride.distance_km} km</td>
                <td>$${ride.fare_amount}</td>
                <td>${ride.driver_name || 'N/A'}</td>
                <td>${this.generateStarRating(ride.driver_rating || 0)}</td>
                <td><span class="status-badge ${ride.ride_status}">${ride.ride_status}</span></td>
                <td>
                    <button class="btn-icon" onclick="app.handleRideView('${ride.id || ride.ride_id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn-icon" onclick="app.handleRideEdit('${ride.id || ride.ride_id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                </td>
            </tr>
        `).join('');
    }
    
    generateRidesCardsHTML() {
        return this.rides.map(ride => `
            <div class="ride-card" data-ride-id="${ride.id || ride.ride_id}">
                <div class="ride-card-header">
                    <span class="ride-date">${new Date(ride.ride_date).toLocaleDateString()}</span>
                    <span class="status-badge ${ride.ride_status}">${ride.ride_status}</span>
                </div>
                <div class="ride-route">
                    <div class="route-point">
                        <i class="fas fa-circle text-success"></i>
                        <span>${ride.pickup_location}</span>
                    </div>
                    <div class="route-line"></div>
                    <div class="route-point">
                        <i class="fas fa-circle text-danger"></i>
                        <span>${ride.dropoff_location}</span>
                    </div>
                </div>
                <div class="ride-details">
                    <span>${ride.distance_km} km</span>
                    <span>$${ride.fare_amount}</span>
                    <span>${this.generateStarRating(ride.driver_rating || 0)}</span>
                </div>
            </div>
        `).join('');
    }
    
    generateStarRating(rating) {
        const stars = [];
        const fullStars = Math.floor(rating);
        const hasHalfStar = rating % 1 !== 0;
        
        for (let i = 0; i < 5; i++) {
            if (i < fullStars) {
                stars.push('<i class="fas fa-star text-warning"></i>');
            } else if (i === fullStars && hasHalfStar) {
                stars.push('<i class="fas fa-star-half-alt text-warning"></i>');
            } else {
                stars.push('<i class="far fa-star text-muted"></i>');
            }
        }
        
        return stars.join('');
    }
    
    updateNotificationsDisplay() {
        const container = document.getElementById('notificationsList');
        if (container) {
            container.innerHTML = this.generateNotificationsHTML();
        }
        
        this.updateNotificationBadge();
    }
    
    updateQuizProgressDisplay() {
        // Update Torah quiz progress display
        const quizTimeline = document.getElementById('quizTimeline');
        if (quizTimeline && this.torahProgress.length > 0) {
            const recentProgress = this.torahProgress.slice(0, 10);
            quizTimeline.innerHTML = recentProgress.map(progress => `
                <div class="timeline-item">
                    <div class="timeline-icon ${progress.is_correct ? 'correct' : 'incorrect'}">
                        <i class="fas ${progress.is_correct ? 'fa-check' : 'fa-times'}"></i>
                    </div>
                    <div class="timeline-content">
                        <h4>${progress.category} Question</h4>
                        <p>${progress.is_correct ? 'Correct' : 'Incorrect'} answer</p>
                        <small>${this.formatTimeAgo(progress.answered_at)}</small>
                    </div>
                    <div class="timeline-points">
                        +${progress.points_earned} pts
                    </div>
                </div>
            `).join('');
        }
        
        // Update quiz stats
        this.updateQuizStats();
    }
    
    updateQuizStats() {
        if (this.torahProgress.length > 0) {
            const correctAnswers = this.torahProgress.filter(p => p.is_correct).length;
            const totalQuestions = this.torahProgress.length;
            const accuracy = ((correctAnswers / totalQuestions) * 100).toFixed(0);
            
            // Calculate current streak
            let currentStreak = 0;
            for (let i = 0; i < this.torahProgress.length; i++) {
                if (this.torahProgress[i].is_correct) {
                    currentStreak++;
                } else {
                    break;
                }
            }
            
            // Update quiz stats in UI
            const quizStreakElement = document.getElementById('quizStreak');
            const correctAnswersElement = document.getElementById('correctAnswers');
            const totalQuestionsElement = document.getElementById('totalQuestions');
            
            if (quizStreakElement) quizStreakElement.textContent = currentStreak;
            if (correctAnswersElement) correctAnswersElement.textContent = accuracy + '%';
            if (totalQuestionsElement) totalQuestionsElement.textContent = totalQuestions;
        }
    }
    
    updateDashboardWithRealData() {
        // Update dashboard with actual data
        this.updateDashboardStats();
        this.updateRecentActivity();
        this.updateQuickStats();
        
        // Update charts with real data if available
        if (this.dataViz && this.rides.length > 0) {
            this.updateChartsWithLatestData();
        }
    }
    
    updateChartsWithLatestData() {
        // Update charts with latest data
        try {
            if (this.dataViz) {
                // Generate updated chart data from current rides
                const chartData = this.generateChartDataFromRides();
                
                // Update each chart
                this.dataViz.updateChart('rideActivityChart', chartData.rideActivity);
                this.dataViz.updateChart('spendingChart', chartData.spending);
                this.dataViz.updateChart('ratingDistributionChart', chartData.ratings);
                this.dataViz.updateChart('peakHoursChart', chartData.peakHours);
                this.dataViz.updateChart('monthlyTrendsChart', chartData.monthlyTrends);
                this.dataViz.updateChart('torahQuizChart', chartData.torahQuiz);
            }
        } catch (error) {
            console.error('Error updating charts:', error);
        }
    }
    
    generateChartDataFromRides() {
        // Generate chart data from actual ride data
        const now = new Date();
        const last30Days = [];
        const ridesByDay = new Map();
        const distanceByDay = new Map();
        
        // Generate last 30 days
        for (let i = 29; i >= 0; i--) {
            const date = new Date(now);
            date.setDate(date.getDate() - i);
            const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            last30Days.push(dateStr);
            ridesByDay.set(dateStr, 0);
            distanceByDay.set(dateStr, 0);
        }
        
        // Populate with actual ride data
        this.rides.forEach(ride => {
            const rideDate = new Date(ride.ride_date);
            const dateStr = rideDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
            if (ridesByDay.has(dateStr)) {
                ridesByDay.set(dateStr, ridesByDay.get(dateStr) + 1);
                distanceByDay.set(dateStr, distanceByDay.get(dateStr) + parseFloat(ride.distance_km || 0));
            }
        });
        
        // Calculate spending breakdown
        const totalSpending = this.rides.reduce((sum, ride) => sum + parseFloat(ride.total_amount || 0), 0);
        const avgFare = totalSpending * 0.85; // 85% for rides
        const tips = totalSpending * 0.10; // 10% for tips
        const fees = totalSpending * 0.05; // 5% for fees
        
        // Calculate rating distribution
        const ratingCounts = [0, 0, 0, 0, 0]; // 1-5 stars
        this.feedback.forEach(feedback => {
            if (feedback.rating >= 1 && feedback.rating <= 5) {
                ratingCounts[feedback.rating - 1]++;
            }
        });
        
        return {
            rideActivity: {
                labels: last30Days,
                rides: Array.from(ridesByDay.values()),
                distance: Array.from(distanceByDay.values())
            },
            spending: {
                labels: ['Rides', 'Tips', 'Fees', 'Other'],
                values: [avgFare.toFixed(2), tips.toFixed(2), fees.toFixed(2), (totalSpending * 0.01).toFixed(2)]
            },
            ratings: {
                ratings: ratingCounts
            },
            peakHours: {
                hours: ['12 AM', '3 AM', '6 AM', '9 AM', '12 PM', '3 PM', '6 PM', '9 PM'],
                frequency: [5, 2, 8, 25, 30, 35, 45, 20] // Sample data for now
            },
            monthlyTrends: {
                months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                rides: [45, 52, 48, 61, 55, 67], // Sample data for now
                spending: [680, 780, 720, 915, 825, 1005],
                ratings: [4.2, 4.3, 4.1, 4.5, 4.4, 4.6]
            },
            torahQuiz: {
                categories: ['Torah', 'Talmud', 'Halacha', 'History', 'Philosophy'],
                scores: this.calculateTorahQuizScores()
            }
        };
    }
    
    calculateTorahQuizScores() {
        const categories = ['Torah', 'Talmud', 'Halacha', 'History', 'Philosophy'];
        const scores = [];
        
        categories.forEach(category => {
            const categoryProgress = this.torahProgress.filter(p => p.category === category);
            if (categoryProgress.length > 0) {
                const correct = categoryProgress.filter(p => p.is_correct).length;
                const accuracy = (correct / categoryProgress.length) * 100;
                scores.push(accuracy);
            } else {
                scores.push(0);
            }
        });
        
        return scores;
    }
    
    checkForNewNotifications() {
        // Check for new notifications (placeholder for real implementation)
        console.log('Checking for new notifications...');
    }
    
    generateNotificationsHTML() {
        return this.notifications.map(notification => `
            <div class="notification-item ${notification.is_read ? 'read' : 'unread'}" 
                 data-notification-id="${notification.id || notification.notification_id}">
                <div class="notification-icon">
                    <i class="fas ${this.getNotificationIcon(notification.type)}"></i>
                </div>
                <div class="notification-content">
                    <h4>${notification.title}</h4>
                    <p>${notification.message}</p>
                    <small>${this.formatTimeAgo(notification.timestamp)}</small>
                </div>
                ${!notification.is_read ? '<div class="unread-indicator"></div>' : ''}
            </div>
        `).join('');
    }
    
    updateNotificationBadge() {
        const unreadCount = this.notifications.filter(n => !n.is_read).length;
        const badge = document.getElementById('notificationCount');
        if (badge) {
            badge.textContent = unreadCount;
            badge.style.display = unreadCount > 0 ? 'block' : 'none';
        }
    }
    
    // Utility methods
    getNotificationIcon(type) {
        const icons = {
            ride_completed: 'fa-check-circle',
            driver_rated: 'fa-star',
            quiz_available: 'fa-question-circle',
            system_update: 'fa-info-circle'
        };
        return icons[type] || 'fa-bell';
    }
    
    getStatusTooltip(status) {
        const tooltips = {
            completed: 'Ride completed successfully',
            pending: 'Ride is pending confirmation',
            cancelled: 'Ride was cancelled',
            in_progress: 'Ride is currently in progress'
        };
        return tooltips[status.toLowerCase()] || status;
    }
    
    formatTimeAgo(timestamp) {
        const now = new Date();
        const time = new Date(timestamp);
        const diffMs = now - time;
        const diffMins = Math.floor(diffMs / 60000);
        const diffHours = Math.floor(diffMins / 60);
        const diffDays = Math.floor(diffHours / 24);
        
        if (diffDays > 0) return `${diffDays}d ago`;
        if (diffHours > 0) return `${diffHours}h ago`;
        if (diffMins > 0) return `${diffMins}m ago`;
        return 'Just now';
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `toast toast-${type} show`;
        notification.innerHTML = `
            <div class="toast-icon">
                <i class="fas ${type === 'success' ? 'fa-check' : type === 'error' ? 'fa-times' : 'fa-info'}"></i>
            </div>
            <div class="toast-content">
                <div class="toast-message">${message}</div>
            </div>
            <button class="toast-close">
                <i class="fas fa-times"></i>
            </button>
        `;
        
        const container = document.getElementById('toastContainer') || document.body;
        container.appendChild(notification);
        
        // Auto-remove after 5 seconds
        setTimeout(() => {
            notification.remove();
        }, 5000);
        
        // Bind close button
        notification.querySelector('.toast-close').addEventListener('click', () => {
            notification.remove();
        });
    }
    
    showError(title, message) {
        this.modalManager.alert(`${title}: ${message}`, 'Error');
    }
    
    showLoadingState() {
        document.getElementById('loadingOverlay').style.display = 'flex';
    }
    
    hideLoadingState() {
        document.getElementById('loadingOverlay').style.display = 'none';
    }
    
    // Sample data generators (for demo purposes)
    generateSampleRides() {
        const sampleRides = [];
        const pickupLocations = [
            'Downtown Jerusalem', 'Tel Aviv Central', 'Haifa Port', 'Be\'er Sheva Station',
            'Netanya Beach', 'Eilat Airport', 'Tiberias Waterfront', 'Nazareth Old City',
            'Ashdod Marina', 'Herzliya Pituach', 'Ramat Gan Diamond Exchange', 'Petah Tikva Mall'
        ];
        const dropoffLocations = [
            'Western Wall', 'Ben Gurion Airport', 'Technion Campus', 'Soroka Hospital',
            'Caesarea Ruins', 'Ramon Crater', 'Sea of Galilee', 'Basilica of Annunciation',
            'Ashdod Port', 'Arena Mall', 'Rabin Square', 'Segula Industrial Zone'
        ];
        const drivers = ['Moshe Cohen', 'Sarah Levy', 'David Goldstein', 'Rachel Katz', 'Yosef Mizrahi'];
        const statuses = ['completed', 'completed', 'completed', 'pending', 'cancelled'];
        
        for (let i = 0; i < 25; i++) {
            const rideDate = new Date();
            rideDate.setDate(rideDate.getDate() - Math.floor(Math.random() * 90));
            
            const distance = (Math.random() * 50 + 5).toFixed(1);
            const fareAmount = (parseFloat(distance) * 2.5 + Math.random() * 20 + 10).toFixed(2);
            const driverRating = Math.random() > 0.1 ? (Math.random() * 2 + 3).toFixed(1) : 0;
            
            sampleRides.push({
                id: `ride_${i + 1}`,
                ride_id: `ride_${i + 1}`,
                user_id: 'demo_user',
                ride_date: rideDate.toISOString().split('T')[0],
                pickup_location: pickupLocations[Math.floor(Math.random() * pickupLocations.length)],
                dropoff_location: dropoffLocations[Math.floor(Math.random() * dropoffLocations.length)],
                distance_km: distance,
                fare_amount: fareAmount,
                total_amount: (parseFloat(fareAmount) + Math.random() * 5).toFixed(2),
                driver_name: drivers[Math.floor(Math.random() * drivers.length)],
                driver_rating: parseFloat(driverRating),
                ride_status: statuses[Math.floor(Math.random() * statuses.length)],
                payment_method: Math.random() > 0.5 ? 'credit_card' : 'cash',
                created_at: rideDate.toISOString(),
                updated_at: rideDate.toISOString()
            });
        }
        
        return sampleRides.sort((a, b) => new Date(b.ride_date) - new Date(a.ride_date));
    }
    
    generateSampleDrivers() {
        return [
            {
                id: 'driver_1',
                name: 'Moshe Cohen',
                rating: 4.8,
                total_rides: 1247,
                years_experience: 5,
                vehicle_type: 'Toyota Camry',
                license_plate: '123-45-678'
            },
            {
                id: 'driver_2',
                name: 'Sarah Levy',
                rating: 4.9,
                total_rides: 892,
                years_experience: 3,
                vehicle_type: 'Honda Accord',
                license_plate: '987-65-432'
            },
            {
                id: 'driver_3',
                name: 'David Goldstein',
                rating: 4.7,
                total_rides: 1456,
                years_experience: 7,
                vehicle_type: 'Nissan Altima',
                license_plate: '456-78-901'
            },
            {
                id: 'driver_4',
                name: 'Rachel Katz',
                rating: 4.6,
                total_rides: 634,
                years_experience: 2,
                vehicle_type: 'Hyundai Elantra',
                license_plate: '789-01-234'
            },
            {
                id: 'driver_5',
                name: 'Yosef Mizrahi',
                rating: 4.9,
                total_rides: 2103,
                years_experience: 8,
                vehicle_type: 'Mazda 6',
                license_plate: '234-56-789'
            }
        ];
    }
    
    generateSampleFeedback() {
        const feedbackData = [];
        const drivers = this.generateSampleDrivers();
        const comments = [
            'Excellent service, very professional driver!',
            'Clean car and smooth ride, highly recommended.',
            'Driver was punctual and friendly.',
            'Great conversation about Torah during the ride.',
            'Safe driving and comfortable vehicle.',
            'Very knowledgeable about the city routes.',
            'Respectful and courteous throughout the journey.',
            'Car was clean and well-maintained.',
            'Driver helped with luggage, great service!',
            'Smooth ride, will definitely book again.'
        ];
        
        for (let i = 0; i < 15; i++) {
            const driver = drivers[Math.floor(Math.random() * drivers.length)];
            const rating = Math.floor(Math.random() * 2) + 4; // 4 or 5 stars mostly
            const feedbackDate = new Date();
            feedbackDate.setDate(feedbackDate.getDate() - Math.floor(Math.random() * 60));
            
            feedbackData.push({
                id: `feedback_${i + 1}`,
                ride_id: `ride_${i + 1}`,
                driver_id: driver.id,
                driver_name: driver.name,
                rating: rating,
                comment: comments[Math.floor(Math.random() * comments.length)],
                feedback_date: feedbackDate.toISOString().split('T')[0],
                created_at: feedbackDate.toISOString()
            });
        }
        
        return feedbackData.sort((a, b) => new Date(b.feedback_date) - new Date(a.feedback_date));
    }
    
    generateSampleNotifications() {
        const notifications = [];
        const types = ['ride_completed', 'driver_rated', 'quiz_available', 'system_update'];
        const titles = {
            ride_completed: 'Ride Completed Successfully',
            driver_rated: 'Driver Rating Submitted',
            quiz_available: 'New Torah Quiz Available',
            system_update: 'System Update Notice'
        };
        const messages = {
            ride_completed: 'Your ride from {pickup} to {dropoff} has been completed. Thank you for using Straight-Way!',
            driver_rated: 'Thank you for rating your driver. Your feedback helps us maintain high service quality.',
            quiz_available: 'A new Torah quiz is available. Test your knowledge and earn points!',
            system_update: 'We\'ve updated our app with new features and improvements.'
        };
        
        for (let i = 0; i < 12; i++) {
            const type = types[Math.floor(Math.random() * types.length)];
            const timestamp = new Date();
            timestamp.setHours(timestamp.getHours() - Math.floor(Math.random() * 72));
            
            notifications.push({
                id: `notification_${i + 1}`,
                notification_id: `notification_${i + 1}`,
                user_id: 'demo_user',
                type: type,
                title: titles[type],
                message: messages[type],
                is_read: Math.random() > 0.4, // 60% read, 40% unread
                timestamp: timestamp.toISOString(),
                created_at: timestamp.toISOString()
            });
        }
        
        return notifications.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
    }
    
    generateSampleTorahProgress() {
        const categories = ['Torah', 'Talmud', 'Halacha', 'History', 'Philosophy'];
        const progress = [];
        
        for (let i = 0; i < 50; i++) {
            const category = categories[Math.floor(Math.random() * categories.length)];
            const isCorrect = Math.random() > 0.25; // 75% correct rate
            const questionDate = new Date();
            questionDate.setDate(questionDate.getDate() - Math.floor(Math.random() * 30));
            
            progress.push({
                id: `quiz_${i + 1}`,
                user_id: 'demo_user',
                category: category,
                question_id: `q_${i + 1}`,
                question_text: `Sample ${category} question ${i + 1}`,
                user_answer: isCorrect ? 'correct_answer' : 'wrong_answer',
                correct_answer: 'correct_answer',
                is_correct: isCorrect,
                points_earned: isCorrect ? 5 : 0,
                time_taken: Math.floor(Math.random() * 45) + 15, // 15-60 seconds
                answered_at: questionDate.toISOString(),
                created_at: questionDate.toISOString()
            });
        }
        
        return progress.sort((a, b) => new Date(b.answered_at) - new Date(a.answered_at));
    }
    
    // Cleanup
    cleanup() {
        // Clear intervals
        this.updateIntervals.forEach(interval => clearInterval(interval));
        this.updateIntervals.clear();
        
        // Stop Firebase listeners
        if (this.firebaseService) {
            this.firebaseService.stopAllListeners();
        }
        
        // Destroy charts
        if (this.dataViz) {
            this.dataViz.destroyAllCharts();
        }
        
        // Destroy drag and drop
        if (this.dragDropManager) {
            this.dragDropManager.destroy();
        }
    }
}

// Initialize application
const app = new StraightWayApp();

// Export for global use
window.StraightWayApp = StraightWayApp;
window.app = app;

// Handle page load
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, application should be initializing...');
});