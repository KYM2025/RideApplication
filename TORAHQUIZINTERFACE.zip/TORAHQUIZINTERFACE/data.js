// STRAIGHT-WAY RIDESHARE PLATFORM DATA
// Extracted from PDF files and structured for interactive interface

// Sample ride history data
const rideHistoryData = [
  {
    user_id: "user_001",
    ride_id: "ride_001",
    pickup_location: "Downtown Jerusalem",
    dropoff_location: "Mount of Olives",
    distance_km: 5.2,
    fare_amount: 25.50,
    ride_date: "2024-01-15T10:30:00Z",
    ride_streak_day: 3
  },
  {
    user_id: "user_001",
    ride_id: "ride_002",
    pickup_location: "Western Wall",
    dropoff_location: "Mahane Yehuda Market",
    distance_km: 2.8,
    fare_amount: 15.75,
    ride_date: "2024-01-16T14:20:00Z",
    ride_streak_day: 4
  },
  {
    user_id: "user_002",
    ride_id: "ride_003",
    pickup_location: "Tel Aviv Central",
    dropoff_location: "Jaffa Port",
    distance_km: 8.1,
    fare_amount: 32.00,
    ride_date: "2024-01-17T09:15:00Z",
    ride_streak_day: 1
  }
];

// Driver feedback data
const driverFeedbackData = [
  {
    ride_id: "ride_001",
    driver_id: "driver_001",
    user_id: "user_001",
    star_rating: 5,
    comment: "Excellent service! Very respectful and knowledgeable about the city.",
    sentiment_score: 0.9
  },
  {
    ride_id: "ride_002",
    driver_id: "driver_002",
    user_id: "user_001",
    star_rating: 4,
    comment: "Good ride, arrived on time.",
    sentiment_score: 0.7
  },
  {
    ride_id: "ride_003",
    driver_id: "driver_001",
    user_id: "user_002",
    star_rating: 5,
    comment: "Amazing driver! Shared beautiful insights about Torah during the ride.",
    sentiment_score: 0.95
  }
];

// Torah quiz progress data
const torahQuizData = [
  {
    user_id: "user_001",
    quiz_id: "quiz_001",
    question_id: "q_001",
    question: "Who led the Israelites out of Egypt?",
    answer: "Moses",
    choices: ["Abraham", "Moses", "David", "Aaron"],
    correct: true,
    points_awarded: 10
  },
  {
    user_id: "user_001",
    quiz_id: "quiz_002",
    question_id: "q_002",
    question: "Which book comes first in the Torah?",
    answer: "Genesis",
    choices: ["Genesis", "Exodus", "Leviticus", "Numbers"],
    correct: true,
    points_awarded: 10
  },
  {
    user_id: "user_002",
    quiz_id: "quiz_003",
    question_id: "q_003",
    question: "How many days did it take to create the world?",
    answer: "6",
    choices: ["5", "6", "7", "8"],
    correct: false,
    points_awarded: 0
  }
];

// Notifications data
const notificationsData = [
  {
    user_id: "user_001",
    message_title: "Points Unlocked!",
    message_body: "You've unlocked 10 pts!",
    type: "reward",
    created_at: "2024-01-17T12:00:00Z",
    is_read: false,
    icon: "🔔"
  },
  {
    user_id: "user_001",
    message_title: "Bonus Ride Day",
    message_body: "Friday = Bonus Ride Day",
    type: "promotion",
    created_at: "2024-01-17T08:00:00Z",
    is_read: false,
    icon: "📅"
  },
  {
    user_id: "user_001",
    message_title: "New Torah Drop",
    message_body: "New Drop is available",
    type: "quiz",
    created_at: "2024-01-16T20:00:00Z",
    is_read: false,
    icon: "🧠"
  },
  {
    user_id: "user_001",
    message_title: "Referral Success",
    message_body: "Keisha joined via you",
    type: "referral",
    created_at: "2024-01-15T16:30:00Z",
    is_read: false,
    icon: "👥"
  }
];

// Backend function templates data
const backendFunctions = [
  {
    name: "logRide",
    description: "Records trip data when a ride is completed",
    agent: "Ride Logger Agent",
    parameters: ["userId", "from", "to", "distance", "price", "date"]
  },
  {
    name: "updateUserStats",
    description: "Updates the user's streak and total miles on every new ride",
    agent: "Streak & Mileage Tracker Agent",
    parameters: ["rideId", "userId", "distance"]
  },
  {
    name: "submitDriverRating",
    description: "Captures post-ride ratings and comments",
    agent: "Driver Rating Collector Agent",
    parameters: ["rideId", "driverId", "rating", "comment"]
  },
  {
    name: "getTorahQuiz",
    description: "Provides randomized Torah-based quiz content",
    agent: "Torah Quiz Engine",
    parameters: []
  },
  {
    name: "sendNotification",
    description: "Sends user-specific system alerts and updates",
    agent: "Notification Delivery Agent",
    parameters: ["userId", "message", "type"]
  },
  {
    name: "trackReferral",
    description: "Links newly joined users to their referrer",
    agent: "Referral Tracker Agent",
    parameters: ["newUserId", "referrerId"]
  },
  {
    name: "updatePoints",
    description: "Updates a user's total earned points",
    agent: "Points Management Agent",
    parameters: ["userId", "points"]
  }
];

// User statistics
const userStats = {
  totalRides: 15,
  totalMiles: 127.5,
  currentStreak: 5,
  totalPoints: 250,
  averageRating: 4.8,
  referrals: 3,
  quizScore: 85
};

// Export all data for use in the interface
window.appData = {
  rideHistory: rideHistoryData,
  driverFeedback: driverFeedbackData,
  torahQuiz: torahQuizData,
  notifications: notificationsData,
  backendFunctions: backendFunctions,
  userStats: userStats
};