// STRAIGHT-WAY TORAH QUIZ INTERFACE - INTERACTIVE APPLICATION
// Comprehensive functionality for data visualization and user interaction

class StraightWayInterface {
    constructor() {
        this.currentSection = 'notifications';
        this.currentQuizIndex = 0;
        this.charts = {};
        this.filteredData = {};
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadNotifications();
        this.loadUserStats();
        this.setupSearch();
        this.initializeCharts();
        this.loadAllSections();
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const section = e.currentTarget.dataset.section;
                this.switchSection(section);
            });
        });

        // Global search
        document.getElementById('globalSearch').addEventListener('input', (e) => {
            this.performGlobalSearch(e.target.value);
        });

        // Filter listeners
        document.getElementById('notificationFilter')?.addEventListener('change', (e) => {
            this.filterNotifications(e.target.value);
        });

        document.getElementById('ratingFilter')?.addEventListener('change', (e) => {
            this.filterFeedback('rating', e.target.value);
        });

        document.getElementById('sentimentFilter')?.addEventListener('change', (e) => {
            this.filterFeedback('sentiment', e.target.value);
        });

        document.getElementById('dateFilter')?.addEventListener('change', (e) => {
            this.filterRides('date', e.target.value);
        });

        document.getElementById('functionSearch')?.addEventListener('input', (e) => {
            this.searchFunctions(e.target.value);
        });

        // Modal close
        window.addEventListener('click', (e) => {
            if (e.target.classList.contains('modal')) {
                this.closeModal();
            }
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeModal();
            }
            if (e.ctrlKey || e.metaKey) {
                switch(e.key) {
                    case 'e':
                        e.preventDefault();
                        this.exportAllData();
                        break;
                    case 'f':
                        e.preventDefault();
                        document.getElementById('globalSearch').focus();
                        break;
                }
            }
        });
    }

    switchSection(sectionName) {
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');

        // Update content
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(sectionName).classList.add('active');

        this.currentSection = sectionName;

        // Load section-specific data
        switch(sectionName) {
            case 'notifications':
                this.loadNotifications();
                break;
            case 'torah-quiz':
                this.loadQuizInterface();
                break;
            case 'ride-history':
                this.loadRideHistory();
                break;
            case 'driver-feedback':
                this.loadDriverFeedback();
                break;
            case 'backend-functions':
                this.loadBackendFunctions();
                break;
            case 'analytics':
                this.loadAnalytics();
                break;
        }
    }

    loadNotifications() {
        const container = document.getElementById('notificationsContainer');
        if (!container) return;

        const notifications = window.appData.notifications;
        container.innerHTML = '';

        notifications.forEach((notification, index) => {
            const card = this.createNotificationCard(notification, index);
            container.appendChild(card);
        });

        this.setupNotificationInteractions();
    }

    createNotificationCard(notification, index) {
        const card = document.createElement('div');
        card.className = `notification-card ${!notification.is_read ? 'unread' : ''}`;
        card.dataset.index = index;
        
        card.innerHTML = `
            <div class="notification-icon">
                ${notification.icon || '🔔'}
            </div>
            <div class="notification-content">
                <div class="notification-title">${notification.message_title}</div>
                <div class="notification-body">${notification.message_body}</div>
            </div>
            <div class="notification-time">
                ${this.formatDate(notification.created_at)}
            </div>
        `;

        card.addEventListener('click', () => {
            this.showNotificationDetails(notification, index);
        });

        return card;
    }

    setupNotificationInteractions() {
        // Add drag and drop functionality
        const cards = document.querySelectorAll('.notification-card');
        cards.forEach(card => {
            card.draggable = true;
            card.addEventListener('dragstart', this.handleDragStart.bind(this));
            card.addEventListener('dragover', this.handleDragOver.bind(this));
            card.addEventListener('drop', this.handleDrop.bind(this));
        });
    }

    loadQuizInterface() {
        const container = document.getElementById('quizContent');
        if (!container) return;

        const quizData = window.appData.torahQuiz;
        if (quizData.length === 0) {
            container.innerHTML = '<p>No quiz data available.</p>';
            return;
        }

        const currentQuiz = quizData[this.currentQuizIndex] || quizData[0];
        
        container.innerHTML = `
            <div class="quiz-question">
                <div class="question-text">${currentQuiz.question}</div>
                <div class="quiz-choices">
                    ${currentQuiz.choices.map((choice, index) => `
                        <button class="choice-btn" data-choice="${choice}" onclick="app.selectAnswer('${choice}', '${currentQuiz.answer}')">
                            ${choice}
                        </button>
                    `).join('')}
                </div>
            </div>
        `;

        this.updateQuizProgress();
        this.loadQuizHistory();
    }

    selectAnswer(selected, correct) {
        const buttons = document.querySelectorAll('.choice-btn');
        buttons.forEach(btn => {
            btn.disabled = true;
            if (btn.dataset.choice === correct) {
                btn.classList.add('correct');
            } else if (btn.dataset.choice === selected && selected !== correct) {
                btn.classList.add('incorrect');
            }
        });

        setTimeout(() => {
            this.nextQuestion();
        }, 2000);
    }

    nextQuestion() {
        const quizData = window.appData.torahQuiz;
        this.currentQuizIndex = (this.currentQuizIndex + 1) % quizData.length;
        this.loadQuizInterface();
    }

    updateQuizProgress() {
        const progressFill = document.getElementById('quizProgress');
        const progressText = document.getElementById('progressText');
        const quizData = window.appData.torahQuiz;
        
        if (progressFill && progressText) {
            const progress = ((this.currentQuizIndex + 1) / quizData.length) * 100;
            progressFill.style.width = `${progress}%`;
            progressText.textContent = `Question ${this.currentQuizIndex + 1} of ${quizData.length}`;
        }
    }

    loadQuizHistory() {
        const container = document.getElementById('quizHistoryList');
        if (!container) return;

        const quizData = window.appData.torahQuiz;
        container.innerHTML = '';

        quizData.forEach((quiz, index) => {
            const item = document.createElement('div');
            item.className = 'quiz-history-item';
            item.innerHTML = `
                <div class="quiz-question-preview">${quiz.question}</div>
                <div class="quiz-result ${quiz.correct ? 'correct' : 'incorrect'}">
                    ${quiz.correct ? '✓' : '✗'} ${quiz.points_awarded} pts
                </div>
            `;
            container.appendChild(item);
        });
    }

    loadRideHistory() {
        const tableBody = document.getElementById('ridesTableBody');
        if (!tableBody) return;

        const rides = window.appData.rideHistory;
        tableBody.innerHTML = '';

        rides.forEach((ride, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${this.formatDate(ride.ride_date)}</td>
                <td>${ride.pickup_location}</td>
                <td>${ride.dropoff_location}</td>
                <td>${ride.distance_km} km</td>
                <td>$${ride.fare_amount}</td>
                <td>${ride.ride_streak_day}</td>
                <td>
                    <button class="action-btn" onclick="app.showRideDetails(${index})">
                        <i class="fas fa-eye"></i> View
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });

        this.updateLocationFilter();
    }

    updateLocationFilter() {
        const filter = document.getElementById('locationFilter');
        if (!filter) return;

        const rides = window.appData.rideHistory;
        const locations = new Set();
        
        rides.forEach(ride => {
            locations.add(ride.pickup_location);
            locations.add(ride.dropoff_location);
        });

        filter.innerHTML = '<option value="all">All Locations</option>';
        Array.from(locations).sort().forEach(location => {
            const option = document.createElement('option');
            option.value = location;
            option.textContent = location;
            filter.appendChild(option);
        });
    }

    loadDriverFeedback() {
        const container = document.getElementById('feedbackList');
        const breakdown = document.getElementById('ratingBreakdown');
        
        if (!container) return;

        const feedback = window.appData.driverFeedback;
        container.innerHTML = '';

        // Load rating breakdown
        if (breakdown) {
            const ratings = [5, 4, 3, 2, 1];
            const ratingCounts = {};
            
            feedback.forEach(item => {
                ratingCounts[item.star_rating] = (ratingCounts[item.star_rating] || 0) + 1;
            });

            breakdown.innerHTML = ratings.map(rating => {
                const count = ratingCounts[rating] || 0;
                const percentage = feedback.length > 0 ? (count / feedback.length) * 100 : 0;
                
                return `
                    <div class="rating-bar">
                        <span>${rating} ⭐</span>
                        <div class="rating-bar-fill">
                            <div class="rating-bar-progress" style="width: ${percentage}%"></div>
                        </div>
                        <span>${count}</span>
                    </div>
                `;
            }).join('');
        }

        // Load feedback items
        feedback.forEach((item, index) => {
            const feedbackItem = document.createElement('div');
            feedbackItem.className = 'feedback-item';
            feedbackItem.innerHTML = `
                <div class="feedback-header">
                    <div class="feedback-rating">
                        ${'⭐'.repeat(item.star_rating)}
                    </div>
                    <div class="feedback-sentiment ${this.getSentimentClass(item.sentiment_score)}">
                        ${this.getSentimentLabel(item.sentiment_score)}
                    </div>
                </div>
                <div class="feedback-comment">"${item.comment}"</div>
                <div class="feedback-meta">
                    Ride ID: ${item.ride_id} | Driver ID: ${item.driver_id}
                </div>
            `;
            
            feedbackItem.addEventListener('click', () => {
                this.showFeedbackDetails(item, index);
            });
            
            container.appendChild(feedbackItem);
        });
    }

    loadBackendFunctions() {
        const container = document.getElementById('functionsGrid');
        if (!container) return;

        const functions = window.appData.backendFunctions;
        container.innerHTML = '';

        functions.forEach((func, index) => {
            const card = document.createElement('div');
            card.className = 'function-card';
            card.innerHTML = `
                <div class="function-name">${func.name}</div>
                <div class="function-description">${func.description}</div>
                <div class="function-agent">${func.agent}</div>
                <div class="function-params">
                    Parameters: ${func.parameters.length > 0 ? func.parameters.join(', ') : 'None'}
                </div>
                <button class="test-function-btn" onclick="app.testFunction('${func.name}')">
                    <i class="fas fa-play"></i> Test Function
                </button>
            `;
            container.appendChild(card);
        });
    }

    loadAnalytics() {
        this.initializeCharts();
        this.updateAnalyticsData();
    }

    initializeCharts() {
        // Ride Trends Chart
        const rideTrendsCtx = document.getElementById('rideTrendsChart');
        if (rideTrendsCtx && !this.charts.rideTrends) {
            this.charts.rideTrends = new Chart(rideTrendsCtx, {
                type: 'line',
                data: {
                    labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
                    datasets: [{
                        label: 'Rides per Day',
                        data: [2, 3, 1, 4, 5, 3, 2],
                        borderColor: '#3498db',
                        backgroundColor: 'rgba(52, 152, 219, 0.1)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        }

        // Quiz Performance Chart
        const quizPerformanceCtx = document.getElementById('quizPerformanceChart');
        if (quizPerformanceCtx && !this.charts.quizPerformance) {
            this.charts.quizPerformance = new Chart(quizPerformanceCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Correct', 'Incorrect'],
                    datasets: [{
                        data: [85, 15],
                        backgroundColor: ['#27ae60', '#e74c3c']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }

        // Rating Distribution Chart
        const ratingDistributionCtx = document.getElementById('ratingDistributionChart');
        if (ratingDistributionCtx && !this.charts.ratingDistribution) {
            this.charts.ratingDistribution = new Chart(ratingDistributionCtx, {
                type: 'bar',
                data: {
                    labels: ['1⭐', '2⭐', '3⭐', '4⭐', '5⭐'],
                    datasets: [{
                        label: 'Number of Ratings',
                        data: [0, 0, 0, 1, 2],
                        backgroundColor: '#f39c12'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    }
                }
            });
        }

        // Notification Types Chart
        const notificationTypesCtx = document.getElementById('notificationTypesChart');
        if (notificationTypesCtx && !this.charts.notificationTypes) {
            this.charts.notificationTypes = new Chart(notificationTypesCtx, {
                type: 'pie',
                data: {
                    labels: ['Rewards', 'Promotions', 'Quiz', 'Referrals'],
                    datasets: [{
                        data: [1, 1, 1, 1],
                        backgroundColor: ['#27ae60', '#3498db', '#9b59b6', '#e67e22']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false
                }
            });
        }
    }

    updateAnalyticsData() {
        // Update charts with real data
        const rides = window.appData.rideHistory;
        const feedback = window.appData.driverFeedback;
        const notifications = window.appData.notifications;
        const quizData = window.appData.torahQuiz;

        // Update ride trends
        if (this.charts.rideTrends) {
            const rideDates = rides.map(ride => new Date(ride.ride_date).getDay());
            const dailyCounts = [0, 0, 0, 0, 0, 0, 0];
            rideDates.forEach(day => dailyCounts[day]++);
            
            this.charts.rideTrends.data.datasets[0].data = dailyCounts;
            this.charts.rideTrends.update();
        }

        // Update rating distribution
        if (this.charts.ratingDistribution) {
            const ratingCounts = [0, 0, 0, 0, 0];
            feedback.forEach(item => {
                ratingCounts[item.star_rating - 1]++;
            });
            
            this.charts.ratingDistribution.data.datasets[0].data = ratingCounts;
            this.charts.ratingDistribution.update();
        }

        // Update notification types
        if (this.charts.notificationTypes) {
            const typeCounts = {};
            notifications.forEach(notif => {
                typeCounts[notif.type] = (typeCounts[notif.type] || 0) + 1;
            });
            
            this.charts.notificationTypes.data.datasets[0].data = Object.values(typeCounts);
            this.charts.notificationTypes.update();
        }

        // Update quiz performance
        if (this.charts.quizPerformance) {
            const correct = quizData.filter(q => q.correct).length;
            const incorrect = quizData.length - correct;
            
            this.charts.quizPerformance.data.datasets[0].data = [correct, incorrect];
            this.charts.quizPerformance.update();
        }
    }

    loadUserStats() {
        const stats = window.appData.userStats;
        
        // Update stat displays
        document.getElementById('totalRides').textContent = stats.totalRides;
        document.getElementById('totalMiles').textContent = stats.totalMiles;
        document.getElementById('currentStreak').textContent = stats.currentStreak;
        document.getElementById('quizScore').textContent = `${stats.quizScore}%`;
        document.getElementById('totalPoints').textContent = stats.totalPoints;
    }

    loadAllSections() {
        // Pre-load all sections for better performance
        this.loadRideHistory();
        this.loadDriverFeedback();
        this.loadBackendFunctions();
        this.loadAnalytics();
    }

    // Search and Filter Functions
    performGlobalSearch(query) {
        if (!query.trim()) {
            this.clearSearchResults();
            return;
        }

        const results = this.searchAllData(query.toLowerCase());
        this.displaySearchResults(results);
    }

    searchAllData(query) {
        const results = [];
        const data = window.appData;

        // Search notifications
        data.notifications.forEach((item, index) => {
            if (item.message_title.toLowerCase().includes(query) || 
                item.message_body.toLowerCase().includes(query)) {
                results.push({
                    type: 'notification',
                    item: item,
                    index: index,
                    section: 'notifications'
                });
            }
        });

        // Search rides
        data.rideHistory.forEach((item, index) => {
            if (item.pickup_location.toLowerCase().includes(query) || 
                item.dropoff_location.toLowerCase().includes(query)) {
                results.push({
                    type: 'ride',
                    item: item,
                    index: index,
                    section: 'ride-history'
                });
            }
        });

        // Search feedback
        data.driverFeedback.forEach((item, index) => {
            if (item.comment.toLowerCase().includes(query)) {
                results.push({
                    type: 'feedback',
                    item: item,
                    index: index,
                    section: 'driver-feedback'
                });
            }
        });

        // Search functions
        data.backendFunctions.forEach((item, index) => {
            if (item.name.toLowerCase().includes(query) || 
                item.description.toLowerCase().includes(query)) {
                results.push({
                    type: 'function',
                    item: item,
                    index: index,
                    section: 'backend-functions'
                });
            }
        });

        return results;
    }

    displaySearchResults(results) {
        // Create search results overlay
        let overlay = document.getElementById('searchOverlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'searchOverlay';
            overlay.className = 'search-overlay';
            document.body.appendChild(overlay);
        }

        overlay.innerHTML = `
            <div class="search-results">
                <div class="search-results-header">
                    <h3>Search Results (${results.length})</h3>
                    <button onclick="app.clearSearchResults()">&times;</button>
                </div>
                <div class="search-results-list">
                    ${results.map(result => `
                        <div class="search-result-item" onclick="app.goToSearchResult('${result.section}', ${result.index})">
                            <div class="result-type">${result.type}</div>
                            <div class="result-content">
                                ${this.getSearchResultPreview(result)}
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;

        overlay.style.display = 'block';
    }

    getSearchResultPreview(result) {
        switch(result.type) {
            case 'notification':
                return `<strong>${result.item.message_title}</strong><br>${result.item.message_body}`;
            case 'ride':
                return `<strong>Ride:</strong> ${result.item.pickup_location} → ${result.item.dropoff_location}`;
            case 'feedback':
                return `<strong>Rating:</strong> ${'⭐'.repeat(result.item.star_rating)}<br>${result.item.comment}`;
            case 'function':
                return `<strong>${result.item.name}</strong><br>${result.item.description}`;
            default:
                return 'Unknown result type';
        }
    }

    goToSearchResult(section, index) {
        this.clearSearchResults();
        this.switchSection(section);
        
        // Highlight the specific item
        setTimeout(() => {
            const items = document.querySelectorAll(`#${section} .notification-card, #${section} tr, #${section} .feedback-item, #${section} .function-card`);
            if (items[index]) {
                items[index].scrollIntoView({ behavior: 'smooth', block: 'center' });
                items[index].style.backgroundColor = 'rgba(52, 152, 219, 0.2)';
                setTimeout(() => {
                    items[index].style.backgroundColor = '';
                }, 2000);
            }
        }, 100);
    }

    clearSearchResults() {
        const overlay = document.getElementById('searchOverlay');
        if (overlay) {
            overlay.style.display = 'none';
        }
    }

    // Filter Functions
    filterNotifications(type) {
        const notifications = window.appData.notifications;
        const filtered = type === 'all' ? notifications : notifications.filter(n => n.type === type);
        
        const container = document.getElementById('notificationsContainer');
        container.innerHTML = '';
        
        filtered.forEach((notification, index) => {
            const card = this.createNotificationCard(notification, index);
            container.appendChild(card);
        });
        
        this.setupNotificationInteractions();
    }

    filterFeedback(filterType, value) {
        const feedback = window.appData.driverFeedback;
        let filtered = feedback;

        if (filterType === 'rating' && value !== 'all') {
            filtered = feedback.filter(f => f.star_rating === parseInt(value));
        } else if (filterType === 'sentiment' && value !== 'all') {
            filtered = feedback.filter(f => {
                const sentiment = this.getSentimentLabel(f.sentiment_score).toLowerCase();
                return sentiment === value;
            });
        }

        this.displayFilteredFeedback(filtered);
    }

    displayFilteredFeedback(filtered) {
        const container = document.getElementById('feedbackList');
        container.innerHTML = '';

        filtered.forEach((item, index) => {
            const feedbackItem = document.createElement('div');
            feedbackItem.className = 'feedback-item';
            feedbackItem.innerHTML = `
                <div class="feedback-header">
                    <div class="feedback-rating">
                        ${'⭐'.repeat(item.star_rating)}
                    </div>
                    <div class="feedback-sentiment ${this.getSentimentClass(item.sentiment_score)}">
                        ${this.getSentimentLabel(item.sentiment_score)}
                    </div>
                </div>
                <div class="feedback-comment">"${item.comment}"</div>
                <div class="feedback-meta">
                    Ride ID: ${item.ride_id} | Driver ID: ${item.driver_id}
                </div>
            `;
            
            feedbackItem.addEventListener('click', () => {
                this.showFeedbackDetails(item, index);
            });
            
            container.appendChild(feedbackItem);
        });
    }

    filterRides(filterType, value) {
        const rides = window.appData.rideHistory;
        let filtered = rides;

        if (filterType === 'date' && value) {
            const filterDate = new Date(value).toDateString();
            filtered = rides.filter(r => new Date(r.ride_date).toDateString() === filterDate);
        }

        this.displayFilteredRides(filtered);
    }

    displayFilteredRides(filtered) {
        const tableBody = document.getElementById('ridesTableBody');
        tableBody.innerHTML = '';

        filtered.forEach((ride, index) => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${this.formatDate(ride.ride_date)}</td>
                <td>${ride.pickup_location}</td>
                <td>${ride.dropoff_location}</td>
                <td>${ride.distance_km} km</td>
                <td>$${ride.fare_amount}</td>
                <td>${ride.ride_streak_day}</td>
                <td>
                    <button class="action-btn" onclick="app.showRideDetails(${index})">
                        <i class="fas fa-eye"></i> View
                    </button>
                </td>
            `;
            tableBody.appendChild(row);
        });
    }

    searchFunctions(query) {
        const functions = window.appData.backendFunctions;
        const filtered = query ? functions.filter(f => 
            f.name.toLowerCase().includes(query.toLowerCase()) ||
            f.description.toLowerCase().includes(query.toLowerCase()) ||
            f.agent.toLowerCase().includes(query.toLowerCase())
        ) : functions;

        this.displayFilteredFunctions(filtered);
    }

    displayFilteredFunctions(filtered) {
        const container = document.getElementById('functionsGrid');
        container.innerHTML = '';

        filtered.forEach((func, index) => {
            const card = document.createElement('div');
            card.className = 'function-card';
            card.innerHTML = `
                <div class="function-name">${func.name}</div>
                <div class="function-description">${func.description}</div>
                <div class="function-agent">${func.agent}</div>
                <div class="function-params">
                    Parameters: ${func.parameters.length > 0 ? func.parameters.join(', ') : 'None'}
                </div>
                <button class="test-function-btn" onclick="app.testFunction('${func.name}')">
                    <i class="fas fa-play"></i> Test Function
                </button>
            `;
            container.appendChild(card);
        });
    }

    // Modal Functions
    showNotificationDetails(notification, index) {
        const modalBody = document.getElementById('modalBody');
        modalBody.innerHTML = `
            <h2>${notification.message_title}</h2>
            <div class="notification-details">
                <p><strong>Message:</strong> ${notification.message_body}</p>
                <p><strong>Type:</strong> ${notification.type}</p>
                <p><strong>Created:</strong> ${this.formatDate(notification.created_at)}</p>
                <p><strong>Status:</strong> ${notification.is_read ? 'Read' : 'Unread'}</p>
                <p><strong>User ID:</strong> ${notification.user_id}</p>
            </div>
            <div class="modal-actions">
                <button class="action-btn" onclick="app.markAsRead(${index})">
                    Mark as Read
                </button>
                <button class="action-btn" onclick="app.deleteNotification(${index})">
                    Delete
                </button>
            </div>
        `;
        this.showModal();
    }

    showRideDetails(index) {
        const ride = window.appData.rideHistory[index];
        const modalBody = document.getElementById('modalBody');
        modalBody.innerHTML = `
            <h2>Ride Details</h2>
            <div class="ride-details">
                <p><strong>Ride ID:</strong> ${ride.ride_id}</p>
                <p><strong>Date:</strong> ${this.formatDate(ride.ride_date)}</p>
                <p><strong>From:</strong> ${ride.pickup_location}</p>
                <p><strong>To:</strong> ${ride.dropoff_location}</p>
                <p><strong>Distance:</strong> ${ride.distance_km} km</p>
                <p><strong>Fare:</strong> $${ride.fare_amount}</p>
                <p><strong>Streak Day:</strong> ${ride.ride_streak_day}</p>
                <p><strong>User ID:</strong> ${ride.user_id}</p>
            </div>
            <div class="modal-actions">
                <button class="action-btn" onclick="app.exportRideData(${index})">
                    Export Ride
                </button>
            </div>
        `;
        this.showModal();
    }

    showFeedbackDetails(feedback, index) {
        const modalBody = document.getElementById('modalBody');
        modalBody.innerHTML = `
            <h2>Driver Feedback Details</h2>
            <div class="feedback-details">
                <p><strong>Ride ID:</strong> ${feedback.ride_id}</p>
                <p><strong>Driver ID:</strong> ${feedback.driver_id}</p>
                <p><strong>Rating:</strong> ${'⭐'.repeat(feedback.star_rating)}</p>
                <p><strong>Comment:</strong> "${feedback.comment}"</p>
                <p><strong>Sentiment Score:</strong> ${feedback.sentiment_score}</p>
                <p><strong>Sentiment:</strong> ${this.getSentimentLabel(feedback.sentiment_score)}</p>
                <p><strong>User ID:</strong> ${feedback.user_id}</p>
            </div>
            <div class="modal-actions">
                <button class="action-btn" onclick="app.exportFeedbackData(${index})">
                    Export Feedback
                </button>
            </div>
        `;
        this.showModal();
    }

    showModal() {
        document.getElementById('modal').style.display = 'block';
    }

    closeModal() {
        document.getElementById('modal').style.display = 'none';
    }

    // Utility Functions
    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
    }

    getSentimentClass(score) {
        if (score >= 0.7) return 'positive';
        if (score >= 0.3) return 'neutral';
        return 'negative';
    }

    getSentimentLabel(score) {
        if (score >= 0.7) return 'Positive';
        if (score >= 0.3) return 'Neutral';
        return 'Negative';
    }

    // Drag and Drop Functions
    handleDragStart(e) {
        e.dataTransfer.setData('text/plain', e.target.dataset.index);
        e.target.style.opacity = '0.5';
    }

    handleDragOver(e) {
        e.preventDefault();
        e.currentTarget.classList.add('drag-over');
    }

    handleDrop(e) {
        e.preventDefault();
        e.currentTarget.classList.remove('drag-over');
        
        const draggedIndex = e.dataTransfer.getData('text/plain');
        const targetIndex = e.currentTarget.dataset.index;
        
        if (draggedIndex !== targetIndex) {
            this.reorderNotifications(parseInt(draggedIndex), parseInt(targetIndex));
        }
        
        // Reset opacity
        document.querySelectorAll('.notification-card').forEach(card => {
            card.style.opacity = '1';
        });
    }

    reorderNotifications(fromIndex, toIndex) {
        const notifications = window.appData.notifications;
        const item = notifications.splice(fromIndex, 1)[0];
        notifications.splice(toIndex, 0, item);
        this.loadNotifications();
    }

    // Action Functions
    markAsRead(index) {
        window.appData.notifications[index].is_read = true;
        this.loadNotifications();
        this.closeModal();
    }

    deleteNotification(index) {
        window.appData.notifications.splice(index, 1);
        this.loadNotifications();
        this.closeModal();
    }

    toggleReadStatus() {
        const unreadCount = window.appData.notifications.filter(n => !n.is_read).length;
        
        if (unreadCount > 0) {
            // Mark all as read
            window.appData.notifications.forEach(n => n.is_read = true);
        } else {
            // Mark all as unread
            window.appData.notifications.forEach(n => n.is_read = false);
        }
        
        this.loadNotifications();
    }

    sortRides() {
        const rides = window.appData.rideHistory;
        rides.sort((a, b) => new Date(b.ride_date) - new Date(a.ride_date));
        this.loadRideHistory();
    }

    testFunction(functionName) {
        const func = window.appData.backendFunctions.find(f => f.name === functionName);
        if (!func) return;

        // Simulate function testing
        const testResult = {
            function: functionName,
            status: 'success',
            executionTime: Math.random() * 100 + 50,
            result: 'Function executed successfully'
        };

        this.showTestResult(testResult);
    }

    showTestResult(result) {
        const modalBody = document.getElementById('modalBody');
        modalBody.innerHTML = `
            <h2>Function Test Result</h2>
            <div class="test-result">
                <p><strong>Function:</strong> ${result.function}</p>
                <p><strong>Status:</strong> <span class="status-${result.status}">${result.status}</span></p>
                <p><strong>Execution Time:</strong> ${result.executionTime.toFixed(2)}ms</p>
                <p><strong>Result:</strong> ${result.result}</p>
            </div>
            <div class="modal-actions">
                <button class="action-btn" onclick="app.closeModal()">Close</button>
            </div>
        `;
        this.showModal();
    }

    testAllFunctions() {
        const functions = window.appData.backendFunctions;
        let completedTests = 0;
        const totalTests = functions.length;
        
        const progressModal = document.getElementById('modalBody');
        progressModal.innerHTML = `
            <h2>Testing All Functions</h2>
            <div class="test-progress">
                <div class="progress-bar">
                    <div class="progress-fill" id="testProgress" style="width: 0%"></div>
                </div>
                <p id="testStatus">Starting tests...</p>
            </div>
        `;
        this.showModal();

        functions.forEach((func, index) => {
            setTimeout(() => {
                completedTests++;
                const progress = (completedTests / totalTests) * 100;
                
                document.getElementById('testProgress').style.width = `${progress}%`;
                document.getElementById('testStatus').textContent =
                    `Testing ${func.name}... (${completedTests}/${totalTests})`;
                
                if (completedTests === totalTests) {
                    setTimeout(() => {
                        progressModal.innerHTML = `
                            <h2>All Tests Completed</h2>
                            <div class="test-summary">
                                <p><strong>Total Functions Tested:</strong> ${totalTests}</p>
                                <p><strong>Success Rate:</strong> 100%</p>
                                <p><strong>Average Execution Time:</strong> 75ms</p>
                            </div>
                            <div class="modal-actions">
                                <button class="action-btn" onclick="app.closeModal()">Close</button>
                            </div>
                        `;
                    }, 500);
                }
            }, index * 200);
        });
    }

    refreshAnalytics() {
        // Show loading state
        const button = event.target;
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Refreshing...';
        button.disabled = true;

        setTimeout(() => {
            this.updateAnalyticsData();
            button.innerHTML = originalText;
            button.disabled = false;
        }, 1500);
    }

    // Export Functions
    exportAllData() {
        const data = {
            exported_at: new Date().toISOString(),
            user_stats: window.appData.userStats,
            notifications: window.appData.notifications,
            ride_history: window.appData.rideHistory,
            driver_feedback: window.appData.driverFeedback,
            torah_quiz: window.appData.torahQuiz,
            backend_functions: window.appData.backendFunctions
        };

        this.downloadJSON(data, 'straight-way-data-export.json');
    }

    exportRideData(index) {
        const ride = window.appData.rideHistory[index];
        this.downloadJSON(ride, `ride-${ride.ride_id}.json`);
        this.closeModal();
    }

    exportFeedbackData(index) {
        const feedback = window.appData.driverFeedback[index];
        this.downloadJSON(feedback, `feedback-${feedback.ride_id}.json`);
        this.closeModal();
    }

    downloadJSON(data, filename) {
        const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    // Setup search functionality
    setupSearch() {
        // Add search overlay styles
        const searchStyles = `
            .search-overlay {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0, 0, 0, 0.5);
                backdrop-filter: blur(5px);
                z-index: 1001;
                display: none;
                padding: 2rem;
            }
            
            .search-results {
                background: white;
                border-radius: 12px;
                max-width: 800px;
                margin: 0 auto;
                max-height: 80vh;
                overflow-y: auto;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            }
            
            .search-results-header {
                padding: 1.5rem;
                border-bottom: 2px solid #e9ecef;
                display: flex;
                justify-content: space-between;
                align-items: center;
            }
            
            .search-results-header button {
                background: none;
                border: none;
                font-size: 1.5rem;
                cursor: pointer;
                color: #7f8c8d;
            }
            
            .search-results-list {
                padding: 1rem;
            }
            
            .search-result-item {
                padding: 1rem;
                border-radius: 8px;
                margin-bottom: 0.5rem;
                cursor: pointer;
                transition: background-color 0.2s ease;
            }
            
            .search-result-item:hover {
                background: rgba(52, 152, 219, 0.05);
            }
            
            .result-type {
                font-size: 0.8rem;
                color: #3498db;
                text-transform: uppercase;
                font-weight: 600;
                margin-bottom: 0.5rem;
            }
            
            .result-content {
                color: #2c3e50;
            }
        `;
        
        const styleSheet = document.createElement('style');
        styleSheet.textContent = searchStyles;
        document.head.appendChild(styleSheet);
    }
}

// Global functions for onclick handlers
function closeModal() {
    app.closeModal();
}

function exportAllData() {
    app.exportAllData();
}

function toggleReadStatus() {
    app.toggleReadStatus();
}

function sortRides() {
    app.sortRides();
}

function testAllFunctions() {
    app.testAllFunctions();
}

function refreshAnalytics() {
    app.refreshAnalytics();
}

// Initialize the application
let app;
document.addEventListener('DOMContentLoaded', () => {
    app = new StraightWayInterface();
});