// STRAIGHT-WAY RIDESHARE PLATFORM DATA
// Comprehensive data structure integrating all PDF content

// Sample Ride History Data
const rideHistoryData = [
    {
        user_id: "user_001",
        ride_id: "ride_001",
        pickup_location: "Downtown Jerusalem",
        dropoff_location: "Tel Aviv Central",
        distance_km: 65.2,
        fare_amount: 89.50,
        ride_date: "2024-01-15T08:30:00Z",
        ride_streak_day: 5,
        driver_id: "driver_001",
        status: "completed"
    },
    {
        user_id: "user_001",
        ride_id: "ride_002",
        pickup_location: "Ben Gurion Airport",
        dropoff_location: "Haifa Port",
        distance_km: 98.7,
        fare_amount: 125.00,
        ride_date: "2024-01-16T14:15:00Z",
        ride_streak_day: 6,
        driver_id: "driver_002",
        status: "completed"
    },
    {
        user_id: "user_001",
        ride_id: "ride_003",
        pickup_location: "Old City Jerusalem",
        dropoff_location: "Mount of Olives",
        distance_km: 12.3,
        fare_amount: 25.75,
        ride_date: "2024-01-17T16:45:00Z",
        ride_streak_day: 7,
        driver_id: "driver_003",
        status: "completed"
    },
    {
        user_id: "user_001",
        ride_id: "ride_004",
        pickup_location: "Bethlehem",
        dropoff_location: "Hebron",
        distance_km: 28.9,
        fare_amount: 42.30,
        ride_date: "2024-01-18T10:20:00Z",
        ride_streak_day: 8,
        driver_id: "driver_001",
        status: "completed"
    },
    {
        user_id: "user_001",
        ride_id: "ride_005",
        pickup_location: "Nazareth",
        dropoff_location: "Sea of Galilee",
        distance_km: 35.6,
        fare_amount: 58.90,
        ride_date: "2024-01-19T12:00:00Z",
        ride_streak_day: 9,
        driver_id: "driver_004",
        status: "completed"
    }
];

// Sample Driver Feedback Data
const driverFeedbackData = [
    {
        ride_id: "ride_001",
        driver_id: "driver_001",
        user_id: "user_001",
        star_rating: 5,
        comment: "Excellent driver! Very knowledgeable about Torah and made the journey spiritually enriching.",
        sentiment_score: 0.95,
        timestamp: "2024-01-15T09:00:00Z"
    },
    {
        ride_id: "ride_002",
        driver_id: "driver_002",
        user_id: "user_001",
        star_rating: 4,
        comment: "Good service, clean car, arrived on time. Appreciated the Hebrew music.",
        sentiment_score: 0.78,
        timestamp: "2024-01-16T15:00:00Z"
    },
    {
        ride_id: "ride_003",
        driver_id: "driver_003",
        user_id: "user_001",
        star_rating: 5,
        comment: "Amazing experience! Driver shared beautiful insights about the holy sites we passed.",
        sentiment_score: 0.92,
        timestamp: "2024-01-17T17:15:00Z"
    },
    {
        ride_id: "ride_004",
        driver_id: "driver_001",
        user_id: "user_001",
        star_rating: 5,
        comment: "Second time with this driver - consistently excellent service and spiritual conversation.",
        sentiment_score: 0.88,
        timestamp: "2024-01-18T11:00:00Z"
    },
    {
        ride_id: "ride_005",
        driver_id: "driver_004",
        user_id: "user_001",
        star_rating: 4,
        comment: "Safe driver, comfortable ride. Would appreciate more Torah discussion during the journey.",
        sentiment_score: 0.72,
        timestamp: "2024-01-19T12:45:00Z"
    }
];

// Torah Quiz Questions and Progress Data
const torahQuizData = [
    {
        quiz_id: "quiz_001",
        question: "Who led the Israelites out of Egypt?",
        choices: ["Abraham", "Moses", "David", "Aaron"],
        correct_answer: "Moses",
        explanation: "Moses was chosen by YAHOSHUA to lead the Israelites out of Egyptian bondage, as recorded in the book of Exodus.",
        difficulty: "easy",
        category: "Exodus"
    },
    {
        quiz_id: "quiz_002",
        question: "Which book comes first in the Torah?",
        choices: ["Genesis", "Exodus", "Leviticus", "Numbers"],
        correct_answer: "Genesis",
        explanation: "Genesis (Bereshit) is the first book of the Torah, beginning with the creation of the world.",
        difficulty: "easy",
        category: "Torah Structure"
    },
    {
        quiz_id: "quiz_003",
        question: "How many days did YAHOSHUA create the world?",
        choices: ["5 days", "6 days", "7 days", "8 days"],
        correct_answer: "6 days",
        explanation: "YAHOSHUA created the world in 6 days and rested on the 7th day, establishing the Sabbath.",
        difficulty: "easy",
        category: "Creation"
    },
    {
        quiz_id: "quiz_004",
        question: "What was the name of Abraham's wife?",
        choices: ["Sarah", "Rebecca", "Rachel", "Leah"],
        correct_answer: "Sarah",
        explanation: "Sarah was Abraham's wife, originally named Sarai before YAHOSHUA changed her name.",
        difficulty: "medium",
        category: "Patriarchs"
    },
    {
        quiz_id: "quiz_005",
        question: "How many tribes of Israel were there?",
        choices: ["10", "11", "12", "13"],
        correct_answer: "12",
        explanation: "There were 12 tribes of Israel, descended from the 12 sons of Jacob (Israel).",
        difficulty: "easy",
        category: "Tribes"
    }
];

// User Quiz Progress Data
const torahQuizProgressData = [
    {
        user_id: "user_001",
        quiz_id: "quiz_001",
        question_id: "quiz_001",
        correct: true,
        answer: "Moses",
        points_awarded: 10,
        timestamp: "2024-01-15T20:00:00Z"
    },
    {
        user_id: "user_001",
        quiz_id: "quiz_002",
        question_id: "quiz_002",
        correct: true,
        answer: "Genesis",
        points_awarded: 10,
        timestamp: "2024-01-16T19:30:00Z"
    },
    {
        user_id: "user_001",
        quiz_id: "quiz_003",
        question_id: "quiz_003",
        correct: false,
        answer: "7 days",
        points_awarded: 0,
        timestamp: "2024-01-17T21:15:00Z"
    },
    {
        user_id: "user_001",
        quiz_id: "quiz_004",
        question_id: "quiz_004",
        correct: true,
        answer: "Sarah",
        points_awarded: 15,
        timestamp: "2024-01-18T20:45:00Z"
    }
];

// Notifications Data (matching the reference image)
const notificationsData = [
    {
        user_id: "user_001",
        notification_id: "notif_001",
        message_title: "You've unlocked 10 pts!",
        message_body: "Congratulations on completing your Torah quiz streak!",
        type: "achievement",
        icon: "🔔",
        created_at: "2024-01-19T15:30:00Z",
        is_read: false,
        priority: "high"
    },
    {
        user_id: "user_001",
        notification_id: "notif_002",
        message_title: "Friday = Bonus Ride Day",
        message_body: "Get double points for all rides taken on Shabbat preparation day!",
        type: "promotion",
        icon: "📅",
        created_at: "2024-01-19T14:00:00Z",
        is_read: false,
        priority: "medium"
    },
    {
        user_id: "user_001",
        notification_id: "notif_003",
        message_title: "New Drop is available",
        message_body: "Fresh Torah wisdom and spiritual insights await you!",
        type: "content",
        icon: "🧠",
        created_at: "2024-01-19T12:15:00Z",
        is_read: false,
        priority: "medium"
    },
    {
        user_id: "user_001",
        notification_id: "notif_004",
        message_title: "Keisha joined via you",
        message_body: "Your referral has successfully joined the Straight-Way community!",
        type: "referral",
        icon: "👥",
        created_at: "2024-01-19T10:30:00Z",
        is_read: true,
        priority: "low"
    },
    {
        user_id: "user_001",
        notification_id: "notif_005",
        message_title: "Weekly Torah Study",
        message_body: "Join us this Shabbat for community Torah study and discussion.",
        type: "event",
        icon: "📖",
        created_at: "2024-01-18T16:00:00Z",
        is_read: true,
        priority: "medium"
    }
];

// Referral Data
const referralData = [
    {
        referral_id: "ref_001",
        referrer_id: "user_001",
        new_user_id: "user_002",
        new_user_name: "Keisha",
        referral_code: "STRAIGHT001",
        bonus_points: 50,
        status: "completed",
        timestamp: "2024-01-19T10:30:00Z"
    },
    {
        referral_id: "ref_002",
        referrer_id: "user_001",
        new_user_id: "user_003",
        new_user_name: "David",
        referral_code: "STRAIGHT001",
        bonus_points: 50,
        status: "completed",
        timestamp: "2024-01-10T14:20:00Z"
    },
    {
        referral_id: "ref_003",
        referrer_id: "user_001",
        new_user_id: "user_004",
        new_user_name: "Sarah",
        referral_code: "STRAIGHT001",
        bonus_points: 50,
        status: "pending",
        timestamp: "2024-01-18T09:15:00Z"
    }
];

// User Profile Data
const userProfileData = {
    user_id: "user_001",
    name: "Abraham Cohen",
    email: "abraham.cohen@straightway.com",
    phone: "+972-50-123-4567",
    total_rides: 5,
    total_miles: 240.7,
    current_streak: 9,
    total_points: 485,
    quiz_score: 35,
    quiz_streak: 3,
    referral_count: 3,
    member_since: "2023-12-01T00:00:00Z",
    preferred_language: "Hebrew",
    cultural_background: "Orthodox Jewish",
    favorite_routes: ["Jerusalem-Tel Aviv", "Old City Tours"],
    achievements: [
        "First Ride Completed",
        "Torah Scholar (10 correct answers)",
        "Community Builder (3 referrals)",
        "Streak Master (7+ day streak)"
    ]
};

// Driver Data
const driverData = [
    {
        driver_id: "driver_001",
        name: "Moshe Goldstein",
        rating: 4.9,
        total_rides: 1247,
        years_experience: 8,
        specialties: ["Torah Discussion", "Holy Site Tours", "Hebrew Language"],
        vehicle: "Toyota Camry 2022",
        languages: ["Hebrew", "English", "Yiddish"]
    },
    {
        driver_id: "driver_002",
        name: "Rachel Levy",
        rating: 4.7,
        total_rides: 892,
        years_experience: 5,
        specialties: ["Family Friendly", "Airport Transfers", "Sabbath Preparation"],
        vehicle: "Honda Accord 2021",
        languages: ["Hebrew", "English", "French"]
    },
    {
        driver_id: "driver_003",
        name: "Yosef Ben-David",
        rating: 4.8,
        total_rides: 1456,
        years_experience: 12,
        specialties: ["Historical Tours", "Religious Sites", "Torah Wisdom"],
        vehicle: "Mercedes E-Class 2023",
        languages: ["Hebrew", "English", "Arabic"]
    },
    {
        driver_id: "driver_004",
        name: "Miriam Rosen",
        rating: 4.6,
        total_rides: 634,
        years_experience: 3,
        specialties: ["City Navigation", "Cultural Exchange", "Music & Prayer"],
        vehicle: "Hyundai Elantra 2022",
        languages: ["Hebrew", "English", "Russian"]
    }
];

// Analytics Data for Charts
const analyticsData = {
    rideActivity: {
        labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
        datasets: [{
            label: "Rides per Day",
            data: [12, 19, 15, 25, 35, 8, 5],
            backgroundColor: "rgba(52, 152, 219, 0.2)",
            borderColor: "rgba(52, 152, 219, 1)",
            borderWidth: 2,
            fill: true
        }]
    },
    pointsProgress: {
        labels: ["Week 1", "Week 2", "Week 3", "Week 4"],
        datasets: [{
            label: "Points Earned",
            data: [85, 125, 95, 180],
            backgroundColor: "rgba(243, 156, 18, 0.2)",
            borderColor: "rgba(243, 156, 18, 1)",
            borderWidth: 2,
            fill: true
        }]
    },
    userEngagement: {
        labels: ["Quiz Participation", "Ride Frequency", "Community Interaction", "Referrals"],
        datasets: [{
            label: "Engagement Score",
            data: [85, 92, 78, 65],
            backgroundColor: [
                "rgba(155, 89, 182, 0.8)",
                "rgba(52, 152, 219, 0.8)",
                "rgba(46, 204, 113, 0.8)",
                "rgba(231, 76, 60, 0.8)"
            ]
        }]
    },
    revenueData: {
        labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun"],
        datasets: [{
            label: "Revenue ($)",
            data: [1200, 1900, 1500, 2200, 2800, 2100],
            backgroundColor: "rgba(46, 204, 113, 0.2)",
            borderColor: "rgba(46, 204, 113, 1)",
            borderWidth: 2
        }]
    }
};

// Backend Function Templates (from PDF)
const backendFunctions = {
    logRide: {
        name: "Ride Logger Agent",
        description: "Records trip data when a ride is completed",
        parameters: ["userId", "from", "to", "distance", "price", "date"],
        implementation: "Firebase Cloud Function"
    },
    updateUserStats: {
        name: "Streak & Mileage Tracker Agent",
        description: "Updates the user's streak and total miles on every new ride",
        triggers: "On new ride creation",
        implementation: "Firestore trigger function"
    },
    submitDriverRating: {
        name: "Driver Rating Collector Agent",
        description: "Captures post-ride ratings and comments",
        parameters: ["rideId", "driverId", "rating", "comment"],
        implementation: "HTTP callable function"
    },
    analyzeSentiment: {
        name: "Sentiment Analysis Agent",
        description: "Analyzes tone and content of written driver feedback",
        integration: "External NLP API",
        implementation: "AI service integration"
    },
    getTorahQuiz: {
        name: "Torah Quiz Engine",
        description: "Provides randomized Torah-based quiz content",
        content: "Rotating question bank with spiritual insights",
        implementation: "Content management system"
    },
    sendNotification: {
        name: "Notification Delivery Agent",
        description: "Sends user-specific system alerts and updates",
        types: ["ride_alerts", "rewards", "promotions", "community_updates"],
        implementation: "Push notification service"
    },
    trackReferral: {
        name: "Referral Tracker Agent",
        description: "Links newly joined users to their referrer",
        parameters: ["newUserId", "referrerId"],
        implementation: "User relationship tracking"
    },
    updatePoints: {
        name: "Points Management Agent",
        description: "Updates a user's total earned points",
        triggers: ["quiz_completion", "ride_completion", "referral_bonus"],
        implementation: "Point system management"
    }
};

// Export all data for use in the application
window.appData = {
    rides: rideHistoryData,
    ratings: driverFeedbackData,
    quizQuestions: torahQuizData,
    quizProgress: torahQuizProgressData,
    notifications: notificationsData,
    referrals: referralData,
    user: userProfileData,
    drivers: driverData,
    analytics: analyticsData,
    functions: backendFunctions
};

// Helper functions for data manipulation
window.dataHelpers = {
    // Calculate total metrics
    getTotalRides: () => rideHistoryData.length,
    getTotalPoints: () => userProfileData.total_points,
    getCurrentStreak: () => userProfileData.current_streak,
    getTotalReferrals: () => referralData.filter(r => r.status === 'completed').length,
    
    // Get filtered data
    getRidesByDateRange: (startDate, endDate) => {
        return rideHistoryData.filter(ride => {
            const rideDate = new Date(ride.ride_date);
            return rideDate >= new Date(startDate) && rideDate <= new Date(endDate);
        });
    },
    
    getUnreadNotifications: () => {
        return notificationsData.filter(n => !n.is_read);
    },
    
    getRatingsByDriver: (driverId) => {
        return driverFeedbackData.filter(rating => rating.driver_id === driverId);
    },
    
    getAverageRating: () => {
        const total = driverFeedbackData.reduce((sum, rating) => sum + rating.star_rating, 0);
        return (total / driverFeedbackData.length).toFixed(1);
    },
    
    // Data export functions
    exportToCSV: (data, filename) => {
        const csv = convertToCSV(data);
        downloadCSV(csv, filename);
    },
    
    exportToJSON: (data, filename) => {
        const json = JSON.stringify(data, null, 2);
        downloadJSON(json, filename);
    }
};

// Utility functions
function convertToCSV(data) {
    if (!data || data.length === 0) return '';
    
    const headers = Object.keys(data[0]);
    const csvContent = [
        headers.join(','),
        ...data.map(row => headers.map(header => 
            JSON.stringify(row[header] || '')
        ).join(','))
    ].join('\n');
    
    return csvContent;
}

function downloadCSV(csv, filename) {
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', filename + '.csv');
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

function downloadJSON(json, filename) {
    const blob = new Blob([json], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', filename + '.json');
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}