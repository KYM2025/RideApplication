// STRAIGHT-WAY RIDESHARE PLATFORM - INTERACTIVE DASHBOARD
// Main JavaScript functionality for the comprehensive interface

class StraightWayDashboard {
    constructor() {
        this.currentSection = 'overview';
        this.charts = {};
        this.currentQuiz = null;
        this.quizScore = 0;
        this.quizStreak = 0;
        this.sortDirection = {};
        this.draggedElement = null;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.loadInitialData();
        this.initializeCharts();
        this.setupDragAndDrop();
        this.startLiveUpdates();
        
        // Show welcome toast
        this.showToast('Welcome to Straight-Way Dashboard!', 'success');
    }

    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                const section = e.currentTarget.dataset.section;
                this.switchSection(section);
            });
        });

        // Global search
        const searchInput = document.getElementById('globalSearch');
        searchInput.addEventListener('input', (e) => {
            this.performGlobalSearch(e.target.value);
        });

        // Data filter
        const dataFilter = document.getElementById('dataFilter');
        dataFilter.addEventListener('change', (e) => {
            this.filterData(e.target.value);
        });

        // Export button
        document.getElementById('exportBtn').addEventListener('click', () => {
            this.showExportModal();
        });

        // Metric cards (clickable for detailed view)
        document.querySelectorAll('.metric-card').forEach(card => {
            card.addEventListener('click', (e) => {
                const metric = e.currentTarget.dataset.metric;
                this.showMetricDetails(metric);
            });
        });

        // Table sorting
        document.querySelectorAll('[data-sort]').forEach(header => {
            header.addEventListener('click', (e) => {
                const sortKey = e.currentTarget.dataset.sort;
                this.sortTable(sortKey);
            });
        });

        // Quiz functionality
        document.getElementById('startQuizBtn').addEventListener('click', () => {
            this.startQuiz();
        });

        document.getElementById('nextQuestionBtn').addEventListener('click', () => {
            this.nextQuestion();
        });

        // Notification actions
        document.getElementById('markAllReadBtn').addEventListener('click', () => {
            this.markAllNotificationsRead();
        });

        document.getElementById('addNotificationBtn').addEventListener('click', () => {
            this.showAddNotificationModal();
        });

        // Rating functionality
        document.getElementById('addRatingBtn').addEventListener('click', () => {
            this.showAddRatingModal();
        });

        // Date filters for rides
        document.getElementById('filterRides').addEventListener('click', () => {
            this.filterRidesByDate();
        });

        // Modal controls
        document.getElementById('modalClose').addEventListener('click', () => {
            this.closeModal();
        });

        document.getElementById('modalCancel').addEventListener('click', () => {
            this.closeModal();
        });

        document.getElementById('modalSave').addEventListener('click', () => {
            this.saveModalData();
        });

        // Analytics timeframe
        const analyticsTimeframe = document.getElementById('analyticsTimeframe');
        if (analyticsTimeframe) {
            analyticsTimeframe.addEventListener('change', (e) => {
                this.updateAnalytics(e.target.value);
            });
        }

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            this.handleKeyboardShortcuts(e);
        });

        // Window resize for responsive charts
        window.addEventListener('resize', () => {
            this.resizeCharts();
        });
    }

    loadInitialData() {
        // Load metrics
        this.updateMetrics();
        
        // Load sections
        this.loadRideHistory();
        this.loadDriverRatings();
        this.loadNotifications();
        this.loadQuizData();
        
        // Update UI elements
        this.updateUserProfile();
    }

    updateMetrics() {
        const totalRides = window.dataHelpers.getTotalRides();
        const totalPoints = window.dataHelpers.getTotalPoints();
        const currentStreak = window.dataHelpers.getCurrentStreak();
        const totalReferrals = window.dataHelpers.getTotalReferrals();

        // Animate counter updates
        this.animateCounter('totalRides', totalRides);
        this.animateCounter('totalPoints', totalPoints);
        this.animateCounter('currentStreak', currentStreak);
        this.animateCounter('totalReferrals', totalReferrals);
    }

    animateCounter(elementId, targetValue) {
        const element = document.getElementById(elementId);
        const startValue = parseInt(element.textContent) || 0;
        const duration = 1000;
        const startTime = performance.now();

        const animate = (currentTime) => {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            
            const currentValue = Math.floor(startValue + (targetValue - startValue) * progress);
            element.textContent = currentValue;

            if (progress < 1) {
                requestAnimationFrame(animate);
            }
        };

        requestAnimationFrame(animate);
    }

    switchSection(sectionName) {
        // Update navigation
        document.querySelectorAll('.nav-item').forEach(item => {
            item.classList.remove('active');
        });
        document.querySelector(`[data-section="${sectionName}"]`).classList.add('active');

        // Update content
        document.querySelectorAll('.section').forEach(section => {
            section.classList.remove('active');
        });
        document.getElementById(sectionName).classList.add('active');

        this.currentSection = sectionName;

        // Load section-specific data
        this.loadSectionData(sectionName);
    }

    loadSectionData(sectionName) {
        switch(sectionName) {
            case 'overview':
                this.updateCharts();
                break;
            case 'rides':
                this.loadRideHistory();
                break;
            case 'ratings':
                this.loadDriverRatings();
                break;
            case 'quiz':
                this.loadQuizData();
                break;
            case 'notifications':
                this.loadNotifications();
                break;
            case 'analytics':
                this.loadAnalytics();
                break;
        }
    }

    initializeCharts() {
        // Ride Activity Chart
        const rideCtx = document.getElementById('rideChart');
        if (rideCtx) {
            this.charts.rideChart = new Chart(rideCtx, {
                type: 'line',
                data: window.appData.analytics.rideActivity,
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    }
                }
            });
        }

        // Points Progress Chart
        const pointsCtx = document.getElementById('pointsChart');
        if (pointsCtx) {
            this.charts.pointsChart = new Chart(pointsCtx, {
                type: 'bar',
                data: window.appData.analytics.pointsProgress,
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }
    }

    updateCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart) {
                chart.update();
            }
        });
    }

    resizeCharts() {
        Object.values(this.charts).forEach(chart => {
            if (chart) {
                chart.resize();
            }
        });
    }

    loadRideHistory() {
        const tableBody = document.getElementById('ridesTableBody');
        if (!tableBody) return;

        const rides = window.appData.rides;
        tableBody.innerHTML = '';

        rides.forEach(ride => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${new Date(ride.ride_date).toLocaleDateString()}</td>
                <td>${ride.pickup_location}</td>
                <td>${ride.dropoff_location}</td>
                <td>${ride.distance_km} km</td>
                <td>$${ride.fare_amount}</td>
                <td>
                    <span class="streak-badge">Day ${ride.ride_streak_day}</span>
                </td>
                <td>
                    <button class="btn-secondary btn-sm" onclick="dashboard.viewRideDetails('${ride.ride_id}')">
                        <i class="fas fa-eye"></i>
                    </button>
                    <button class="btn-secondary btn-sm" onclick="dashboard.editRide('${ride.ride_id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                </td>
            `;
            row.classList.add('draggable');
            row.draggable = true;
            row.dataset.rideId = ride.ride_id;
            tableBody.appendChild(row);
        });
    }

    loadDriverRatings() {
        const ratingsList = document.getElementById('ratingsList');
        const avgRatingElement = document.getElementById('avgRating');
        const avgStarsElement = document.getElementById('avgStars');
        
        if (!ratingsList) return;

        const ratings = window.appData.ratings;
        const avgRating = window.dataHelpers.getAverageRating();

        // Update average rating
        if (avgRatingElement) {
            avgRatingElement.textContent = avgRating;
        }

        // Update stars display
        if (avgStarsElement) {
            avgStarsElement.innerHTML = this.generateStarsHTML(parseFloat(avgRating));
        }

        // Load ratings list
        ratingsList.innerHTML = '';
        ratings.forEach(rating => {
            const ratingCard = document.createElement('div');
            ratingCard.className = 'rating-card';
            ratingCard.innerHTML = `
                <div class="rating-header">
                    <div class="rating-stars">
                        ${this.generateStarsHTML(rating.star_rating)}
                    </div>
                    <div class="rating-date">
                        ${new Date(rating.timestamp).toLocaleDateString()}
                    </div>
                </div>
                <div class="rating-comment">
                    "${rating.comment}"
                </div>
                <div class="rating-sentiment">
                    Sentiment: <span class="sentiment-score ${this.getSentimentClass(rating.sentiment_score)}">
                        ${(rating.sentiment_score * 100).toFixed(0)}%
                    </span>
                </div>
            `;
            ratingsList.appendChild(ratingCard);
        });
    }

    generateStarsHTML(rating) {
        let starsHTML = '';
        for (let i = 1; i <= 5; i++) {
            if (i <= rating) {
                starsHTML += '<i class="fas fa-star star"></i>';
            } else {
                starsHTML += '<i class="fas fa-star star empty"></i>';
            }
        }
        return starsHTML;
    }

    getSentimentClass(score) {
        if (score >= 0.8) return 'positive';
        if (score >= 0.6) return 'neutral';
        return 'negative';
    }

    loadNotifications() {
        const container = document.getElementById('notificationsContainer');
        if (!container) return;

        const notifications = window.appData.notifications;
        container.innerHTML = '';

        notifications.forEach(notification => {
            const notificationCard = document.createElement('div');
            notificationCard.className = `notification-card ${!notification.is_read ? 'unread' : ''}`;
            notificationCard.innerHTML = `
                <div class="notification-icon">
                    ${notification.icon}
                </div>
                <div class="notification-content">
                    <div class="notification-title">
                        ${notification.message_title}
                    </div>
                    <div class="notification-message">
                        ${notification.message_body}
                    </div>
                    <div class="notification-time">
                        ${this.formatTimeAgo(notification.created_at)}
                    </div>
                </div>
            `;
            
            notificationCard.addEventListener('click', () => {
                this.markNotificationRead(notification.notification_id);
                notificationCard.classList.remove('unread');
            });

            container.appendChild(notificationCard);
        });
    }

    formatTimeAgo(timestamp) {
        const now = new Date();
        const time = new Date(timestamp);
        const diffInSeconds = Math.floor((now - time) / 1000);

        if (diffInSeconds < 60) return 'Just now';
        if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)}m ago`;
        if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)}h ago`;
        return `${Math.floor(diffInSeconds / 86400)}d ago`;
    }

    loadQuizData() {
        const quizScore = document.getElementById('quizScore');
        const quizStreak = document.getElementById('quizStreak');
        const progressList = document.getElementById('quizProgress');

        if (quizScore) {
            const totalScore = window.appData.quizProgress.reduce((sum, q) => sum + q.points_awarded, 0);
            quizScore.textContent = totalScore;
            this.quizScore = totalScore;
        }

        if (quizStreak) {
            const streak = this.calculateQuizStreak();
            quizStreak.textContent = streak;
            this.quizStreak = streak;
        }

        if (progressList) {
            progressList.innerHTML = '';
            window.appData.quizProgress.forEach(progress => {
                const progressItem = document.createElement('div');
                progressItem.className = `progress-item ${progress.correct ? 'correct' : 'incorrect'}`;
                progressItem.innerHTML = `
                    <div class="progress-icon">
                        <i class="fas fa-${progress.correct ? 'check' : 'times'}"></i>
                    </div>
                    <div class="progress-content">
                        <div class="progress-question">Question ${progress.quiz_id.split('_')[1]}</div>
                        <div class="progress-points">+${progress.points_awarded} points</div>
                        <div class="progress-date">${new Date(progress.timestamp).toLocaleDateString()}</div>
                    </div>
                `;
                progressList.appendChild(progressItem);
            });
        }
    }

    calculateQuizStreak() {
        const progress = window.appData.quizProgress.sort((a, b) => 
            new Date(b.timestamp) - new Date(a.timestamp)
        );
        
        let streak = 0;
        for (const item of progress) {
            if (item.correct) {
                streak++;
            } else {
                break;
            }
        }
        return streak;
    }

    startQuiz() {
        const questions = window.appData.quizQuestions;
        this.currentQuiz = questions[Math.floor(Math.random() * questions.length)];
        
        const questionElement = document.getElementById('quizQuestion');
        const choicesElement = document.getElementById('quizChoices');
        const startBtn = document.getElementById('startQuizBtn');
        const nextBtn = document.getElementById('nextQuestionBtn');

        questionElement.textContent = this.currentQuiz.question;
        choicesElement.innerHTML = '';

        this.currentQuiz.choices.forEach((choice, index) => {
            const choiceElement = document.createElement('div');
            choiceElement.className = 'quiz-choice';
            choiceElement.textContent = choice;
            choiceElement.addEventListener('click', () => {
                this.selectQuizChoice(choiceElement, choice);
            });
            choicesElement.appendChild(choiceElement);
        });

        startBtn.style.display = 'none';
        nextBtn.style.display = 'inline-block';
    }

    selectQuizChoice(element, choice) {
        // Remove previous selections
        document.querySelectorAll('.quiz-choice').forEach(el => {
            el.classList.remove('selected', 'correct', 'incorrect');
        });

        element.classList.add('selected');

        // Show correct answer after selection
        setTimeout(() => {
            document.querySelectorAll('.quiz-choice').forEach(el => {
                if (el.textContent === this.currentQuiz.correct_answer) {
                    el.classList.add('correct');
                } else if (el.classList.contains('selected')) {
                    el.classList.add('incorrect');
                }
            });

            // Update score
            if (choice === this.currentQuiz.correct_answer) {
                this.quizScore += 10;
                this.quizStreak++;
                this.showToast('Correct! +10 points', 'success');
            } else {
                this.quizStreak = 0;
                this.showToast(`Incorrect. The answer was: ${this.currentQuiz.correct_answer}`, 'error');
            }

            // Update display
            document.getElementById('quizScore').textContent = this.quizScore;
            document.getElementById('quizStreak').textContent = this.quizStreak;

        }, 500);
    }

    nextQuestion() {
        this.startQuiz();
    }

    performGlobalSearch(query) {
        if (!query.trim()) {
            this.clearSearchResults();
            return;
        }

        const results = this.searchAllData(query.toLowerCase());
        this.displaySearchResults(results);
    }

    searchAllData(query) {
        const results = [];

        // Search rides
        window.appData.rides.forEach(ride => {
            if (ride.pickup_location.toLowerCase().includes(query) ||
                ride.dropoff_location.toLowerCase().includes(query)) {
                results.push({
                    type: 'ride',
                    data: ride,
                    relevance: this.calculateRelevance(query, ride.pickup_location + ' ' + ride.dropoff_location)
                });
            }
        });

        // Search ratings
        window.appData.ratings.forEach(rating => {
            if (rating.comment.toLowerCase().includes(query)) {
                results.push({
                    type: 'rating',
                    data: rating,
                    relevance: this.calculateRelevance(query, rating.comment)
                });
            }
        });

        // Search notifications
        window.appData.notifications.forEach(notification => {
            if (notification.message_title.toLowerCase().includes(query) ||
                notification.message_body.toLowerCase().includes(query)) {
                results.push({
                    type: 'notification',
                    data: notification,
                    relevance: this.calculateRelevance(query, notification.message_title + ' ' + notification.message_body)
                });
            }
        });

        return results.sort((a, b) => b.relevance - a.relevance);
    }

    calculateRelevance(query, text) {
        const lowerText = text.toLowerCase();
        const queryWords = query.split(' ');
        let relevance = 0;

        queryWords.forEach(word => {
            if (lowerText.includes(word)) {
                relevance += word.length;
            }
        });

        return relevance;
    }

    displaySearchResults(results) {
        // Create or update search results overlay
        let overlay = document.getElementById('searchResults');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.id = 'searchResults';
            overlay.className = 'search-results-overlay';
            document.body.appendChild(overlay);
        }

        overlay.innerHTML = `
            <div class="search-results-container">
                <div class="search-results-header">
                    <h3>Search Results (${results.length})</h3>
                    <button onclick="dashboard.clearSearchResults()" class="btn-secondary">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="search-results-list">
                    ${results.map(result => this.formatSearchResult(result)).join('')}
                </div>
            </div>
        `;

        overlay.style.display = 'block';
    }

    formatSearchResult(result) {
        switch(result.type) {
            case 'ride':
                return `
                    <div class="search-result-item" onclick="dashboard.goToRide('${result.data.ride_id}')">
                        <div class="result-icon"><i class="fas fa-car"></i></div>
                        <div class="result-content">
                            <div class="result-title">Ride: ${result.data.pickup_location} → ${result.data.dropoff_location}</div>
                            <div class="result-meta">${new Date(result.data.ride_date).toLocaleDateString()} • $${result.data.fare_amount}</div>
                        </div>
                    </div>
                `;
            case 'rating':
                return `
                    <div class="search-result-item" onclick="dashboard.goToRating('${result.data.ride_id}')">
                        <div class="result-icon"><i class="fas fa-star"></i></div>
                        <div class="result-content">
                            <div class="result-title">Rating: ${result.data.star_rating} stars</div>
                            <div class="result-meta">${result.data.comment.substring(0, 100)}...</div>
                        </div>
                    </div>
                `;
            case 'notification':
                return `
                    <div class="search-result-item" onclick="dashboard.goToNotification('${result.data.notification_id}')">
                        <div class="result-icon"><i class="fas fa-bell"></i></div>
                        <div class="result-content">
                            <div class="result-title">${result.data.message_title}</div>
                            <div class="result-meta">${result.data.message_body.substring(0, 100)}...</div>
                        </div>
                    </div>
                `;
            default:
                return '';
        }
    }

    clearSearchResults() {
        const overlay = document.getElementById('searchResults');
        if (overlay) {
            overlay.style.display = 'none';
        }
    }

    filterData(filterType) {
        // Implementation for filtering data based on type
        switch(filterType) {
            case 'rides':
                this.switchSection('rides');
                break;
            case 'ratings':
                this.switchSection('ratings');
                break;
            case 'quiz':
                this.switchSection('quiz');
                break;
            case 'notifications':
                this.switchSection('notifications');
                break;
            default:
                this.switchSection('overview');
        }
    }

    sortTable(sortKey) {
        const currentDirection = this.sortDirection[sortKey] || 'asc';
        const newDirection = currentDirection === 'asc' ? 'desc' : 'asc';
        this.sortDirection[sortKey] = newDirection;

        // Update sort indicators
        document.querySelectorAll('[data-sort] i').forEach(icon => {
            icon.className = 'fas fa-sort';
        });
        
        const currentHeader = document.querySelector(`[data-sort="${sortKey}"] i`);
        currentHeader.className = `fas fa-sort-${newDirection === 'asc' ? 'up' : 'down'}`;

        // Sort and reload data
        this.sortDataAndReload(sortKey, newDirection);
    }

    sortDataAndReload(sortKey, direction) {
        if (this.currentSection === 'rides') {
            const sortedRides = [...window.appData.rides].sort((a, b) => {
                let aVal = a[sortKey];
                let bVal = b[sortKey];

                if (sortKey === 'date') {
                    aVal = new Date(a.ride_date);
                    bVal = new Date(b.ride_date);
                }

                if (direction === 'asc') {
                    return aVal > bVal ? 1 : -1;
                } else {
                    return aVal < bVal ? 1 : -1;
                }
            });

            // Temporarily update data and reload
            const originalData = window.appData.rides;
            window.appData.rides = sortedRides;
            this.loadRideHistory();
            window.appData.rides = originalData;
        }
    }

    setupDragAndDrop() {
        // Enable drag and drop for table rows and cards
        document.addEventListener('dragstart', (e) => {
            if (e.target.classList.contains('draggable')) {
                this.draggedElement = e.target;
                e.target.style.opacity = '0.5';
            }
        });

        document.addEventListener('dragend', (e) => {
            if (e.target.classList.contains('draggable')) {
                e.target.style.opacity = '1';
                this.draggedElement = null;
            }
        });

        document.addEventListener('dragover', (e) => {
            e.preventDefault();
        });

        document.addEventListener('drop', (e) => {
            e.preventDefault();
            if (this.draggedElement && e.target.classList.contains('drop-zone')) {
                this.handleDrop(e.target);
            }
        });
    }

    handleDrop(dropZone) {
        if (this.draggedElement) {
            // Handle the drop based on the context
            this.showToast('Item moved successfully!', 'success');
        }
    }

    showExportModal() {
        const modal = document.getElementById('modalOverlay');
        const title = document.getElementById('modalTitle');
        const content = document.getElementById('modalContent');

        title.textContent = 'Export Data';
        content.innerHTML = `
            <div class="export-options">
                <h4>Select data to export:</h4>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="exportRides" checked> Ride History
                    </label>
                </div>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="exportRatings" checked> Driver Ratings
                    </label>
                </div>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="exportQuiz" checked> Quiz Progress
                    </label>
                </div>
                <div class="form-group">
                    <label class="checkbox-label">
                        <input type="checkbox" id="exportNotifications" checked> Notifications
                    </label>
                </div>
                <div class="form-group">
                    <label class="form-label">Export Format:</label>
                    <select id="exportFormat" class="form-input">
                        <option value="csv">CSV</option>
                        <option value="json">JSON</option>
                        <option value="pdf">PDF Report</option>
                    </select>
                </div>
            </div>
        `;

        modal.classList.add('active');
    }

    saveModalData() {
        const format = document.getElementById('exportFormat')?.value;
        const exportData = {};

        if (document.getElementById('exportRides')?.checked) {
            exportData.rides = window.appData.rides;
        }
        if (document.getElementById('exportRatings')?.checked) {
            exportData.ratings = window.appData.ratings;
        }
        if (document.getElementById('exportQuiz')?.checked) {
            exportData.quiz = window.appData.quizProgress;
        }
        if (document.getElementById('exportNotifications')?.checked) {
            exportData.notifications = window.appData.notifications;
        }

        this.exportData(exportData, format);
        this.closeModal();
    }

    exportData(data, format) {
        const timestamp = new Date().toISOString().split('T')[0];
        const filename = `straight-way-data-${timestamp}`;

        switch(format) {
            case 'csv':
                // Export each data type as separate CSV
                Object.keys(data).forEach(key => {
                    window.dataHelpers.exportToCSV(data[key], `${filename}-${key}`);
                });
                break;
            case 'json':
                window.dataHelpers.exportToJSON(data, filename);
                break;
            case 'pdf':
                this.generatePDFReport(data, filename);
                break;
        }

        this.showToast('Data exported successfully!', 'success');
    }

    generatePDFReport(data, filename) {
        // Simple PDF generation (in a real app, you'd use a library like jsPDF)
        const reportContent = this.generateReportContent(data);
        const blob = new Blob([reportContent], { type: 'text/plain' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename + '.txt';
        a.click();
        window.URL.revokeObjectURL(url);
    }

    generateReportContent(data) {
        let content = 'STRAIGHT-WAY RIDESHARE PLATFORM REPORT\n';
        content += '=====================================\n\n';
        content += `Generated: ${new Date().toLocaleString()}\n\n`;

        Object.keys(data).forEach(key => {
            content += `${key.toUpperCase()}:\n`;
            content += '-'.repeat(key.length + 1) + '\n';
            content += JSON.stringify(data[key], null, 2) + '\n\n';
        });

        return content;
    }

    closeModal() {
        document.getElementById('modalOverlay').classList.remove('active');
    }

    showToast(message, type = 'info') {
        const container = document.getElementById('toastContainer');
        const toast = document.createElement('div');
        toast.className = `toast ${type}`;
        toast.innerHTML = `
            <div class="toast-icon">
                <i class="fas fa-${type === 'success' ? 'check' : type === 'error' ? 'times' : 'info'}"></i>
            </div>
            <div class="toast-message">${message}</div>
        `;

        container.appendChild(toast);

        // Auto remove after 3 seconds
        setTimeout(() => {
            toast.remove();
        }, 3000);
    }

    startLiveUpdates() {
        // Simulate live data updates
        setInterval(() => {
            this.updateLiveData();
        }, 30000); // Update every 30 seconds
    }

    updateLiveData() {
        // Simulate new notifications
        if (Math.random() > 0.7) {
            this.addRandomNotification();
        }

        // Update metrics with small variations
        this.updateMetrics();
    }

    addRandomNotification() {
        const randomNotifications = [
            {
                message_title: "New ride available!",
                message_body: "A driver is nearby and ready to take you on your journey.",
                type: "ride_alert",
                icon: "🚗"
            },
            {
                message_title: "Torah quiz bonus!",
                message_body: "Double points available for the next hour!",
                type: "promotion",
                icon: "📚"
            },
            {
                message_title: "Community update",
                message_body: "New member joined your referral network.",
                type: "community",
                icon: "👥"
            }
        ];

        const randomNotif = randomNotifications[Math.floor(Math.random() * randomNotifications.length)];
        const newNotification = {
            ...randomNotif,
            notification_id: `notif_${Date.now()}`,
            user_id: "user_001",
            created_at: new Date().toISOString(),
            is_read: false,
            priority: "medium"
        };

        window.appData.notifications.unshift(newNotification);
        
        if (this.currentSection === 'notifications') {
            this.loadNotifications();
        }

        this.showToast(randomNotif.message_title, 'info');
    }

    markNotificationRead(notificationId) {
        const notification = window.appData.notifications.find(n => n.notification_id === notificationId);
        if (notification) {
            notification.is_read = true;
        }
    }

    markAllNotificationsRead() {
        window.appData.notifications.forEach(notification => {
            notification.is_read = true;
        });
        this.loadNotifications();
        this.showToast('All notifications marked as read', 'success');
    }

    showAddNotificationModal() {
        const modal = document.getElementById('modalOverlay');
        const title = document.getElementById('modalTitle');
        const content = document.getElementById('modalContent');

        title.textContent = 'Add Notification';
        content.innerHTML = `
            <div class="form-group">
                <label class="form-label">Title:</label>
                <input type="text" id="notifTitle" class="form-input" placeholder="Enter notification title">
            </div>
            <div class="form-group">
                <label class="form-label">Message:</label>
                <textarea id="notifMessage" class="form-input" rows="3" placeholder="Enter notification message"></textarea>
            </div>
            <div class="form-group">
                <label class="form-label">Type:</label>
                <select id="notifType" class="form-input">
                    <option value="achievement">Achievement</option>
                    <option value="promotion">Promotion</option>
                    <option value="content">Content</option>
                    <option value="referral">Referral</option>
                    <option value="event">Event</option>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Icon:</label>
                <input type="text" id="notifIcon" class="form-input" placeholder="Enter emoji or icon" value="🔔">
            </div>
        `;

        modal.classList.add('active');
    }

    showAddRatingModal() {
        const modal = document.getElementById('modalOverlay');
        const title = document.getElementById('modalTitle');
        const content = document.getElementById('modalContent');

        title.textContent = 'Add Driver Rating';
        content.innerHTML = `
            <div class="form-group">
                <label class="form-label">Ride:</label>
                <select id="ratingRideId" class="form-input">
                    ${window.appData.rides.map(ride =>
                        `<option value="${ride.ride_id}">${ride.pickup_location} → ${ride.dropoff_location}</option>`
                    ).join('')}
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Rating:</label>
                <div class="rating-input">
                    ${[1,2,3,4,5].map(star =>
                        `<i class="fas fa-star rating-star" data-rating="${star}"></i>`
                    ).join('')}
                </div>
                <input type="hidden" id="ratingValue" value="5">
            </div>
            <div class="form-group">
                <label class="form-label">Comment:</label>
                <textarea id="ratingComment" class="form-input" rows="3" placeholder="Share your experience..."></textarea>
            </div>
        `;

        // Add rating star interaction
        setTimeout(() => {
            document.querySelectorAll('.rating-star').forEach(star => {
                star.addEventListener('click', (e) => {
                    const rating = parseInt(e.target.dataset.rating);
                    document.getElementById('ratingValue').value = rating;
                    
                    document.querySelectorAll('.rating-star').forEach((s, index) => {
                        if (index < rating) {
                            s.style.color = '#f39c12';
                        } else {
                            s.style.color = '#e0e0e0';
                        }
                    });
                });
            });
        }, 100);

        modal.classList.add('active');
    }

    filterRidesByDate() {
        const startDate = document.getElementById('rideStartDate').value;
        const endDate = document.getElementById('rideEndDate').value;

        if (!startDate || !endDate) {
            this.showToast('Please select both start and end dates', 'error');
            return;
        }

        const filteredRides = window.dataHelpers.getRidesByDateRange(startDate, endDate);
        
        // Temporarily update data and reload
        const originalData = window.appData.rides;
        window.appData.rides = filteredRides;
        this.loadRideHistory();
        window.appData.rides = originalData;

        this.showToast(`Showing ${filteredRides.length} rides for selected date range`, 'info');
    }

    showMetricDetails(metric) {
        const modal = document.getElementById('modalOverlay');
        const title = document.getElementById('modalTitle');
        const content = document.getElementById('modalContent');

        let detailContent = '';
        
        switch(metric) {
            case 'rides':
                title.textContent = 'Ride Details';
                detailContent = `
                    <div class="metric-details">
                        <h4>Recent Rides</h4>
                        ${window.appData.rides.slice(0, 5).map(ride => `
                            <div class="detail-item">
                                <strong>${ride.pickup_location} → ${ride.dropoff_location}</strong><br>
                                <small>${new Date(ride.ride_date).toLocaleDateString()} • $${ride.fare_amount}</small>
                            </div>
                        `).join('')}
                    </div>
                `;
                break;
            case 'points':
                title.textContent = 'Points Breakdown';
                detailContent = `
                    <div class="metric-details">
                        <h4>Points Sources</h4>
                        <div class="detail-item">Quiz Completion: ${window.appData.quizProgress.reduce((sum, q) => sum + q.points_awarded, 0)} pts</div>
                        <div class="detail-item">Ride Bonuses: 150 pts</div>
                        <div class="detail-item">Referral Bonuses: 150 pts</div>
                        <div class="detail-item">Streak Bonuses: 85 pts</div>
                    </div>
                `;
                break;
            case 'streak':
                title.textContent = 'Streak Information';
                detailContent = `
                    <div class="metric-details">
                        <h4>Current Streak: ${window.dataHelpers.getCurrentStreak()} days</h4>
                        <p>Keep riding daily to maintain your streak and earn bonus points!</p>
                        <div class="streak-calendar">
                            <!-- Streak visualization would go here -->
                        </div>
                    </div>
                `;
                break;
            case 'referrals':
                title.textContent = 'Referral Network';
                detailContent = `
                    <div class="metric-details">
                        <h4>Your Referrals</h4>
                        ${window.appData.referrals.map(ref => `
                            <div class="detail-item">
                                <strong>${ref.new_user_name}</strong><br>
                                <small>Joined ${new Date(ref.timestamp).toLocaleDateString()} • +${ref.bonus_points} pts</small>
                            </div>
                        `).join('')}
                    </div>
                `;
                break;
        }

        content.innerHTML = detailContent;
        modal.classList.add('active');
    }

    handleKeyboardShortcuts(e) {
        // Keyboard shortcuts for power users
        if (e.ctrlKey || e.metaKey) {
            switch(e.key) {
                case 'k':
                    e.preventDefault();
                    document.getElementById('globalSearch').focus();
                    break;
                case 'e':
                    e.preventDefault();
                    this.showExportModal();
                    break;
                case '1':
                    e.preventDefault();
                    this.switchSection('overview');
                    break;
                case '2':
                    e.preventDefault();
                    this.switchSection('rides');
                    break;
                case '3':
                    e.preventDefault();
                    this.switchSection('ratings');
                    break;
                case '4':
                    e.preventDefault();
                    this.switchSection('quiz');
                    break;
                case '5':
                    e.preventDefault();
                    this.switchSection('notifications');
                    break;
            }
        }

        // Escape key to close modals
        if (e.key === 'Escape') {
            this.closeModal();
            this.clearSearchResults();
        }
    }

    loadAnalytics() {
        // Load engagement chart
        const engagementCtx = document.getElementById('engagementChart');
        if (engagementCtx && !this.charts.engagementChart) {
            this.charts.engagementChart = new Chart(engagementCtx, {
                type: 'doughnut',
                data: window.appData.analytics.userEngagement,
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }

        // Load revenue chart
        const revenueCtx = document.getElementById('revenueChart');
        if (revenueCtx && !this.charts.revenueChart) {
            this.charts.revenueChart = new Chart(revenueCtx, {
                type: 'line',
                data: window.appData.analytics.revenueData,
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });
        }

        // Load performance metrics
        this.loadPerformanceMetrics();
    }

    loadPerformanceMetrics() {
        const container = document.getElementById('performanceMetrics');
        if (!container) return;

        const metrics = [
            { label: 'Average Response Time', value: '2.3s', trend: 'down', good: true },
            { label: 'User Satisfaction', value: '94%', trend: 'up', good: true },
            { label: 'App Crashes', value: '0.02%', trend: 'down', good: true },
            { label: 'Daily Active Users', value: '1,247', trend: 'up', good: true }
        ];

        container.innerHTML = metrics.map(metric => `
            <div class="performance-metric">
                <div class="metric-label">${metric.label}</div>
                <div class="metric-value ${metric.good ? 'good' : 'bad'}">${metric.value}</div>
                <div class="metric-trend ${metric.trend}">
                    <i class="fas fa-arrow-${metric.trend}"></i>
                </div>
            </div>
        `).join('');
    }

    updateUserProfile() {
        const user = window.appData.user;
        // Update any user-specific UI elements
        document.title = `Straight-Way Dashboard - ${user.name}`;
    }

    // Navigation helper methods
    goToRide(rideId) {
        this.switchSection('rides');
        this.clearSearchResults();
        // Highlight the specific ride
        setTimeout(() => {
            const rideRow = document.querySelector(`[data-ride-id="${rideId}"]`);
            if (rideRow) {
                rideRow.scrollIntoView({ behavior: 'smooth' });
                rideRow.style.backgroundColor = '#e3f2fd';
                setTimeout(() => {
                    rideRow.style.backgroundColor = '';
                }, 2000);
            }
        }, 100);
    }

    goToRating(rideId) {
        this.switchSection('ratings');
        this.clearSearchResults();
    }

    goToNotification(notificationId) {
        this.switchSection('notifications');
        this.clearSearchResults();
        this.markNotificationRead(notificationId);
    }

    viewRideDetails(rideId) {
        const ride = window.appData.rides.find(r => r.ride_id === rideId);
        if (!ride) return;

        const modal = document.getElementById('modalOverlay');
        const title = document.getElementById('modalTitle');
        const content = document.getElementById('modalContent');

        title.textContent = 'Ride Details';
        content.innerHTML = `
            <div class="ride-details">
                <div class="detail-section">
                    <h4>Trip Information</h4>
                    <div class="detail-grid">
                        <div class="detail-item">
                            <label>From:</label>
                            <span>${ride.pickup_location}</span>
                        </div>
                        <div class="detail-item">
                            <label>To:</label>
                            <span>${ride.dropoff_location}</span>
                        </div>
                        <div class="detail-item">
                            <label>Distance:</label>
                            <span>${ride.distance_km} km</span>
                        </div>
                        <div class="detail-item">
                            <label>Fare:</label>
                            <span>$${ride.fare_amount}</span>
                        </div>
                        <div class="detail-item">
                            <label>Date:</label>
                            <span>${new Date(ride.ride_date).toLocaleString()}</span>
                        </div>
                        <div class="detail-item">
                            <label>Streak Day:</label>
                            <span>${ride.ride_streak_day}</span>
                        </div>
                    </div>
                </div>
            </div>
        `;

        modal.classList.add('active');
    }

    editRide(rideId) {
        const ride = window.appData.rides.find(r => r.ride_id === rideId);
        if (!ride) return;

        const modal = document.getElementById('modalOverlay');
        const title = document.getElementById('modalTitle');
        const content = document.getElementById('modalContent');

        title.textContent = 'Edit Ride';
        content.innerHTML = `
            <div class="form-group">
                <label class="form-label">From:</label>
                <input type="text" id="editFrom" class="form-input" value="${ride.pickup_location}">
            </div>
            <div class="form-group">
                <label class="form-label">To:</label>
                <input type="text" id="editTo" class="form-input" value="${ride.dropoff_location}">
            </div>
            <div class="form-group">
                <label class="form-label">Distance (km):</label>
                <input type="number" id="editDistance" class="form-input" value="${ride.distance_km}" step="0.1">
            </div>
            <div class="form-group">
                <label class="form-label">Fare ($):</label>
                <input type="number" id="editFare" class="form-input" value="${ride.fare_amount}" step="0.01">
            </div>
        `;

        modal.classList.add('active');
    }
}

// Initialize the dashboard when the page loads
let dashboard;
document.addEventListener('DOMContentLoaded', () => {
    dashboard = new StraightWayDashboard();
});

// Add some additional CSS for search results and other dynamic elements
const additionalStyles = `
    .search-results-overlay {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0,0,0,0.5);
        display: none;
        align-items: center;
        justify-content: center;
        z-index: 2000;
    }

    .search-results-container {
        background: white;
        border-radius: 15px;
        max-width: 600px;
        width: 90%;
        max-height: 80vh;
        overflow-y: auto;
    }

    .search-results-header {
        padding: 1.5rem;
        border-bottom: 1px solid #e0e0e0;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .search-results-list {
        padding: 1rem;
    }

    .search-result-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        border-radius: 10px;
        cursor: pointer;
        transition: background 0.3s ease;
        margin-bottom: 0.5rem;
    }

    .search-result-item:hover {
        background: #f8f9fa;
    }

    .result-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: #e3f2fd;
        display: flex;
        align-items: center;
        justify-content: center;
        color: #2196f3;
    }

    .result-content {
        flex: 1;
    }

    .result-title {
        font-weight: 600;
        color: #2c3e50;
        margin-bottom: 0.25rem;
    }

    .result-meta {
        font-size: 0.9rem;
        color: #7f8c8d;
    }

    .rating-input {
        display: flex;
        gap: 0.25rem;
        margin-bottom: 1rem;
    }

    .rating-star {
        font-size: 1.5rem;
        color: #e0e0e0;
        cursor: pointer;
        transition: color 0.3s ease;
    }

    .rating-star:hover {
        color: #f39c12;
    }

    .checkbox-label {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        cursor: pointer;
    }

    .streak-badge {
        background: #e74c3c;
        color: white;
        padding: 0.25rem 0.5rem;
        border-radius: 15px;
        font-size: 0.8rem;
        font-weight: 600;
    }

    .btn-sm {
        padding: 0.5rem;
        font-size: 0.8rem;
        margin-right: 0.25rem;
    }

    .rating-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        margin-bottom: 1rem;
    }

    .rating-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 1rem;
    }

    .rating-comment {
        font-style: italic;
        color: #34495e;
        margin-bottom: 0.5rem;
    }

    .rating-sentiment {
        font-size: 0.9rem;
        color: #7f8c8d;
    }

    .sentiment-score.positive { color: #27ae60; }
    .sentiment-score.neutral { color: #f39c12; }
    .sentiment-score.negative { color: #e74c3c; }

    .progress-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        padding: 1rem;
        background: white;
        border-radius: 10px;
        margin-bottom: 0.5rem;
        box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .progress-icon {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
    }

    .progress-item.correct .progress-icon { background: #27ae60; }
    .progress-item.incorrect .progress-icon { background: #e74c3c; }

    .performance-metric {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1rem;
        background: #f8f9fa;
        border-radius: 10px;
        margin-bottom: 1rem;
    }

    .metric-value.good { color: #27ae60; }
    .metric-value.bad { color: #e74c3c; }

    .metric-trend.up { color: #27ae60; }
    .metric-trend.down { color: #e74c3c; }

    .detail-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1rem;
    }

    .detail-item {
        display: flex;
        flex-direction: column;
        gap: 0.25rem;
    }

    .detail-item label {
        font-weight: 600;
        color: #7f8c8d;
        font-size: 0.9rem;
    }

    .detail-item span {
        color: #2c3e50;
    }
`;

// Inject additional styles
const styleSheet = document.createElement('style');
styleSheet.textContent = additionalStyles;
document.head.appendChild(styleSheet);