# RATEYOURDRIVER - Interactive Dashboard

**In the name of YAHOSHUA HaMashiach**

A comprehensive, fully interactive single-screen interface for the STRAIGHT-WAY rideshare platform's driver rating system. This dashboard dynamically integrates and utilizes all data sources to provide real-time visualization, filtering, searching, and manipulation capabilities.

## 🚗 Project Overview

RATEYOURDRIVER is part of the STRAIGHT-WAY rideshare platform, designed to revolutionize urban ridesharing by creating a bold, safe, and culturally rooted platform that empowers neighborhoods, uplifts people, and transforms everyday travel into a journey of connection, joy, and purpose.

## ✨ Features

### 📊 Interactive Dashboard Components
- **Statistics Grid**: 5 clickable stat cards with real-time data
- **Driver Rating System**: Interactive 5-star rating with sentiment analysis
- **Data Visualization**: Chart.js powered analytics with multiple timeframes
- **Interactive Data Table**: Sortable, filterable, searchable ride history

### 🔍 Advanced User Interactions
- **Global Search**: Cross-data search with modal results
- **Modal Windows**: Detailed views for statistics and user profiles
- **Live Updates**: Real-time data simulation with notifications
- **Export Functionality**: CSV/JSON data export capabilities

### 🎨 UI/UX Excellence
- **Modern Design**: Glassmorphism effects with gradient backgrounds
- **Responsive Layout**: Mobile-friendly grid system
- **Accessibility**: ARIA labels, keyboard navigation, high contrast support
- **Performance**: Optimized rendering and efficient data handling

### 🕊️ Spiritual & Cultural Integration
- **Torah Quiz System**: Interactive spiritual questions with progress tracking
- **Biblical Values**: Peace, Strength, Kindness reflected in UI elements
- **Hebrew Terminology**: YAHOSHUA references and spiritual context
- **Community Focus**: Referral system and neighborhood empowerment

## 🛠️ Technical Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Visualization**: Chart.js for data charts
- **Icons**: Font Awesome 6.0
- **Architecture**: Modular component-based structure
- **Responsive**: CSS Grid and Flexbox layouts

## 📁 Project Structure

```
RATEYOURDRIVER/
├── index.html                 # Main HTML file
├── styles.css                 # Comprehensive CSS styles
├── script.js                  # JavaScript functionality
├── .vscode/
│   ├── settings.json         # VS Code workspace settings
│   └── extensions.json       # Recommended extensions
├── README.md                 # Project documentation
└── [Source Documents]
    ├── PROMPT RATEYOURDRIVERSCREEN.pdf
    ├── RATEYOURDRIVERSCREEN.pdf
    ├── STRAIGHT-WAY BACKEND FUNCTION TEMPLATES MASTER.pdf
    └── STRAIGHT-WAY RIDESHARE PLATFORM ARCHITECTURE MASTER.pdf
```

## 🚀 Getting Started

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari, Edge)
- VS Code (recommended) with Live Server extension
- Basic understanding of HTML, CSS, and JavaScript

### Installation
1. Clone or download the project files
2. Open the project folder in VS Code
3. Install recommended extensions when prompted
4. Right-click on `index.html` and select "Open with Live Server"
5. The dashboard will open in your default browser

### Alternative Setup
Simply open `index.html` in any modern web browser to run the application locally.

## 📱 Usage

### Dashboard Navigation
- **Statistics Cards**: Click any stat card for detailed breakdowns
- **Search**: Use the global search to find rides, drivers, or data
- **Filters**: Apply rating and date filters to the data table
- **Sorting**: Click column headers to sort table data
- **Export**: Download data in CSV or JSON formats

### Driver Rating
1. Select star rating (1-5 stars)
2. Add optional comment
3. Choose relevant tags (Peace, Strength, Kindness, etc.)
4. Submit rating for sentiment analysis and storage

### Data Visualization
- Switch between Week/Month/Year views
- Toggle live updates for real-time data simulation
- Hover over chart elements for detailed information

## 🔧 Customization

### Adding New Data Sources
1. Update the `ridesData` array in `script.js`
2. Modify the `populateTable()` function for new fields
3. Adjust CSS classes in `styles.css` for styling

### Styling Modifications
- Primary colors: Modify CSS custom properties
- Layout: Adjust CSS Grid configurations
- Animations: Update transition and animation properties

### Functionality Extensions
- Add new modal types in `showDetailModal()`
- Extend search functionality in `performGlobalSearch()`
- Create additional chart types in `initializeCharts()`

## 🌟 Key Components

### Data Models
- **Ride History**: Trip metadata with sentiment analysis
- **Driver Ratings**: Star ratings with comment sentiment
- **Torah Quiz**: Spiritual questions with progress tracking
- **Notifications**: System alerts and user messages

### Interactive Elements
- **Star Rating System**: Hover effects and click handlers
- **Tag Selection**: Multi-select spiritual values
- **Modal Windows**: Detailed information displays
- **Live Updates**: Real-time data simulation

### Accessibility Features
- **ARIA Labels**: Screen reader compatibility
- **Keyboard Navigation**: Full keyboard accessibility
- **High Contrast**: Support for accessibility preferences
- **Responsive Design**: Mobile and tablet optimization

## 🎯 Performance Optimizations

- **Efficient DOM Manipulation**: Minimal reflows and repaints
- **Event Delegation**: Optimized event handling
- **Lazy Loading**: On-demand content loading
- **CSS Animations**: Hardware-accelerated transitions

## 🔒 Security Considerations

- **Input Validation**: Client-side data sanitization
- **XSS Prevention**: Proper content escaping
- **HTTPS Ready**: Secure protocol compatibility
- **Data Privacy**: Local storage with no external tracking

## 🤝 Contributing

This project is part of the STRAIGHT-WAY platform mission. Contributions should align with the spiritual and cultural values of the platform:

1. Maintain respect for Torah principles
2. Ensure accessibility and inclusivity
3. Follow clean code practices
4. Test thoroughly across devices and browsers

## 📄 License

This project is created for the STRAIGHT-WAY rideshare platform mission to revolutionize urban transportation through spiritual and community values.

## 🙏 Acknowledgments

- **YAHOSHUA HaMashiach** - For guidance and inspiration
- **Torah Wisdom** - For foundational principles
- **Community Values** - Peace, Strength, Kindness, and Unity

## 📞 Support

For technical support or questions about the STRAIGHT-WAY platform, please refer to the platform documentation or community resources.

---

**"Let your words be seasoned with grace." - Colossians 4:6**

*Built with love and purpose for the STRAIGHT-WAY community* 🕊️