// RATEYOURDRIVER - Interactive Dashboard JavaScript
// In the name of YAHOSHUA HaMashiach

// Global variables
let currentRating = 0;
let selectedTags = [];
let ridesData = [];
let liveUpdatesEnabled = false;
let currentView = 'dashboard';
let sortDirection = {};
let ridesChart = null;

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeData();
    initializeCharts();
    initializeEventListeners();
    startLiveUpdates();
});

// Sample data initialization
function initializeData() {
    ridesData = [
        {
            id: 1,
            date: '2024-01-15',
            driver: 'Malik Johnson',
            from: 'Downtown',
            to: 'Airport',
            distance: 12.5,
            fare: 28.50,
            rating: 5,
            comment: 'Excellent service, very peaceful ride',
            sentiment: 'positive',
            tags: ['peace', 'punctual']
        },
        {
            id: 2,
            date: '2024-01-14',
            driver: 'Sarah Williams',
            from: 'Home',
            to: 'Mall',
            distance: 8.2,
            fare: 19.75,
            rating: 4,
            comment: 'Good ride, clean car',
            sentiment: 'positive',
            tags: ['clean', 'kindness']
        },
        {
            id: 3,
            date: '2024-01-13',
            driver: 'David Cohen',
            from: 'Office',
            to: 'Home',
            distance: 15.3,
            fare: 32.25,
            rating: 5,
            comment: 'Amazing driver, felt very safe',
            sentiment: 'positive',
            tags: ['safe', 'strength']
        },
        {
            id: 4,
            date: '2024-01-12',
            driver: 'Rebecca Martinez',
            from: 'University',
            to: 'Downtown',
            distance: 9.8,
            fare: 22.00,
            rating: 4,
            comment: 'Nice conversation, very kind',
            sentiment: 'positive',
            tags: ['kindness', 'peace']
        },
        {
            id: 5,
            date: '2024-01-11',
            driver: 'Aaron Thompson',
            from: 'Hospital',
            to: 'Home',
            distance: 18.7,
            fare: 35.50,
            rating: 5,
            comment: 'Excellent service, very professional',
            sentiment: 'positive',
            tags: ['strength', 'punctual']
        }
    ];

    populateTable();
    updateStats();
}

// Event listeners initialization
function initializeEventListeners() {
    // Star rating functionality
    document.querySelectorAll('.star').forEach(star => {
        star.addEventListener('click', function() {
            currentRating = parseInt(this.dataset.rating);
            updateStarDisplay();
        });

        star.addEventListener('mouseover', function() {
            const rating = parseInt(this.dataset.rating);
            highlightStars(rating);
        });
    });

    document.getElementById('starRating').addEventListener('mouseleave', function() {
        updateStarDisplay();
    });

    // Tag selection functionality
    document.querySelectorAll('.tag-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tag = this.dataset.tag;
            if (selectedTags.includes(tag)) {
                selectedTags = selectedTags.filter(t => t !== tag);
                this.classList.remove('active');
            } else {
                selectedTags.push(tag);
                this.classList.add('active');
            }
        });
    });

    // Close modals when clicking outside
    window.addEventListener('click', function(event) {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = 'none';
        }
    });
}

// Star rating functions
function updateStarDisplay() {
    document.querySelectorAll('.star').forEach((star, index) => {
        if (index < currentRating) {
            star.classList.add('active');
        } else {
            star.classList.remove('active');
        }
    });
}

function highlightStars(rating) {
    document.querySelectorAll('.star').forEach((star, index) => {
        if (index < rating) {
            star.classList.add('active');
        } else {
            star.classList.remove('active');
        }
    });
}

// Submit rating
function submitRating() {
    if (currentRating === 0) {
        showNotification('Please select a rating', 'warning');
        return;
    }

    const comment = document.getElementById('ratingComment').value;
    const driver = document.getElementById('currentDriver').textContent;
    const sentiment = analyzeSentiment(comment);

    const newRating = {
        id: ridesData.length + 1,
        date: new Date().toISOString().split('T')[0],
        driver: driver,
        from: 'Current Location',
        to: 'Destination',
        distance: Math.random() * 20 + 5,
        fare: Math.random() * 40 + 15,
        rating: currentRating,
        comment: comment,
        sentiment: sentiment,
        tags: [...selectedTags]
    };

    ridesData.unshift(newRating);
    populateTable();
    updateStats();

    // Reset form
    currentRating = 0;
    selectedTags = [];
    document.getElementById('ratingComment').value = '';
    document.querySelectorAll('.star').forEach(star => star.classList.remove('active'));
    document.querySelectorAll('.tag-btn').forEach(btn => btn.classList.remove('active'));

    showNotification('Rating submitted successfully!', 'success');
}

// Sentiment analysis simulation
function analyzeSentiment(text) {
    const positiveWords = ['excellent', 'great', 'amazing', 'wonderful', 'peaceful', 'safe', 'clean', 'kind', 'professional', 'nice'];
    const negativeWords = ['bad', 'terrible', 'awful', 'rude', 'unsafe', 'dirty', 'late', 'unprofessional'];

    const words = text.toLowerCase().split(' ');
    let positiveCount = 0;
    let negativeCount = 0;

    words.forEach(word => {
        if (positiveWords.includes(word)) positiveCount++;
        if (negativeWords.includes(word)) negativeCount++;
    });

    if (positiveCount > negativeCount) return 'positive';
    if (negativeCount > positiveCount) return 'negative';
    return 'neutral';
}

// Table functionality
function populateTable() {
    const tbody = document.getElementById('ridesTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';

    ridesData.forEach(ride => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${ride.date}</td>
            <td>${ride.driver}</td>
            <td>${ride.from}</td>
            <td>${ride.to}</td>
            <td>${ride.distance.toFixed(1)} mi</td>
            <td>$${ride.fare.toFixed(2)}</td>
            <td>${'★'.repeat(ride.rating)}${'☆'.repeat(5-ride.rating)}</td>
            <td><span class="sentiment-indicator sentiment-${ride.sentiment}">${ride.sentiment}</span></td>
            <td>
                <button class="control-btn" onclick="viewRideDetails(${ride.id})" title="View Details">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="control-btn" onclick="editRide(${ride.id})" title="Edit">
                    <i class="fas fa-edit"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Sorting functionality
function sortTable(columnIndex) {
    const table = document.getElementById('ridesTable');
    if (!table) return;
    
    const tbody = table.querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));

    const isAscending = !sortDirection[columnIndex];
    sortDirection[columnIndex] = isAscending;

    rows.sort((a, b) => {
        const aValue = a.cells[columnIndex].textContent.trim();
        const bValue = b.cells[columnIndex].textContent.trim();

        let comparison = 0;
        if (!isNaN(parseFloat(aValue.replace(/[^0-9.-]/g, ''))) && !isNaN(parseFloat(bValue.replace(/[^0-9.-]/g, '')))) {
            comparison = parseFloat(aValue.replace(/[^0-9.-]/g, '')) - parseFloat(bValue.replace(/[^0-9.-]/g, ''));
        } else {
            comparison = aValue.localeCompare(bValue);
        }

        return isAscending ? comparison : -comparison;
    });

    tbody.innerHTML = '';
    rows.forEach(row => tbody.appendChild(row));

    // Update sort indicators
    document.querySelectorAll('th i').forEach(icon => {
        icon.className = 'fas fa-sort';
    });
    const currentIcon = table.querySelectorAll('th')[columnIndex].querySelector('i');
    currentIcon.className = isAscending ? 'fas fa-sort-up' : 'fas fa-sort-down';
}

// Filtering functionality
function filterTable() {
    const ratingFilter = document.getElementById('ratingFilter')?.value;
    const dateFilter = document.getElementById('dateFilter')?.value;

    let filteredData = ridesData;

    if (ratingFilter) {
        filteredData = filteredData.filter(ride => ride.rating == ratingFilter);
    }

    if (dateFilter) {
        const now = new Date();
        filteredData = filteredData.filter(ride => {
            const rideDate = new Date(ride.date);
            switch(dateFilter) {
                case 'today':
                    return rideDate.toDateString() === now.toDateString();
                case 'week':
                    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
                    return rideDate >= weekAgo;
                case 'month':
                    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
                    return rideDate >= monthAgo;
                default:
                    return true;
            }
        });
    }

    // Update table with filtered data
    const tbody = document.getElementById('ridesTableBody');
    if (!tbody) return;
    
    tbody.innerHTML = '';

    filteredData.forEach(ride => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${ride.date}</td>
            <td>${ride.driver}</td>
            <td>${ride.from}</td>
            <td>${ride.to}</td>
            <td>${ride.distance.toFixed(1)} mi</td>
            <td>$${ride.fare.toFixed(2)}</td>
            <td>${'★'.repeat(ride.rating)}${'☆'.repeat(5-ride.rating)}</td>
            <td><span class="sentiment-indicator sentiment-${ride.sentiment}">${ride.sentiment}</span></td>
            <td>
                <button class="control-btn" onclick="viewRideDetails(${ride.id})">
                    <i class="fas fa-eye"></i>
                </button>
                <button class="control-btn" onclick="editRide(${ride.id})">
                    <i class="fas fa-edit"></i>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Search functionality
function searchTable() {
    const searchTerm = document.getElementById('tableSearch')?.value.toLowerCase();
    if (!searchTerm) return;
    
    const rows = document.querySelectorAll('#ridesTableBody tr');

    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

function performGlobalSearch() {
    const searchTerm = document.getElementById('globalSearch')?.value.toLowerCase();
    if (!searchTerm) return;

    const results = ridesData.filter(ride => 
        ride.driver.toLowerCase().includes(searchTerm) ||
        ride.from.toLowerCase().includes(searchTerm) ||
        ride.to.toLowerCase().includes(searchTerm) ||
        ride.comment.toLowerCase().includes(searchTerm)
    );

    showSearchResults(results, searchTerm);
}

function showSearchResults(results, searchTerm) {
    const modal = document.getElementById('detailModal');
    const title = document.getElementById('modalTitle');
    const content = document.getElementById('modalContent');

    if (!modal || !title || !content) return;

    title.textContent = `Search Results for "${searchTerm}"`;
    
    let html = '<div class="search-results">';
    
    if (results.length > 0) {
        html += '<h3>Rides Found</h3>';
        results.forEach(ride => {
            html += `
                <div style="background: #f8f9fa; padding: 15px; margin: 10px 0; border-radius: 8px;">
                    <strong>${ride.driver}</strong> - ${ride.from} to ${ride.to}
                    <br><small>${ride.date} | ${ride.rating} stars | $${ride.fare.toFixed(2)}</small>
                    <br><em>"${ride.comment}"</em>
                </div>
            `;
        });
    } else {
        html += '<p>No results found.</p>';
    }

    html += '</div>';
    content.innerHTML = html;
    modal.style.display = 'block';
}

// Chart initialization
function initializeCharts() {
    const ctx = document.getElementById('ridesChart')?.getContext('2d');
    if (!ctx) return;
    
    ridesChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
            datasets: [{
                label: 'Rides',
                data: [12, 19, 3, 5, 2, 3, 9],
                borderColor: '#3498db',
                backgroundColor: 'rgba(52, 152, 219, 0.1)',
                tension: 0.4,
                fill: true
            }, {
                label: 'Average Rating',
                data: [4.5, 4.8, 4.2, 4.6, 4.9, 4.3, 4.7],
                borderColor: '#f39c12',
                backgroundColor: 'rgba(243, 156, 18, 0.1)',
                tension: 0.4,
                fill: true,
                yAxisID: 'y1'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                }
            },
            scales: {
                x: {
                    display: true,
                    title: {
                        display: true,
                        text: 'Day of Week'
                    }
                },
                y: {
                    type: 'linear',
                    display: true,
                    position: 'left',
                    title: {
                        display: true,
                        text: 'Number of Rides'
                    }
                },
                y1: {
                    type: 'linear',
                    display: true,
                    position: 'right',
                    title: {
                        display: true,
                        text: 'Average Rating'
                    },
                    grid: {
                        drawOnChartArea: false,
                    },
                    min: 0,
                    max: 5
                }
            }
        }
    });
}

function updateChart() {
    if (!ridesChart) return;
    
    const timeframe = document.getElementById('chartTimeframe')?.value;
    let labels, ridesDataChart, ratingsData;

    switch(timeframe) {
        case 'week':
            labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
            ridesDataChart = [12, 19, 3, 5, 2, 3, 9];
            ratingsData = [4.5, 4.8, 4.2, 4.6, 4.9, 4.3, 4.7];
            break;
        case 'month':
            labels = ['Week 1', 'Week 2', 'Week 3', 'Week 4'];
            ridesDataChart = [45, 52, 38, 41];
            ratingsData = [4.6, 4.7, 4.5, 4.8];
            break;
        case 'year':
            labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
            ridesDataChart = [20, 25, 30, 28, 35, 40, 45, 42, 38, 33, 28, 25];
            ratingsData = [4.5, 4.6, 4.7, 4.6, 4.8, 4.7, 4.9, 4.8, 4.6, 4.7, 4.5, 4.6];
            break;
    }

    ridesChart.data.labels = labels;
    ridesChart.data.datasets[0].data = ridesDataChart;
    ridesChart.data.datasets[1].data = ratingsData;
    ridesChart.update();
}

// Modal functionality
function showDetailModal(type) {
    const modal = document.getElementById('detailModal');
    const title = document.getElementById('modalTitle');
    const content = document.getElementById('modalContent');

    if (!modal || !title || !content) return;

    switch(type) {
        case 'rides':
            title.textContent = 'Total Rides Details';
            content.innerHTML = `
                <div style="text-align: center;">
                    <div style="font-size: 48px; color: #3498db; margin-bottom: 20px;">🚗</div>
                    <p><strong>Total Rides:</strong> ${ridesData.length}</p>
                    <p><strong>Average Distance:</strong> 12.3 miles per ride</p>
                    <p><strong>Total Distance:</strong> ${Math.round(ridesData.reduce((sum, ride) => sum + ride.distance, 0))} miles</p>
                    <p><strong>Most Frequent Route:</strong> Downtown ↔ Airport</p>
                </div>
            `;
            break;
        case 'streak':
            title.textContent = 'Ride Streak Details';
            content.innerHTML = `
                <div style="text-align: center;">
                    <div style="font-size: 48px; color: #e74c3c; margin-bottom: 20px;">🔥</div>
                    <p><strong>Current Streak:</strong> 12 days</p>
                    <p><strong>Longest Streak:</strong> 28 days</p>
                    <p><strong>Total Streak Days:</strong> 156 days</p>
                    <p style="color: #666;">Keep riding to maintain your streak!</p>
                </div>
            `;
            break;
        case 'rating':
            title.textContent = 'Rating Details';
            const avgRating = ridesData.reduce((sum, ride) => sum + ride.rating, 0) / ridesData.length;
            content.innerHTML = `
                <div style="text-align: center;">
                    <div style="font-size: 48px; color: #f39c12; margin-bottom: 20px;">⭐</div>
                    <p><strong>Average Rating:</strong> ${avgRating.toFixed(1)}/5</p>
                    <p><strong>Total Ratings Given:</strong> ${ridesData.length}</p>
                    <div style="margin-top: 20px;">
                        <div>5 Stars: ${ridesData.filter(r => r.rating === 5).length} (${Math.round(ridesData.filter(r => r.rating === 5).length / ridesData.length * 100)}%)</div>
                        <div>4 Stars: ${ridesData.filter(r => r.rating === 4).length} (${Math.round(ridesData.filter(r => r.rating === 4).length / ridesData.length * 100)}%)</div>
                        <div>3 Stars: ${ridesData.filter(r => r.rating === 3).length} (${Math.round(ridesData.filter(r => r.rating === 3).length / ridesData.length * 100)}%)</div>
                        <div>2 Stars: ${ridesData.filter(r => r.rating === 2).length} (${Math.round(ridesData.filter(r => r.rating === 2).length / ridesData.length * 100)}%)</div>
                        <div>1 Star: ${ridesData.filter(r => r.rating === 1).length} (${Math.round(ridesData.filter(r => r.rating === 1).length / ridesData.length * 100)}%)</div>
                    </div>
                </div>
            `;
            break;
        case 'miles':
            const totalMiles = ridesData.reduce((sum, ride) => sum + ride.distance, 0);
            title.textContent = 'Miles Details';
            content.innerHTML = `
                <div style="text-align: center;">
                    <div style="font-size: 48px; color: #9b59b6; margin-bottom: 20px;">🛣️</div>
                    <p><strong>Total Miles:</strong> ${Math.round(totalMiles)}</p>
                    <p><strong>Average per Ride:</strong> ${(totalMiles / ridesData.length).toFixed(1)} miles</p>
                    <p><strong>Longest Ride:</strong> ${Math.max(...ridesData.map(r => r.distance)).toFixed(1)} miles</p>
                    <p><strong>Environmental Impact:</strong> ${(totalMiles * 0.4 / 1000).toFixed(1)} tons CO2 saved</p>
                </div>
            `;
            break;
        case 'points':
            title.textContent = 'Torah Points Details';
            content.innerHTML = `
                <div style="text-align: center;">
                    <div style="font-size: 48px; color: #9b59b6; margin-bottom: 20px;">🏆</div>
                    <p><strong>Total Points:</strong> 8,950</p>
                    <p><strong>Quiz Accuracy:</strong> 89%</p>
                    <p><strong>Questions Answered:</strong> 156</p>
                    <p><strong>Current Level:</strong> Torah Scholar</p>
                </div>
            `;
            break;
    }

    modal.style.display = 'block';
}

function showUserModal() {
    const modal = document.getElementById('userModal');
    if (modal) {
        modal.style.display = 'block';
    }
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.style.display = 'none';
    }
}

// Utility functions
function switchView(view) {
    currentView = view;
    document.querySelectorAll('.nav-item').forEach(item => item.classList.remove('active'));
    if (event && event.target) {
        event.target.closest('.nav-item').classList.add('active');
    }
    showNotification(`Switched to ${view} view`, 'info');
}

function refreshRatingData() {
    const drivers = ['Malik Johnson', 'Sarah Williams', 'David Cohen', 'Rebecca Martinez', 'Aaron Thompson'];
    const randomDriver = drivers[Math.floor(Math.random() * drivers.length)];
    const driverElement = document.getElementById('currentDriver');
    if (driverElement) {
        driverElement.textContent = randomDriver;
    }
    showNotification('Driver data refreshed', 'success');
}

function exportRatingData() {
    const data = ridesData.map(ride => ({
        date: ride.date,
        driver: ride.driver,
        rating: ride.rating,
        comment: ride.comment,
        sentiment: ride.sentiment
    }));
    
    const csv = convertToCSV(data);
    downloadFile(csv, 'ratings_export.csv', 'text/csv');
    showNotification('Rating data exported successfully', 'success');
}

function exportTableData() {
    const csv = convertToCSV(ridesData);
    downloadFile(csv, 'rides_export.csv', 'text/csv');
    showNotification('Table data exported successfully', 'success');
}

function convertToCSV(data) {
    if (data.length === 0) return '';
    const headers = Object.keys(data[0]).join(',');
    const rows = data.map(row => Object.values(row).map(val => `"${val}"`).join(','));
    return [headers, ...rows].join('\n');
}

function downloadFile(content, filename, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
}

function viewRideDetails(rideId) {
    const ride = ridesData.find(r => r.id === rideId);
    if (ride) {
        const modal = document.getElementById('detailModal');
        const title = document.getElementById('modalTitle');
        const content = document.getElementById('modalContent');

        if (!modal || !title || !content) return;

        title.textContent = `Ride Details - ${ride.driver}`;
        content.innerHTML = `
            <div>
                <p><strong>Date:</strong> ${ride.date}</p>
                <p><strong>Driver:</strong> ${ride.driver}</p>
                <p><strong>Route:</strong> ${ride.from} → ${ride.to}</p>
                <p><strong>Distance:</strong> ${ride.distance.toFixed(1)} miles</p>
                <p><strong>Fare:</strong> $${ride.fare.toFixed(2)}</p>
                <p><strong>Rating:</strong> ${'★'.repeat(ride.rating)}${'☆'.repeat(5-ride.rating)}</p>
                <p><strong>Comment:</strong> "${ride.comment}"</p>
                <p><strong>Sentiment:</strong> <span class="sentiment-indicator sentiment-${ride.sentiment}">${ride.sentiment}</span></p>
                <p><strong>Tags:</strong> ${ride.tags.join(', ')}</p>
            </div>
        `;
        modal.style.display = 'block';
    }
}

function editRide(rideId) {
    showNotification('Edit functionality coming soon!', 'info');
}

function toggleLiveUpdates() {
    const checkbox = document.getElementById('liveUpdates');
    if (checkbox) {
        liveUpdatesEnabled = checkbox.checked;
        if (liveUpdatesEnabled) {
            startLiveUpdates();
            showNotification('Live updates enabled', 'success');
        } else {
            showNotification('Live updates disabled', 'info');
        }
    }
}

function startLiveUpdates() {
    if (liveUpdatesEnabled) {
        setInterval(() => {
            updateStats();
            if (Math.random() > 0.9) {
                simulateNewRide();
            }
        }, 5000);
    }
}

function simulateNewRide() {
    const drivers = ['Malik Johnson', 'Sarah Williams', 'David Cohen', 'Rebecca Martinez', 'Aaron Thompson'];
    const locations = ['Downtown', 'Airport', 'Mall', 'University', 'Hospital', 'Stadium'];
    
    const newRide = {
        id: ridesData.length + 1,
        date: new Date().toISOString().split('T')[0],
        driver: drivers[Math.floor(Math.random() * drivers.length)],
        from: locations[Math.floor(Math.random() * locations.length)],
        to: locations[Math.floor(Math.random() * locations.length)],
        distance: Math.random() * 20 + 5,
        fare: Math.random() * 40 + 15,
        rating: Math.floor(Math.random() * 5) + 1,
        comment: 'Auto-generated ride',
        sentiment: 'neutral',
        tags: []
    };

    ridesData.unshift(newRide);
    populateTable();
    updateStats();
    showNotification('New ride data received!', 'info');
}

function updateStats() {
    const totalRidesElement = document.getElementById('totalRides');
    const avgRatingElement = document.getElementById('avgRating');
    const totalMilesElement = document.getElementById('totalMiles');
    const currentStreakElement = document.getElementById('currentStreak');
    const totalPointsElement = document.getElementById('totalPoints');

    if (totalRidesElement) {
        totalRidesElement.textContent = ridesData.length;
    }
    
    if (avgRatingElement && ridesData.length > 0) {
        const avgRating = ridesData.reduce((sum, ride) => sum + ride.rating, 0) / ridesData.length;
        avgRatingElement.textContent = avgRating.toFixed(1);
    }
    
    if (totalMilesElement) {
        const totalMiles = ridesData.reduce((sum, ride) => sum + ride.distance, 0);
        totalMilesElement.textContent = Math.round(totalMiles).toLocaleString();
    }
    
    // Simulate streak and points updates
    if (currentStreakElement) {
        currentStreakElement.textContent = Math.floor(Math.random() * 5) + 10;
    }
    
    if (totalPointsElement) {
        totalPointsElement.textContent = (8950 + Math.floor(Math.random() * 100)).toLocaleString();
    }
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => {
        notification.remove();
    }, 3000);
}